###############################################################################################
### Ethnic Representational Priorities and Political Engagement in Deeply Divided Societies ###
### William O'Brochta                                                                       ###
### Louisiana Tech University                                                               ###
### Published in Nations and Nationalism                                                    ###
###############################################################################################


library(haven)
library(cjoint)
library(MASS)
library(lmtest)
library(car)
library(psych)
library(Zelig)
library(ZeligChoice)
library(VGAM)
library(stargazer)

survey<-read_sav("Washington_final_withQ29.sav")
profiles<-read.csv("Profiles.csv",header=T, stringsAsFactors = T)
survey2<-merge(survey, profiles, by="Profile", all.x=T)

#Prepare survey
survey2$female<-ifelse(survey2$dem1==2, 1, 0)
survey2$age<-survey2$dem2
survey2$dem3<-ifelse(survey2$dem3==99,NA,survey2$dem3)
survey2$married<-ifelse(survey2$dem3==1, 1, 0)
survey2$education<-survey2$dem4
survey2$albanian<-ifelse(survey2$dem5==1,1,0)
survey2$dem6<-ifelse(survey2$dem6==99,NA,survey2$dem6)
survey2$incomepersonal<-survey2$dem6
survey2$dem7<-ifelse(survey2$dem7==99,NA,survey2$dem7)
survey2$incomehousehold<-survey2$dem7
survey2$householdsize<-survey2$dem8
survey2$region<-as.factor(survey2$dem9)
survey2$Skopje<-ifelse(survey2$region==1, 1, 0)
survey2$region2<-ifelse(survey2$region==2, 1, 0)
survey2$region3<-ifelse(survey2$region==3, 1, 9)
survey2$urban<-ifelse(survey2$dem10==1,1,0)
survey2$municipality<-as.factor(survey2$dem10)
survey2$news<-survey2$Q2_1
survey2$equalopportunity<-survey2$Q2_2
survey2$authoritarian<-survey2$Q2_3
survey2$knowledge<-ifelse(survey2$Q5==3, 1, 0)



#Alternative Measures of Vignette Profiles
survey2$ProfileNumber_f<-as.factor(survey2$ProfileNumber)
survey2$ProfileOverZero<-ifelse(survey2$ProfileNumber>0,1,0)
survey2$ProfileOverOne<-ifelse(survey2$ProfileNumber>2,1,0)
survey2$ProfileSDSM<-ifelse(survey2$ProfileParty=="SDSM",1,0)

#Variables of Interest
survey2$cabinetchoice<-as.factor(survey2$Q22)
survey2$hiring_ethnicity<-survey2$Q23
survey2$employee_ethnicity<-survey2$Q24
survey2$ministerfinancial<-survey2$Q25
survey2$ministerconcerns<-survey2$Q26
survey2$firstmeeting<-as.factor(survey2$Q27)
survey2$secondmeeting<-as.factor(survey2$Q28)

table(survey2$cabinetchoice, survey2$albanian)

#1=culture, 2=welfare, 3=international, 4=economy
survey2$cabinetcoded<-ifelse(survey2$cabinetchoice==9|
                               survey2$cabinetchoice==10|
                               survey2$cabinetchoice==16|
                               survey2$cabinetchoice==17|
                               survey2$cabinetchoice==23,1,NA)
survey2$cabinetcoded<-ifelse(survey2$cabinetchoice==2|
                               survey2$cabinetchoice==3|
                             survey2$cabinetchoice==8|
                               survey2$cabinetchoice==11,2,survey2$cabinetcoded)
survey2$cabinetcoded<-ifelse(survey2$cabinetchoice==1|
                             survey2$cabinetchoice==13|
                               survey2$cabinetchoice==19|
                               survey2$cabinetchoice==22,3,survey2$cabinetcoded)
survey2$cabinetcoded<-ifelse(is.na(survey2$cabinetcoded),4,survey2$cabinetcoded)
survey2$cabinetcoded<-as.factor(survey2$cabinetcoded)
survey2$cabinetcoded<-relevel(survey2$cabinetcoded, ref=4)

survey2$cabinetethnicity<-ifelse(survey2$cabinetchoice==1|
                                   survey2$cabinetchoice==19|
                                   survey2$cabinetchoice==22|
                                   survey2$cabinetchoice==13|
                                   survey2$cabinetchoice==12|
                                   survey2$cabinetchoice==3|
                                   survey2$cabinetchoice==4|
                                   survey2$cabinetchoice==15|
                                   survey2$cabinetchoice==6|
                                   survey2$cabinetchoice==2|
                                   survey2$cabinetchoice==7|
                                   survey2$cabinetchoice==9|
                                   survey2$cabinetchoice==14|
                                   survey2$cabinetchoice==16,"MAC",NA)

survey2$cabinetethnicity<-ifelse(survey2$cabinetchoice==5|
                                   survey2$cabinetchoice==8|
                                   survey2$cabinetchoice==10|
                                   survey2$cabinetchoice==11|
                                   survey2$cabinetchoice==23,"ALB",survey2$cabinetethnicity)

survey2$cabinetethnicity<-ifelse(survey2$cabinetchoice==17|
                                   survey2$cabinetchoice==18|
                                   survey2$cabinetchoice==20,"Other",survey2$cabinetethnicity)

survey2$cabinetethnicity<-as.factor(survey2$cabinetethnicity)
survey2$cabinetethnicity<-relevel(survey2$cabinetethnicity, ref="Other")
survey2$cabinetalbanian<-ifelse(survey2$cabinetethnicity=="ALB",1,0)
survey2$cabinetmacedonian<-ifelse(survey2$cabinetethnicity=="MAC",1,0)

cor(survey2$albanian,survey2$cabinetalbanian, use="complete.obs")
cor(1-survey2$albanian,survey2$cabinetmacedonian, use="complete.obs")

table(survey2$albanian,survey2$cabinetethnicity)


survey2$firstmeeting_n<-(survey2$Q27-1)/4
survey2$secondmeeting_n<-(survey2$Q28-1)/4


#Economy is reference category
model0<-zelig(cabinetcoded~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge+albanian,
                 data=survey2,
                 model = "mlogit", robust=T, cite = FALSE)
coef0<-summaryvglm(from_zelig_model(model0))
stargazer(coef0@coef3)


#Table SI.1.1
(table(survey2$cabinetcoded,survey2$albanian)/392)*100

survey2$cabinet_culture<-ifelse(survey2$cabinetcoded==1,1,0)
survey2$cabinet_welfare<-ifelse(survey2$cabinetcoded==2,1,0)
survey2$cabinet_international<-ifelse(survey2$cabinetcoded==3,1,0)
survey2$cabinet_economy<-ifelse(survey2$cabinetcoded==4,1,0)
t.test(survey2[survey2$albanian==0,]$cabinet_culture, survey2[survey2$albanian==1,]$cabinet_culture)
t.test(survey2[survey2$albanian==0,]$cabinet_welfare, survey2[survey2$albanian==1,]$cabinet_welfare)
t.test(survey2[survey2$albanian==0,]$cabinet_international, survey2[survey2$albanian==1,]$cabinet_international)
t.test(survey2[survey2$albanian==0,]$cabinet_economy, survey2[survey2$albanian==1,]$cabinet_economy)


#Second meeting influenced Albanian preferences more than Macedonians
macedonianshift<-table(survey2[survey2$albanian==0,]$firstmeeting,
                       survey2[survey2$albanian==0,]$secondmeeting)
(macedonianshift/392)*100
(392-sum(diag(macedonianshift)))/392

#Those who became more likely
macedonianshift2<-macedonianshift
macedonianshift2[lower.tri(macedonianshift2, diag=T)]<-0
sum(macedonianshift2)
#Pct of those shifting
sum(macedonianshift2)/(392-sum(diag(macedonianshift)))
#Those who became less likely
392-sum(diag(macedonianshift))-sum(macedonianshift2)
#Pct
(392-sum(diag(macedonianshift))-sum(macedonianshift2))/(392-sum(diag(macedonianshift)))

albanianshift<-table(survey2[survey2$albanian==1,]$firstmeeting,
                     survey2[survey2$albanian==1,]$secondmeeting)
(albanianshift/392)*100
392-sum(diag(albanianshift))

#Those who became more likely
albanianshift2<-albanianshift
albanianshift2[lower.tri(albanianshift2, diag=T)]<-0
sum(albanianshift2)
#Pct of those shifting
sum(albanianshift2)/(392-sum(diag(albanianshift)))
#Those who became less likely
392-sum(diag(albanianshift))-sum(albanianshift2)
#Pct
(392-sum(diag(albanianshift))-sum(albanianshift2))/(392-sum(diag(albanianshift)))



#Macedonians more likely to attend than Albanians
t.test(survey2[survey2$albanian==0,]$Q27,survey2[survey2$albanian==1,]$Q27)
mean(survey2[survey2$albanian==0,]$Q27)
mean(survey2[survey2$albanian==1,]$Q27)

t.test(survey2[survey2$albanian==0,]$Q28,survey2[survey2$albanian==1,]$Q28)
mean(survey2[survey2$albanian==0,]$Q28)
mean(survey2[survey2$albanian==1,]$Q28)






#Correlation between descriptive and substantive factors
cor(survey2$hiring_ethnicity,survey2$employee_ethnicity)
table(survey2$hiring_ethnicity,survey2$employee_ethnicity)
table(survey2[survey2$albanian==0,]$hiring_ethnicity,survey2[survey2$albanian==0,]$employee_ethnicity)
table(survey2[survey2$albanian==1,]$hiring_ethnicity,survey2[survey2$albanian==1,]$employee_ethnicity)
cor(survey2[survey2$albanian==0,]$hiring_ethnicity,survey2[survey2$albanian==0,]$employee_ethnicity)
cor(survey2[survey2$albanian==1,]$hiring_ethnicity,survey2[survey2$albanian==1,]$employee_ethnicity)


cor(survey2$ministerfinancial,survey2$ministerconcerns)
table(survey2$ministerfinancial,survey2$ministerconcerns)
table(survey2[survey2$albanian==0,]$ministerfinancial,survey2[survey2$albanian==0,]$ministerconcerns)
table(survey2[survey2$albanian==1,]$ministerfinancial,survey2[survey2$albanian==1,]$ministerconcerns)
cor(survey2[survey2$albanian==0,]$ministerfinancial,survey2[survey2$albanian==0,]$ministerconcerns)
cor(survey2[survey2$albanian==1,]$ministerfinancial,survey2[survey2$albanian==1,]$ministerconcerns)


cor(survey2$hiring_ethnicity,survey2$ministerfinancial)
cor(survey2$hiring_ethnicity,survey2$ministerconcerns)
cor(survey2$employee_ethnicity,survey2$ministerfinancial)
cor(survey2$employee_ethnicity,survey2$ministerconcerns)



model1<-polr(firstmeeting~hiring_ethnicity+ministerfinancial+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2, Hess=TRUE)
linearHypothesis(model1, "hiring_ethnicity = ministerfinancial")

model1.1<-polr(firstmeeting~hiring_ethnicity+ministerconcerns+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model1.1, "hiring_ethnicity = ministerconcerns")


 model1.2<-polr(firstmeeting~employee_ethnicity+ministerfinancial+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2, Hess=TRUE)
linearHypothesis(model1.2, "employee_ethnicity = ministerfinancial")

model1.3<-polr(firstmeeting~employee_ethnicity+ministerconcerns+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model1.3, "employee_ethnicity = ministerconcerns")




#Check robustness with linear model
model1.4<-lm(Q27~hiring_ethnicity+ministerfinancial+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2)
(coef1.4<-coeftest(model1.4, vcov=vcovCL(model1.4)))
linearHypothesis(model1.4, "hiring_ethnicity = ministerfinancial")

model1.5<-lm(Q27~hiring_ethnicity+ministerconcerns+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2)
(coef1.5<-coeftest(model1.5, vcov=vcovCL(model1.5)))
linearHypothesis(model1.5, "hiring_ethnicity = ministerconcerns")

model1.6<-lm(Q27~employee_ethnicity+ministerfinancial+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2)
(coef1.6<-coeftest(model1.6, vcov=vcovCL(model1.6)))
linearHypothesis(model1.6, "employee_ethnicity = ministerfinancial")

model1.7<-lm(Q27~employee_ethnicity+ministerconcerns+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2)
(coef1.7<-coeftest(model1.7, vcov=vcovCL(model1.7)))
linearHypothesis(model1.7, "employee_ethnicity = ministerconcerns")


#Second meeting
table(survey2$firstmeeting,survey2$secondmeeting)

model2<-polr(secondmeeting~hiring_ethnicity+ministerfinancial+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2, Hess=TRUE)
linearHypothesis(model2, "hiring_ethnicity = ministerfinancial")

model2.1<-polr(secondmeeting~hiring_ethnicity+ministerconcerns+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model2.1, "hiring_ethnicity = ministerconcerns")

model2.2<-polr(secondmeeting~employee_ethnicity+ministerfinancial+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model2.2, "employee_ethnicity = ministerfinancial")

model2.3<-polr(secondmeeting~employee_ethnicity+ministerconcerns+albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model2.3, "employee_ethnicity = ministerconcerns")


#Check robustness with linear model
model2.4<-lm(Q28~hiring_ethnicity+ministerfinancial+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2)
(coef2.4<-coeftest(model2.4, vcov=vcovCL(model2.4)))
linearHypothesis(model2.4, "hiring_ethnicity = ministerfinancial")

model2.5<-lm(Q28~hiring_ethnicity+ministerconcerns+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2)
(coef2.5<-coeftest(model2.5, vcov=vcovCL(model2.5)))
linearHypothesis(model2.5, "hiring_ethnicity = ministerconcerns")

model2.6<-lm(Q28~employee_ethnicity+ministerfinancial+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2)
(coef2.6<-coeftest(model2.6, vcov=vcovCL(model2.6)))
linearHypothesis(model2.6, "employee_ethnicity = ministerfinancial")

model2.7<-lm(Q28~employee_ethnicity+ministerconcerns+albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2)
(coef2.7<-coeftest(model2.7, vcov=vcovCL(model2.7)))
linearHypothesis(model2.7, "employee_ethnicity = ministerconcerns")

#Table SI.3.1
stargazer(model1, model1.1, model1.2, model1.3, model2, model2.1, model2.2, model2.3)

#Table SI.3.2
stargazer(model1.4, model1.5, model1.6, model1.7, model2.4, model2.5, model2.6, model2.7,
          se=list(coef1.4[,2], coef1.5[,2], coef1.6[,2], coef1.7[,2],
                  coef2.4[,2], coef2.5[,2], coef2.6[,2], coef2.7[,2]))














##Macedonians only
survey2$ProfileNumberOne<-ifelse(survey2$ProfileNumber==1,1,0)
survey2$ProfileNumberSix<-ifelse(survey2$ProfileNumber==6,1,0)
survey2$ProfileNumberTen<-ifelse(survey2$ProfileNumber==10,1,0)
survey2$region4<-ifelse(survey2$region==4,1,0)


model3.0<-polr(firstmeeting~hiring_ethnicity+ministerfinancial
             +ProfileNumberOne+ProfileNumberSix+ProfileNumberTen
             +ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region2+region3+region4+urban
             +news+equalopportunity+authoritarian+knowledge+cabinet_culture+
               cabinet_welfare+cabinet_international, 
             survey2[survey2$albanian==0,], Hess=T)

newdat <- data.frame(
  hiring_ethnicity=mean(model3.0$model$hiring_ethnicity),
  ministerfinancial=c(1:5),
  ProfileNumberOne=mean(model3.0$model$ProfileNumberOne),
  ProfileNumberSix=mean(model3.0$model$ProfileNumberSix),
  ProfileNumberTen=mean(model3.0$model$ProfileNumberTen),
  ProfileSDSM=mean(model3.0$model$ProfileSDSM),
  ProfileSubstantive=mean(model3.0$model$ProfileSubstantive),
  ProfileCooperation=mean(model3.0$model$ProfileCooperation),
  female=mean(model3.0$model$female),
  age=mean(model3.0$model$age),
  married=mean(model3.0$model$married),
  education=mean(model3.0$model$education),
  householdsize=mean(model3.0$model$householdsize),
  region2=mean(model3.0$model$region2),
  region3=mean(model3.0$model$region3),
  region4=mean(model3.0$model$region4),
  urban=mean(model3.0$model$urban),
  news=mean(model3.0$model$news),
  equalopportunity=mean(model3.0$model$equalopportunity),
  authoritarian=mean(model3.0$model$authoritarian),
  knowledge=mean(model3.0$model$knowledge),
  cabinet_culture=mean(model3.0$model$cabinet_culture),
  cabinet_welfare=mean(model3.0$model$cabinet_welfare),
  cabinet_international=mean(model3.0$model$cabinet_international)
)
(phat <- predict(object = model3.0, newdat, type="p"))
#IQR is 5-3=2
summary(survey2[survey2$albanian==0,]$ministerfinancial)
#Subtract row 5-3
phat[5,]-phat[3,]

model3<-polr(firstmeeting~hiring_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3, "hiring_ethnicity = ministerfinancial")


model3.1<-polr(firstmeeting~hiring_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.1, "hiring_ethnicity = ministerconcerns")

model3.2<-polr(firstmeeting~employee_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.2, "employee_ethnicity = ministerfinancial")

model3.3<-polr(firstmeeting~employee_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.3, "employee_ethnicity = ministerconcerns")



model3.4<-polr(secondmeeting~hiring_ethnicity+ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.4, "hiring_ethnicity = ministerfinancial")

model3.5<-polr(secondmeeting~hiring_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.5, "hiring_ethnicity = ministerconcerns")

model3.6<-polr(secondmeeting~employee_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.6, "employee_ethnicity = ministerfinancial")

model3.7<-polr(secondmeeting~employee_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.7, "employee_ethnicity = ministerconcerns")

#Table SI.3.3
stargazer(model3, model3.1, model3.2, model3.3, model3.4, model3.5, model3.6, model3.7)



#Albanian only
model3.0<-polr(firstmeeting~hiring_ethnicity+ministerfinancial
               +ProfileNumberOne+ProfileNumberSix+ProfileNumberTen
               +ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+region4+urban
               +news+equalopportunity+authoritarian+knowledge+cabinet_culture+
                 cabinet_welfare+cabinet_international, 
               survey2[survey2$albanian==1,], Hess=T)
linearHypothesis(model3.0, "hiring_ethnicity = ministerfinancial")

newdat <- data.frame(
  hiring_ethnicity=c(1:5),
  ministerfinancial=mean(model3.0$model$ministerfinancial),
  ProfileNumberOne=mean(model3.0$model$ProfileNumberOne),
  ProfileNumberSix=mean(model3.0$model$ProfileNumberSix),
  ProfileNumberTen=mean(model3.0$model$ProfileNumberTen),
  ProfileSDSM=mean(model3.0$model$ProfileSDSM),
  ProfileSubstantive=mean(model3.0$model$ProfileSubstantive),
  ProfileCooperation=mean(model3.0$model$ProfileCooperation),
  female=mean(model3.0$model$female),
  age=mean(model3.0$model$age),
  married=mean(model3.0$model$married),
  education=mean(model3.0$model$education),
  householdsize=mean(model3.0$model$householdsize),
  region2=mean(model3.0$model$region2),
  region3=mean(model3.0$model$region3),
  region4=mean(model3.0$model$region4),
  urban=mean(model3.0$model$urban),
  news=mean(model3.0$model$news),
  equalopportunity=mean(model3.0$model$equalopportunity),
  authoritarian=mean(model3.0$model$authoritarian),
  knowledge=mean(model3.0$model$knowledge),
  cabinet_culture=mean(model3.0$model$cabinet_culture),
  cabinet_welfare=mean(model3.0$model$cabinet_welfare),
  cabinet_international=mean(model3.0$model$cabinet_international)
)
(phat <- predict(object = model3.0, newdat, type="p"))
#IQR is 5-3=2
summary(survey2[survey2$albanian==1,]$ministerfinancial)
#Subtract row 5-3
phat[5,]-phat[3,]


model4<-polr(firstmeeting~hiring_ethnicity+ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4, "hiring_ethnicity = ministerfinancial")

model4.1<-polr(firstmeeting~hiring_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.1, "hiring_ethnicity = ministerconcerns")

model4.2<-polr(firstmeeting~employee_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.2, "employee_ethnicity = ministerfinancial")

model4.3<-polr(firstmeeting~employee_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.3, "employee_ethnicity = ministerconcerns")


model4.4<-polr(secondmeeting~hiring_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.4, "hiring_ethnicity = ministerfinancial")

model4.5<-polr(secondmeeting~hiring_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.5, "hiring_ethnicity = ministerconcerns")

model4.6<-polr(secondmeeting~employee_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.6, "employee_ethnicity = ministerfinancial")

model4.7<-polr(secondmeeting~employee_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model4.7, "employee_ethnicity = ministerconcerns")

#Table SI.3.4
stargazer(model4, model4.1, model4.2, model4.3, model4.4, model4.5, model4.6, model4.7)



#Both
model5<-polr(firstmeeting~hiring_ethnicity*albanian+ministerfinancial*albanian
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2, Hess=TRUE)
linearHypothesis(model5, "hiring_ethnicity = ministerfinancial")

model5.1<-polr(firstmeeting~hiring_ethnicity*albanian+ministerconcerns*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.1, "hiring_ethnicity = ministerconcerns")

model5.2<-polr(firstmeeting~employee_ethnicity*albanian+ministerfinancial*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.2, "employee_ethnicity = ministerfinancial")

model5.3<-polr(firstmeeting~employee_ethnicity*albanian+ministerconcerns*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.3, "employee_ethnicity = ministerconcerns")


model5.4<-polr(secondmeeting~hiring_ethnicity*albanian+ministerfinancial*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.4, "hiring_ethnicity = ministerfinancial")

model5.5<-polr(secondmeeting~hiring_ethnicity*albanian+ministerconcerns*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.5, "hiring_ethnicity = ministerconcerns")

model5.6<-polr(secondmeeting~employee_ethnicity*albanian+ministerfinancial*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.6, "employee_ethnicity = ministerfinancial")

model5.7<-polr(secondmeeting~employee_ethnicity*albanian+ministerconcerns*albanian
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2, Hess=TRUE)
linearHypothesis(model5.7, "employee_ethnicity = ministerconcerns")

#Table SI.3.5
stargazer(model5, model5.1, model5.2, model5.3, model5.4, model5.5, model5.6, model5.7)




###Normalized models and plots

marginal<-data.frame()

model6<-lm(firstmeeting_n~hiring_ethnicity+ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==0,])
(coef6<-coeftest(model6, vcov=vcovCL(model6)))
marginal_temp<-as.data.frame(summary(margins::margins(model6, 
                                                      variables=c("hiring_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model6))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)



model6.1<-lm(firstmeeting_n~hiring_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.1<-coeftest(model6.1, vcov=vcovCL(model6.1)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.1, 
                                                      variables=c("hiring_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model6.1))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model6.2<-lm(firstmeeting_n~employee_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.2<-coeftest(model6.2, vcov=vcovCL(model6.2)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.2, 
                                                      variables=c("employee_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model6.2))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model6.3<-lm(firstmeeting_n~employee_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.3<-coeftest(model6.3, vcov=vcovCL(model6.3)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.3, 
                                                      variables=c("employee_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model6.3))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)



model6.4<-lm(secondmeeting_n~hiring_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.4<-coeftest(model6.4, vcov=vcovCL(model6.4)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.4, 
                                                      variables=c("hiring_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model6.4))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model6.5<-lm(secondmeeting_n~hiring_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.5<-coeftest(model6.5, vcov=vcovCL(model6.5)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.5, 
                                                      variables=c("hiring_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model6.5))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model6.6<-lm(secondmeeting_n~employee_ethnicity+ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.6<-coeftest(model6.6, vcov=vcovCL(model6.6)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.6, 
                                                      variables=c("employee_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model6.6))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model6.7<-lm(secondmeeting_n~employee_ethnicity+ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,])
(coef6.7<-coeftest(model6.7, vcov=vcovCL(model6.7)))
marginal_temp<-as.data.frame(summary(margins::margins(model6.7, 
                                                      variables=c("employee_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model6.7))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model7<-lm(firstmeeting_n~hiring_ethnicity+ministerfinancial
           +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
           +female+age+married+education+householdsize+region+urban
           +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
           survey2[survey2$albanian==1,])
(coef7<-coeftest(model7, vcov=vcovCL(model7)))
marginal_temp<-as.data.frame(summary(margins::margins(model7, 
                                                      variables=c("hiring_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model7))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)



model7.1<-lm(firstmeeting_n~hiring_ethnicity+ministerconcerns
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.1<-coeftest(model7.1, vcov=vcovCL(model7.1)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.1, 
                                                      variables=c("hiring_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model7.1))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model7.2<-lm(firstmeeting_n~employee_ethnicity+ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.2<-coeftest(model7.2, vcov=vcovCL(model7.2)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.2, 
                                                      variables=c("employee_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model7.2))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model7.3<-lm(firstmeeting_n~employee_ethnicity+ministerconcerns
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.3<-coeftest(model7.3, vcov=vcovCL(model7.3)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.3, 
                                                      variables=c("employee_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model7.3))))
marginal_temp$dv<-"firstmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)



model7.4<-lm(secondmeeting_n~hiring_ethnicity+ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.4<-coeftest(model7.4, vcov=vcovCL(model7.4)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.4, 
                                                      variables=c("hiring_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model7.4))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model7.5<-lm(secondmeeting_n~hiring_ethnicity+ministerconcerns
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.5<-coeftest(model7.5, vcov=vcovCL(model7.5)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.5, 
                                                      variables=c("hiring_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model7.5))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model7.6<-lm(secondmeeting_n~employee_ethnicity+ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.6<-coeftest(model7.6, vcov=vcovCL(model7.6)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.6, 
                                                      variables=c("employee_ethnicity","ministerfinancial"), 
                                                      vcov=vcovCL(model7.6))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model7.7<-lm(secondmeeting_n~employee_ethnicity+ministerconcerns
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,])
(coef7.7<-coeftest(model7.7, vcov=vcovCL(model7.7)))
marginal_temp<-as.data.frame(summary(margins::margins(model7.7, 
                                                      variables=c("employee_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model7.7))))
marginal_temp$dv<-"secondmeeting"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

#save(marginal, file="marginal.RData")


#Table SI.2.1
stargazer(model6, model6.1, model6.2, model6.3, model6.4, model6.5, model6.6, model6.7,
          se=list(coef6[,2], coef6.1[,2], coef6.2[,2], coef6.3[,2], coef6.4[,2],
                  coef6.5[,2], coef6.6[,2], coef6.7[,2]))


#Table SI.2.2
stargazer(model7, model7.1, model7.2, model7.3, model7.4, model7.5, model7.6, model7.7,
          se=list(coef7[,2], coef7.1[,2], coef7.2[,2], coef7.3[,2], coef7.4[,2],
                  coef7.5[,2], coef7.6[,2], coef7.7[,2]))




load("marginal.RData")

#Figure SI.2.1
#Display plots of the substantive representation variable with Hiring
marginal1<-marginal[c(1,2,4,5,9,10,12,13,17,18,20,21,25,26,28,29),]
rownames(marginal1)<-NULL

marginal1$dv <- factor(marginal1$dv, levels = c("secondmeeting", "firstmeeting"),
                       labels = c("1st", "2nd"))
marginal1$factor<-factor(marginal1$factor,levels = c("ministerconcerns","ministerfinancial", "employee_ethnicity",
                                                     "hiring_ethnicity"),
                         labels=c("Concerns", "Financial", "Employee", "Hiring"))
marginal1$type<-c(rep("MAC", 8), rep("ALB", 8))
marginal1$type<-factor(marginal1$type, levels=c("MAC", "ALB"))


marginal1_1 <- ggplot(data=marginal1, aes(factor, AME, color = type, linetype=type,
                                          group = type, shape = type)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()+
  facet_wrap(~dv, strip.position = "top", scales = "free_y")

marginal1_2 <- marginal1_1 + geom_linerange(data=marginal1, 
                                            aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="Estimate") + 
  coord_flip(ylim = c(-0.11, 0.11)) +  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=12)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 12))+
  labs(color  = "", linetype = "", shape = "")+
  scale_linetype_manual( values= c("solid", "solid"))+
  scale_colour_manual(values = c("black", "orange3"))+
  scale_shape_manual( values = c(17,16))
marginal1_2



#Figure 1
#First meeting only
#Display plots of the substantive representation variable with Hiring
marginal1<-marginal[c(1,2,4,5,9,10,12,13,17,18,20,21,25,26,28,29),]
rownames(marginal1)<-NULL
marginal1<-marginal1[c(1:4, 9:12),]
rownames(marginal1)<-NULL

marginal1$dv <- factor(marginal1$dv, levels = c("firstmeeting"),
                       labels = c("1st"))
marginal1$factor<-factor(marginal1$factor,levels = c("ministerconcerns","ministerfinancial", "employee_ethnicity",
                                                     "hiring_ethnicity"),
                         labels=c("Concerns", "Financial", "Employee", "Hiring"))
marginal1$type<-c(rep("MAC", 4), rep("ALB", 4))
marginal1$type<-factor(marginal1$type, levels=c("MAC", "ALB"))


marginal1_1 <- ggplot(data=marginal1, aes(factor, AME, color = type, linetype=type,
                                          group = type, shape = type)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()


marginal1_2 <- marginal1_1 + geom_linerange(data=marginal1, 
                                            aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="Estimate") + 
  coord_flip(ylim = c(-0.11, 0.11)) +  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=12)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 12))+
  labs(color  = "", linetype = "", shape = "")+
  scale_linetype_manual( values= c("solid", "solid"))+
  scale_colour_manual(values = c("black", "orange3"))+
  scale_shape_manual( values = c(17,16))
marginal1_2





###Interaction
survey2alb<-survey2[survey2$albanian==1,]
cor(survey2alb$hiring_ethnicity, survey2alb$ministerconcerns)
cor(survey2alb$hiring_ethnicity, survey2alb$ministerfinancial)
cor(survey2alb$employee_ethnicity, survey2alb$ministerfinancial)
cor(survey2alb$employee_ethnicity, survey2alb$ministerconcerns)

1-sum(diag(table(survey2alb$hiring_ethnicity, survey2alb$ministerconcerns)))/392
1-sum(diag(table(survey2alb$hiring_ethnicity, survey2alb$ministerfinancial)))/392
1-sum(diag(table(survey2alb$employee_ethnicity, survey2alb$ministerfinancial)))/392
1-sum(diag(table(survey2alb$employee_ethnicity, survey2alb$ministerconcerns)))/392

mean(survey2alb$hiring_ethnicity)
mean(survey2alb$employee_ethnicity)
mean(survey2alb$ministerconcerns)
mean(survey2alb$ministerfinancial)


#Macedonians
survey2mac<-survey2[survey2$albanian==0,]
cor(survey2mac$hiring_ethnicity, survey2mac$ministerconcerns)
cor(survey2mac$hiring_ethnicity, survey2mac$ministerfinancial)
cor(survey2mac$employee_ethnicity, survey2mac$ministerfinancial)
cor(survey2mac$employee_ethnicity, survey2mac$ministerconcerns)


1-sum(diag(table(survey2mac$hiring_ethnicity, survey2mac$ministerconcerns)))/392
1-sum(diag(table(survey2mac$hiring_ethnicity, survey2mac$ministerfinancial)))/392
1-sum(diag(table(survey2mac$employee_ethnicity, survey2mac$ministerfinancial)))/392
1-sum(diag(table(survey2mac$employee_ethnicity, survey2mac$ministerconcerns)))/392

mean(survey2mac$hiring_ethnicity)
mean(survey2mac$employee_ethnicity)
mean(survey2mac$ministerconcerns)
mean(survey2mac$ministerfinancial)




#Macedonian only
model8<-polr(firstmeeting~hiring_ethnicity*ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==0,], Hess=TRUE)

model8.1<-polr(firstmeeting~hiring_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.2<-polr(firstmeeting~employee_ethnicity*ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.3<-polr(firstmeeting~employee_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)


model8.4<-polr(secondmeeting~hiring_ethnicity*ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.5<-polr(secondmeeting~hiring_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.6<-polr(secondmeeting~employee_ethnicity*ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.7<-polr(secondmeeting~employee_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==0,], Hess=TRUE)

#Table SI.4.1
stargazer(model8, model8.1, model8.2, model8.3, model8.4, model8.5, model8.6, model8.7)



#Albanian only
model9<-polr(firstmeeting~hiring_ethnicity*ministerfinancial
             +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
             survey2[survey2$albanian==1,], Hess=TRUE)

model9.1<-polr(firstmeeting~hiring_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)

model9.2<-polr(firstmeeting~employee_ethnicity*ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)

model9.3<-polr(firstmeeting~employee_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)


model9.4<-polr(secondmeeting~hiring_ethnicity*ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)

model9.5<-polr(secondmeeting~hiring_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)

model9.6<-polr(secondmeeting~employee_ethnicity*ministerfinancial
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)

model9.7<-polr(secondmeeting~employee_ethnicity*ministerconcerns
               +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
               survey2[survey2$albanian==1,], Hess=TRUE)

#Table SI.4.2
stargazer(model9, model9.1, model9.2, model9.3, model9.4, model9.5, model9.6, model9.7)



#Linear models
#Macedonian OLS
model10<-lm(firstmeeting_n~hiring_ethnicity*ministerfinancial
            +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
            +female+age+married+education+householdsize+region+urban
            +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
            survey2[survey2$albanian==0,])
(coef10<-coeftest(model10, vcov=vcovCL(model10)))


model10.1<-lm(firstmeeting_n~hiring_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.1<-coeftest(model10.1, vcov=vcovCL(model10.1)))


model10.2<-lm(firstmeeting_n~employee_ethnicity*ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.2<-coeftest(model10.2, vcov=vcovCL(model10.2)))


model10.3<-lm(firstmeeting_n~employee_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.3<-coeftest(model10.3, vcov=vcovCL(model10.3)))



model10.4<-lm(secondmeeting_n~hiring_ethnicity*ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.4<-coeftest(model10.4, vcov=vcovCL(model10.4)))


model10.5<-lm(secondmeeting_n~hiring_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.5<-coeftest(model10.5, vcov=vcovCL(model10.5)))


model10.6<-lm(secondmeeting_n~employee_ethnicity*ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.6<-coeftest(model10.6, vcov=vcovCL(model10.6)))


model10.7<-lm(secondmeeting_n~employee_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==0,])
(coef10.7<-coeftest(model10.7, vcov=vcovCL(model10.7)))


model11<-lm(firstmeeting_n~hiring_ethnicity*ministerfinancial
            +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
            +female+age+married+education+householdsize+region+urban
            +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
            survey2[survey2$albanian==1,])
(coef11<-coeftest(model11, vcov=vcovCL(model11)))



#Albanian OLS
model11.1<-lm(firstmeeting_n~hiring_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.1<-coeftest(model11.1, vcov=vcovCL(model11.1)))
marginal_temp<-as.data.frame(summary(margins::margins(model11.1, 
                                                      variables=c("hiring_ethnicity","ministerconcerns"), 
                                                      vcov=vcovCL(model11.1))))


model11.2<-lm(firstmeeting_n~employee_ethnicity*ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.2<-coeftest(model11.2, vcov=vcovCL(model11.2)))



model11.3<-lm(firstmeeting_n~employee_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.3<-coeftest(model11.3, vcov=vcovCL(model11.3)))



model11.4<-lm(secondmeeting_n~hiring_ethnicity*ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.4<-coeftest(model11.4, vcov=vcovCL(model11.4)))


model11.5<-lm(secondmeeting_n~hiring_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.5<-coeftest(model11.5, vcov=vcovCL(model11.5)))


model11.6<-lm(secondmeeting_n~employee_ethnicity*ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.6<-coeftest(model11.6, vcov=vcovCL(model11.6)))


model11.7<-lm(secondmeeting_n~employee_ethnicity*ministerconcerns
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetcoded, 
              survey2[survey2$albanian==1,])
(coef11.7<-coeftest(model11.7, vcov=vcovCL(model11.7)))


#Table SI.4.3
stargazer(model10, model10.1, model10.2, model10.3, model10.4, model10.5, model10.6, model10.7,
          se=list(coef10[,2], coef10.1[,2], coef10.2[,2], coef10.3[,2], coef10.4[,2],
                  coef10.5[,2], coef10.6[,2], coef10.7[,2]))


#Table SI.4.4
stargazer(model11, model11.1, model11.2, model11.3, model11.4, model11.5, model11.6, model11.7,
          se=list(coef11[,2], coef11.1[,2], coef11.2[,2], coef11.3[,2], coef11.4[,2],
                  coef11.5[,2], coef11.6[,2], coef11.7[,2]))



source("interaction_plots.R")
par(mar=c(5.1, 4.3, 4.1, 2.1))

#Figure 2
interaction_plot_factor(model11.1, effect="hiring_ethnicity", moderator="ministerconcerns", interaction="hiring_ethnicity:ministerconcerns", 
                             conf=0.95, xlab='Concerns', ylab='Marginal Effect of Hiring',
                            title='Albanian Meeting Attendance')

#Plot of the other interaction
#Figure SI.4.1
interaction_plot_factor(model11.1, moderator="hiring_ethnicity", effect="ministerconcerns", interaction="hiring_ethnicity:ministerconcerns", 
                        conf=0.95, ylab='Marginal Effect of Concerns', xlab='Hiring',
                        title='Albanian Meeting Attendance')



###Descriptive Statistics
survey2$ProfileNumberZero<-ifelse(survey2$ProfileNumber=="0",1,0)
survey2$region3<-ifelse(survey2$region3=="9", 0, 1)

attach(survey2)
data_summary<-as.data.frame(cbind(firstmeeting_n, secondmeeting_n, employee_ethnicity, hiring_ethnicity,
                                  ministerconcerns, ministerfinancial, cabinet_culture, cabinet_economy,
                                  cabinet_welfare, cabinet_international, female, age, married, education, 
                                  householdsize, Skopje, region2, region3, region4, urban,
                                  news, equalopportunity, authoritarian, knowledge,
                                  ProfileNumberZero, ProfileNumberOne, ProfileNumberSix, ProfileNumberTen, 
                                  ProfileSDSM, ProfileSubstantive, ProfileCooperation))

detach(survey2)

survey2alb<-survey2[survey2$albanian==1,]
attach(survey2alb)
data_summaryalb<-as.data.frame(cbind(firstmeeting_n, secondmeeting_n, employee_ethnicity, hiring_ethnicity,
                                  ministerconcerns, ministerfinancial, cabinet_culture, cabinet_economy,
                                  cabinet_welfare, cabinet_international, female, age, married, education, 
                                  householdsize, Skopje, region2, region3, region4, urban,
                                  news, equalopportunity, authoritarian, knowledge,
                                  ProfileNumberZero, ProfileNumberOne, ProfileNumberSix, ProfileNumberTen, 
                                  ProfileSDSM, ProfileSubstantive, ProfileCooperation))

detach(survey2alb)


survey2mac<-survey2[survey2$albanian==0,]
attach(survey2mac)
data_summarymac<-as.data.frame(cbind(firstmeeting_n, secondmeeting_n, employee_ethnicity, hiring_ethnicity,
                                     ministerconcerns, ministerfinancial, cabinet_culture, cabinet_economy,
                                     cabinet_welfare, cabinet_international, female, age, married, education, 
                                     householdsize, Skopje, region2, region3, region4, urban,
                                     news, equalopportunity, authoritarian, knowledge,
                                     ProfileNumberZero, ProfileNumberOne, ProfileNumberSix, ProfileNumberTen, 
                                     ProfileSDSM, ProfileSubstantive, ProfileCooperation))

detach(survey2mac)




data_summary2<-as.data.frame(matrix(nrow=31, ncol=6))
for(i in 1:31){
  data_summary2[i,1]<-names(data_summary)[i]
  data_summary2[i,2]<-min(data_summary[,i], na.rm=T)
  data_summary2[i,3]<-max(data_summary[,i], na.rm=T)
  data_summary2[i,4]<-sqrt(var(data_summary[,i], na.rm=T))
  data_summary2[i,5]<-mean(data_summary[,i], na.rm=T)
  data_summary2[i,6]<-median(data_summary[,i], na.rm=T)
}
colnames(data_summary2)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")

library(xtable)
#print(xtable(data_summary2, type='latex', digits=2), file='data_summary2.tex', include.rownames=FALSE)


#Albanians
data_summary2alb<-as.data.frame(matrix(nrow=31, ncol=6))
for(i in 1:31){
  data_summary2alb[i,1]<-names(data_summaryalb)[i]
  data_summary2alb[i,2]<-min(data_summaryalb[,i], na.rm=T)
  data_summary2alb[i,3]<-max(data_summaryalb[,i], na.rm=T)
  data_summary2alb[i,4]<-sqrt(var(data_summaryalb[,i], na.rm=T))
  data_summary2alb[i,5]<-mean(data_summaryalb[,i], na.rm=T)
  data_summary2alb[i,6]<-median(data_summaryalb[,i], na.rm=T)
}
colnames(data_summary2alb)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")


#print(xtable(data_summary2alb, type='latex', digits=2), file='data_summary2albanian.tex', include.rownames=FALSE)


data_summary2mac<-as.data.frame(matrix(nrow=31, ncol=6))
for(i in 1:31){
  data_summary2mac[i,1]<-names(data_summarymac)[i]
  data_summary2mac[i,2]<-min(data_summarymac[,i], na.rm=T)
  data_summary2mac[i,3]<-max(data_summarymac[,i], na.rm=T)
  data_summary2mac[i,4]<-sqrt(var(data_summarymac[,i], na.rm=T))
  data_summary2mac[i,5]<-mean(data_summarymac[,i], na.rm=T)
  data_summary2mac[i,6]<-median(data_summarymac[,i], na.rm=T)
}
colnames(data_summary2mac)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")


#print(xtable(data_summary2mac, type='latex', digits=2), file='data_summary2macedonian.tex', include.rownames=FALSE)

data_summarycombined<-cbind(data_summary2alb[,c(1,5,6)],data_summary2mac[,c(5:6)])
#Table SI.1.2
print(xtable(data_summarycombined, type='latex', digits=2), file='data_summarycombined.tex', include.rownames=FALSE)

#Table 1
t.test(survey2[survey2$albanian==0,]$firstmeeting_n, survey2[survey2$albanian==1,]$firstmeeting_n)
t.test(survey2[survey2$albanian==0,]$secondmeeting_n, survey2[survey2$albanian==1,]$secondmeeting_n)

t.test(survey2[survey2$albanian==1,]$firstmeeting_n, survey2[survey2$albanian==1,]$secondmeeting_n, paired=T)
t.test(survey2[survey2$albanian==0,]$firstmeeting_n, survey2[survey2$albanian==0,]$secondmeeting_n, paired=T)

t.test(survey2[survey2$albanian==0,]$employee_ethnicity, survey2[survey2$albanian==1,]$employee_ethnicity)
t.test(survey2[survey2$albanian==0,]$hiring_ethnicity, survey2[survey2$albanian==1,]$hiring_ethnicity)
t.test(survey2[survey2$albanian==0,]$ministerconcerns, survey2[survey2$albanian==1,]$ministerconcerns)
t.test(survey2[survey2$albanian==0,]$ministerfinancial, survey2[survey2$albanian==1,]$ministerfinancial)


t.test(survey2[survey2$albanian==1,]$employee_ethnicity, survey2[survey2$albanian==1,]$hiring_ethnicity, paired=T)
t.test(survey2[survey2$albanian==1,]$employee_ethnicity, survey2[survey2$albanian==1,]$ministerconcerns, paired=T)
t.test(survey2[survey2$albanian==1,]$employee_ethnicity, survey2[survey2$albanian==1,]$ministerfinancial, paired=T)
t.test(survey2[survey2$albanian==1,]$hiring_ethnicity, survey2[survey2$albanian==1,]$ministerconcerns, paired=T)
t.test(survey2[survey2$albanian==1,]$hiring_ethnicity, survey2[survey2$albanian==1,]$ministerfinancial, paired=T)
t.test(survey2[survey2$albanian==1,]$ministerconcerns, survey2[survey2$albanian==1,]$ministerfinancial, paired=T)

t.test(survey2[survey2$albanian==0,]$employee_ethnicity, survey2[survey2$albanian==0,]$hiring_ethnicity, paired=T)
t.test(survey2[survey2$albanian==0,]$employee_ethnicity, survey2[survey2$albanian==0,]$ministerconcerns, paired=T)
t.test(survey2[survey2$albanian==0,]$employee_ethnicity, survey2[survey2$albanian==0,]$ministerfinancial, paired=T)
t.test(survey2[survey2$albanian==0,]$hiring_ethnicity, survey2[survey2$albanian==0,]$ministerconcerns, paired=T)
t.test(survey2[survey2$albanian==0,]$hiring_ethnicity, survey2[survey2$albanian==0,]$ministerfinancial, paired=T)
t.test(survey2[survey2$albanian==0,]$ministerconcerns, survey2[survey2$albanian==0,]$ministerfinancial, paired=T)




###Check with Albanian cabinet ministers
model13<-polr(firstmeeting~hiring_ethnicity+ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
              survey2[survey2$albanian==0,], Hess=TRUE)

model13.1<-polr(firstmeeting~hiring_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)

model13.2<-polr(firstmeeting~employee_ethnicity+ministerfinancial
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)

model13.3<-polr(firstmeeting~employee_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)


model13.4<-polr(secondmeeting~hiring_ethnicity+ministerfinancial
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)

model13.5<-polr(secondmeeting~hiring_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)

model13.6<-polr(secondmeeting~employee_ethnicity+ministerfinancial
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)

model13.7<-polr(secondmeeting~employee_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==0,], Hess=TRUE)

#Table SI.3.6
stargazer(model13, model13.1, model13.2, model13.3, model13.4, model13.5, model13.6, model13.7)



#Albanian only
model14<-polr(firstmeeting~hiring_ethnicity+ministerfinancial
              +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
              survey2[survey2$albanian==1,], Hess=TRUE)

model14.1<-polr(firstmeeting~hiring_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)

model14.2<-polr(firstmeeting~employee_ethnicity+ministerfinancial
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)

model14.3<-polr(firstmeeting~employee_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)


model14.4<-polr(secondmeeting~hiring_ethnicity+ministerfinancial
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)

model14.5<-polr(secondmeeting~hiring_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)

model14.6<-polr(secondmeeting~employee_ethnicity+ministerfinancial
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)

model14.7<-polr(secondmeeting~employee_ethnicity+ministerconcerns
                +ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge+cabinetalbanian, 
                survey2[survey2$albanian==1,], Hess=TRUE)

#Table SI.3.7
stargazer(model14, model14.1, model14.2, model14.3, model14.4, model14.5, model14.6, model14.7)






