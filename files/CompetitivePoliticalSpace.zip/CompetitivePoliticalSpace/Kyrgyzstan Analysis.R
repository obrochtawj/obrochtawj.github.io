
###################################################################################
###Replication files for: Political Space in Competitive Authoritarian Regimes: ###
###Activating Pro Forma Platforms                                               ###
###William O'Brochta and Norman Schofield                                       ###
###Washington University in St. Louis                                           ###
###################################################################################

library(Hmisc)
library(foreign)
library(plyr)
library(scales)
library(pryr)
library(readxl)
#################################
#Party Manifesto Position Factor Loadings
#################################
manifesto<-read.csv("Party Manifesto Positions.csv", stringsAsFactors = F, header=T)

manifesto$V228<-as.factor(manifesto$V228)
manifesto[,c(2:ncol(manifesto))] <- 
  lapply(manifesto[,c(2:ncol(manifesto)),drop=FALSE],as.character)
manifesto[,c(2:ncol(manifesto))] <- 
  lapply(manifesto[,c(2:ncol(manifesto)),drop=FALSE],as.numeric)

#Have to load 2003 factor scores first.
manifesto$factor1<-rowSums(manifesto[,c(2:ncol(manifesto))]*model_scores3)
manifesto$factor2<-rowSums(manifesto[,c(2:ncol(manifesto))]*model_scores4)


manifesto_1<-manifesto[1,c(2:ncol(manifesto))]
rowSums(manifesto_1*model_scores3)
manifesto_2<-manifesto[2,c(2:ncol(manifesto))]

model8<-factanal(x=na.omit(manifesto_2), factors=2, rotation='varimax', na.action=na.omit)



##################################
# WVS Questions
##################################
data2011 <- read.spss("WV6_Data_Kyrgyzstan_2011_spss_v_2016-01-01.sav", use.value.labels=F, to.data.frame = TRUE)
data2003<-read.spss("WV4_Data_Kyrgyzstan_2003_spss_v_2015-04-18.sav", use.value.labels = F, to.data.frame=TRUE)

#2011 questions
instanceconvert<-c('V16', 'V19', 'V37', 'V39', 'V41', 'V70',
  'V71', 'V74', 'V79', 'V95', 'V96', 'V97', 
  'V98', 'V103', 'V106', 'V107', 'V115', 'V116',
  'V119', 'V125_07', 'V126', 'V127', 'V130', 
  'V131', 'V132', 'V133', 'V137', 'V140', 'V142',
  'V145', 'V152', 'V153', 'V159', 'V194', 'V202',
  'V203', 'V208', 'V211', 'V213', 'V239', 'V248')

data2011[,instanceconvert] <- 
  lapply(data2011[,instanceconvert,drop=FALSE],as.character)
data2011[,instanceconvert] <- 
  lapply(data2011[,instanceconvert,drop=FALSE],as.numeric)

instanceconvert2<-c('V39', 'V95', 'V96', 'V98',  'V115',
                    'V125_07', 'V126', 'V127', 'V130',
                    'V145', 'V152', 'V202', 'V211', 'V213', 
                    'V239', 'V248')


#2003 questions
instanceconvert3<-c( 'V73', 'V139', 'V141', 'V143', 'V153', 'V160',
                     'V162', 'V164', 'V167', 'V185', 'V196', 'V207',
                     'V216', 'V214', 'V236CS', 'V226')

data2003[,instanceconvert3] <- 
  lapply(data2003[,instanceconvert3,drop=FALSE],as.character)
data2003[,instanceconvert3] <- 
  lapply(data2003[,instanceconvert3,drop=FALSE],as.numeric)

#See text for variable meanings
data2011_subset<-data2011[,instanceconvert2]
data2003_subset<-data2003[,instanceconvert3]

###Table 1
model<-factanal(x=na.omit(data2011_subset), factors=2, rotation='varimax', na.action=na.omit)
model_scores1<-model$loadings[,1]
model_scores2<-model$loadings[,2]
data2011$factor1<-rowSums(data2011[,instanceconvert2]*model_scores1)
data2011$factor2<-rowSums(data2011[,instanceconvert2]*model_scores2)

#Use loadings from 2003.
#Re-run data2003 assignments.
data2011$factor1_2003<-rowSums(data2011[,instanceconvert2]*model_scores3)
data2011$factor2_2003<-rowSums(data2011[,instanceconvert2]*model_scores4)

data2011_1<-data2011[data2011$V228==417001,]
data2011_2<-data2011[data2011$V228==417002,]
data2011_3<-data2011[data2011$V228==417003,]
data2011_4<-data2011[data2011$V228==417004,]


###Figure 1
#Factor 1 on y axis
plot(factor1_2003~factor2_2003, data=data2011[data2011$V228==417001,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Kyrgyzstan 2011', ylab='Distrust of Institutions', xlab='Distrust of Rural Tradition')
legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(20,20,20,20), col=c('red', 'blue', 'purple', 'black'), bty='n')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011[data2011$V228==417002,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011[data2011$V228==417003,], col=alpha('purple',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011[data2011$V228==417004,], col=alpha('black',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2011_1$factor2_2003)),median(na.omit(data2011_1$factor1_2003)), pch=21, col='white', bg='red', cex=2)
points(median(na.omit(data2011_2$factor2_2003)),median(na.omit(data2011_2$factor1_2003)), pch=21, col='white', bg='blue', cex=2)
points(median(na.omit(data2011_3$factor2_2003)),median(na.omit(data2011_3$factor1_2003)), pch=21, col='white', bg='purple', cex=2)
points(median(na.omit(data2011_4$factor2_2003)),median(na.omit(data2011_4$factor1_2003)), pch=21, col='white', bg='black', cex=2)
#(factor 2, factor 1)
points(4.928051,9.164147, pch=22, col='white', bg='red', cex=2)
points(6.000561, 8.020740, pch=22, col='white', bg='blue', cex=2)
points(-1.167975, 12.214012, pch=22, col='white', bg='purple', cex=2)
points(17.094891, -3.372670, pch=22, col='white', bg='black', cex=2)


#Determine distance between voter point and party point overall (valence) and in each dimension
#Factor 1 (voter-party position)
8.872981-9.164147
9.292909-8.020740
7.904369-12.214012
9.871556-(-3.372670)

#Factor 2
6.26332-4.928051
6.159277-6.000561
5.399842-(-1.167975)
6.556771-17.094891

#Valence (sqrt(factor1(voter-party)^2+factor2(voter-party)^2))
sqrt((8.872981-9.164147)^2+(6.26332-4.928051)^2)
sqrt((9.292909-8.020740)^2+(6.159277-6.000561)^2)
sqrt((7.904369-12.214012)^2+(5.399842-(-1.167975))^2)
sqrt((9.871556-(-3.372670))^2+(6.556771-17.094891)^2)


#2011 using 2011 factors
plot(factor1~factor2, data=data2011[data2011$V228==417001,], col=alpha('red',0.5), ylim=c(-2,32), xlim=c(-12,25), main='Vote Dispersion in Kyrgyzstan 2011', ylab='Distrust of Institutions', xlab='Distrust of Rural Tradition')
par(new=T)
plot(factor1~factor2, data=data2011[data2011$V228==417002,], col=alpha('blue',0.5), ylim=c(-2,32), xlim=c(-12,25), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1~factor2, data=data2011[data2011$V228==417003,], col=alpha('green',0.5), ylim=c(-2,32), xlim=c(-12,25), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1~factor2, data=data2011[data2011$V228==417004,], col=alpha('black',0.5), ylim=c(-2,32), xlim=c(-12,25), axes=F, xlab='', ylab='')
points(median(na.omit(data2011_1$factor2)),median(na.omit(data2011_1$factor1)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2011_2$factor2)),median(na.omit(data2011_2$factor1)), pch=21, col='white', bg='blue', cex=1.5)
points(median(na.omit(data2011_3$factor2)),median(na.omit(data2011_3$factor1)), pch=21, col='white', bg='green', cex=1.5)
points(median(na.omit(data2011_4$factor2)),median(na.omit(data2011_4$factor1)), pch=21, col='white', bg='black', cex=1.5)


#For 2003
model2<-factanal(x=na.omit(data2003_subset), factors=2, rotation='varimax', na.action=na.omit)
model_scores3<-model2$loadings[,1]
model_scores4<-model2$loadings[,2]
data2003$factor1<-rowSums(data2003[,instanceconvert3]*model_scores3)
data2003$factor2<-rowSums(data2003[,instanceconvert3]*model_scores4)

data2003$factor1_2011<-rowSums(data2003[,instanceconvert3]*model_scores1)
data2003$factor2_2011<-rowSums(data2003[,instanceconvert3]*model_scores2)

data2003_1<-data2003[data2003$V220==417028,]
data2003_2<-data2003[data2003$V220==417021,]
data2003_3<-data2003[data2003$V220==417018,]
data2003_4<-data2003[data2003$V220==417020,]

###Figure 2
plot(factor1~factor2, data=data2003[data2003$V220==417028,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Kyrgyzstan 2003', ylab='Distrust of Institutions', xlab='Distrust of Rural Tradition')
legend(18, 28, c('Communist', "Women's", 'Ar-Namys', 'Action'), pch=c(20,20,20,20), col=c('red', 'blue', 'purple', 'black'), bty='n')
par(new=T)
plot(factor1~factor2, data=data2003[data2003$V220==417021,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1~factor2, data=data2003[data2003$V220==417018,], col=alpha('purple',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1~factor2, data=data2003[data2003$V220==417020,], col=alpha('black',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2003_1$factor2)),median(na.omit(data2003_1$factor1)), pch=21, col='white', bg='red', cex=2)
points(median(na.omit(data2003_2$factor2)),median(na.omit(data2003_2$factor1)), pch=21, col='white', bg='blue', cex=2)
points(median(na.omit(data2003_3$factor2)),median(na.omit(data2003_3$factor1)), pch=21, col='white', bg='purple', cex=2)
points(median(na.omit(data2003_4$factor2)),median(na.omit(data2003_4$factor1)), pch=21, col='white', bg='black', cex=2)

#Using 2011 factor loadings
plot(factor1_2011~factor2_2011, data=data2003[data2003$V220==417028,], col=alpha('red',0.5), ylim=c(0,20), xlim=c(0,16), main='Vote Dispersion in Kyrgyzstan 2003', ylab='Distrust of Institutions', xlab='Distrust of Rural Tradition')
par(new=T)
plot(factor1_2011~factor2_2011, data=data2003[data2003$V220==417021,], col=alpha('blue',0.5), ylim=c(0,20), xlim=c(0,16), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1_2011~factor2_2011, data=data2003[data2003$V220==417018,], col=alpha('green',0.5), ylim=c(0,20), xlim=c(0,16), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1_2011~factor2_2011, data=data2003[data2003$V220==417020,], col=alpha('black',0.5), ylim=c(0,20), xlim=c(0,16), axes=F, xlab='', ylab='')
points(median(na.omit(data2003_1$factor2_2011)),median(na.omit(data2003_1$factor1_2011)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2003_2$factor2_2011)),median(na.omit(data2003_2$factor1_2011)), pch=21, col='white', bg='blue', cex=1.5)
points(median(na.omit(data2003_3$factor2_2011)),median(na.omit(data2003_3$factor1_2011)), pch=21, col='white', bg='green', cex=1.5)
points(median(na.omit(data2003_4$factor2_2011)),median(na.omit(data2003_4$factor1_2011)), pch=21, col='white', bg='black', cex=1.5)


################################################
###Multinomial Logit Model
################################################
library(nnet)

data2011_5<-data2011[c(data2011$V228==417001 | data2011$V228==417002 |
                         data2011$V228==417003 |data2011$V228==417004),]
data2011_5$Party<-as.factor(data2011_5$V228)
data2011_5$Region<-as.factor(data2011_5$V256)

data2011_5$Party2<-relevel(data2011_5$Party, ref='417001')
model3<-multinom(Party2~factor1_2003+factor2_2003+Region, data=data2011_5)
summary(model3)
z <- summary(model3)$coefficients/summary(model3)$standard.errors
p <- (1 - pnorm(abs(z), 0, 1)) * 2

library(afex)
set_sum_contrasts()
library(car)
#Each variable on its own to see if it is different from zero.
#Find that region is significantly different from zero.
Anova(model3,type="III")

#With any combination of assuming an alternative choice of party, model is the same
#so iia is fulfilled.
data2011_6<-data2011[c(data2011$V228==417001 | data2011$V228==417002 |
                         data2011$V228==417003 |data2011$V228==417004),]
data2011_6$V228<-ifelse(data2011_6$V228==417004, 417002, data2011_6$V228)
data2011_6$Party<-as.factor(data2011_6$V228)
data2011_6$Region<-as.factor(data2011_6$V256)

data2011_6$Party2<-relevel(data2011_6$Party, ref='417002')
model5<-multinom(Party2~factor1_2003+factor2_2003+Region, data=data2011_6)
summary(model5)
z2 <- summary(model5)$coefficients/summary(model5)$standard.errors
p2 <- (1 - pnorm(abs(z), 0, 1)) * 2




data2003_5<-data2003[c(data2003$V220==417028 | data2003$V220==417021 |
                         data2003$V220==417018 |data2003$V220==417020),]
data2003_5$Party<-as.factor(data2003_5$V220)
data2003_5$Region<-as.factor(data2003_5$V243)

data2003_5$Party2<-relevel(data2003_5$Party, ref='417028')
model4<-multinom(Party2~factor1+factor2+Region, data=data2003_5)
summary(model4)
z1 <- summary(model4)$coefficients/summary(model4)$standard.errors
p1 <- (1 - pnorm(abs(z1), 0, 1)) * 2

Anova(model4,type="III")


#Nested Multinomial Logit
library(mlogit)

#No variables are significant in the nested logit model. Use Hausman to reject IIA
#meaning the nested model is preferred.
#All variables are individual specific, so go after the |.
data2011_7<-data2011_5[,c('factor1_2003','factor2_2003', 'Party', 'Region', 'V240', 'V242' )]
data2011_7$index<-seq(1,nrow(data2011_7), by=1)
data2011_7$V240<-as.factor(data2011_7$V240)
data2011_7<-data2011_7[complete.cases(data2011_7),]
data2011_mlogit<-mlogit.data(data2011_7, choice="Party", shape='wide')
model5<-mlogit(Party~1|factor1_2003+factor2_2003+Region+V240+V242, data=data2011_mlogit)
model6<-mlogit(Party~1|factor1_2003+factor2_2003+Region+V240+V242, data=data2011_mlogit, alt.subset=c('417002', '417003', '417004'))
hmftest(model5, model6)

#With un.nest.el=T, model11 has more exchange between nests than within a nest.
model7<-mlogit(Party~1|factor1_2003+factor2_2003+Region+V240+V242, data=data2011_mlogit, nests=list(All=c('417001', '417002', '417003', '417004'), Major=c('417001', '417002')), un.nest.el=F)
model11<-mlogit(Party~1|factor1_2003+factor2_2003+Region+V240+V242, data=data2011_mlogit, nests=list(Left=c('417001', '417004'),  Right=c('417003', '417002')), un.nest.el=F)
#Log likelihood is least negative here compared to 7, so this is probably the best model.
model12<-mlogit(Party~1|factor1_2003+factor2_2003+Region+V240+V242, data=data2011_mlogit, nests=list(Major=c('417001', '417002'),  Opposition=c('417003', '417004')), un.nest.el=F)
#Test to make sure multinomial logit is the wrong model.
model12.1<-update(model12, nests=NULL)
#Confirms that NML is prefered.
lrtest(model12, model12.1)

#Nested model even worse for 2003. Doesn't converge with Region in it.
data2003_5$Region2<-ifelse(c(data2003_5$Region==4 | data2003_5$Region==6 | data2003_5$Region==7 | data2003_5$Region==8), NA, data2003_5$Region)
data2003_5$Region2<-as.factor(data2003_5$Region2)
data2003_5$V223<-as.factor(data2003_5$V223)
data2003_7<-data2003_5[,c('factor1','factor2', 'Party', 'Region', 'V223', 'V225')]
data2003_7$index<-seq(1,nrow(data2003_7), by=1)
data2003_7<-data2003_7[complete.cases(data2003_7),]
data2003_mlogit<-mlogit.data(data2003_7, choice="Party", shape='wide')
model8<-mlogit(Party~1|factor1+factor2+Region+V223+V225, data=data2003_mlogit)
model9<-mlogit(Party~1|factor1+factor2+Region+V223+V225, data=data2003_mlogit, alt.subset=c('417021', '417018', '417020'))
hmftest(model8, model9)

model10<-mlogit(Party~1|factor1+factor2+V223+V225, data=data2003_mlogit, nests=list(Minor=c('417028', '417021'), Major=c('417020', '417018')))

###Table 3: 2003 Survey Respondents
library(stargazer)
stargazer(model10,single.row=T)

###Table 4: 2011 Survey Respondents
library(stargazer)
stargazer(model12,single.row=T)

####
#Data from Kazakhstan
###
data2011_Kazakh<-read.spss('WV6_Data_Kazakhstan_2011_spss_v_2016-01-01.sav', use.value.labels=F, to.data.frame = TRUE)

data2011_Kazakh[,instanceconvert] <- 
  lapply(data2011_Kazakh[,instanceconvert,drop=FALSE],as.character)
data2011_Kazakh[,instanceconvert] <- 
  lapply(data2011_Kazakh[,instanceconvert,drop=FALSE],as.numeric)


data2011_Kazakh_subset<-data2011_Kazakh[,instanceconvert2]

###Table 5: Kazakhstan Columns
model13<-factanal(x=na.omit(data2011_Kazakh_subset), factors=7, rotation='varimax', na.action=na.omit)
model_scores5<-model13$loadings[,1]
model_scores6<-model13$loadings[,2]
data2011_Kazakh$factor1<-rowSums(data2011_Kazakh[,instanceconvert2]*model_scores5)
data2011_Kazakh$factor2<-rowSums(data2011_Kazakh[,instanceconvert2]*model_scores6)

#Use loadings from 2003.
#Re-run data2003 assignments.
data2011_Kazakh$factor1_2003<-rowSums(data2011_Kazakh[,instanceconvert2]*model_scores3)
data2011_Kazakh$factor2_2003<-rowSums(data2011_Kazakh[,instanceconvert2]*model_scores4)

data2011_Kazakh_1<-data2011_Kazakh[data2011_Kazakh$V228==398008,]
data2011_Kazakh_2<-data2011_Kazakh[data2011_Kazakh$V228==398003,]
data2011_Kazakh_3<-data2011_Kazakh[data2011_Kazakh$V228==398005,]
data2011_Kazakh_4<-data2011_Kazakh[data2011_Kazakh$V228==398001,]

#Factor 1 on y axis
plot(factor1_2003~factor2_2003, data=data2011_Kazakh[data2011_Kazakh$V228==398008,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Kazakhstan 2011', ylab='Distrust of Institutions', xlab='Distrust of Rural Tradition')
#legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(21,21,21,21), col=c('red', 'blue', 'green', 'black'), bty='n')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011_Kazakh[data2011_Kazakh$V228==398003,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011_Kazakh[data2011_Kazakh$V228==398001,], col=alpha('green',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011_Kazakh[data2011_Kazakh$V228==417004,], col=alpha('black',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2011_Kazakh_1$factor2_2003)),median(na.omit(data2011_Kazakh_1$factor1_2003)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2011_Kazakh_2$factor2_2003)),median(na.omit(data2011_Kazakh_2$factor1_2003)), pch=21, col='white', bg='blue', cex=1.5)
points(median(na.omit(data2011_Kazakh_3$factor2_2003)),median(na.omit(data2011_Kazakh_3$factor1_2003)), pch=21, col='white', bg='green', cex=1.5)
points(median(na.omit(data2011_Kazakh_4$factor2_2003)),median(na.omit(data2011_Kazakh_4$factor1_2003)), pch=21, col='white', bg='black', cex=1.5)

#Using 2011 Factors
plot(factor1~factor2, data=data2011_Kazakh[data2011_Kazakh$V228==398008,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Kazakhstan 2011', ylab='Distrust of Institutions', xlab='Distrust of Rural Tradition')
#legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(21,21,21,21), col=c('red', 'blue', 'green', 'black'), bty='n')
par(new=T)
plot(factor1~factor2, data=data2011_Kazakh[data2011_Kazakh$V228==398003,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1~factor2, data=data2011_Kazakh[data2011_Kazakh$V228==398001,], col=alpha('green',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
par(new=T)
plot(factor1~factor2, data=data2011_Kazakh[data2011_Kazakh$V228==417004,], col=alpha('black',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2011_Kazakh_1$factor2)),median(na.omit(data2011_Kazakh_1$factor1)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2011_Kazakh_2$factor2)),median(na.omit(data2011_Kazakh_2$factor1)), pch=21, col='white', bg='blue', cex=1.5)
points(median(na.omit(data2011_Kazakh_3$factor2)),median(na.omit(data2011_Kazakh_3$factor1)), pch=21, col='white', bg='green', cex=1.5)
points(median(na.omit(data2011_Kazakh_4$factor2)),median(na.omit(data2011_Kazakh_4$factor1)), pch=21, col='white', bg='black', cex=1.5)



###
#Import Georgia
###
data2011_Georgia<-read.spss('WV6_Data_Georgia_2014_spss_v_2016-01-01.sav', use.value.labels=F, to.data.frame = TRUE)

data2011_Georgia[,instanceconvert] <- 
  lapply(data2011_Georgia[,instanceconvert,drop=FALSE],as.character)
data2011_Georgia[,instanceconvert] <- 
  lapply(data2011_Georgia[,instanceconvert,drop=FALSE],as.numeric)

instanceconvert4<-c('V39', 'V95', 'V96', 'V98',  'V115',
                    'V125_00', 'V126', 'V127', 'V130',
                    'V145', 'V152', 'V202', 'V211', 'V213', 
                    'V239', 'V248')

data2011_Georgia_subset<-data2011_Georgia[,instanceconvert4]

###Table 5: Georgia Columns
model15<-factanal(x=na.omit(data2011_Georgia_subset), factors=2, rotation='varimax', na.action=na.omit)
model_scores9<-model15$loadings[,1]
model_scores10<-model15$loadings[,2]
data2011_Georgia$factor1<-rowSums(data2011_Georgia[,instanceconvert4]*model_scores9)
data2011_Georgia$factor2<-rowSums(data2011_Georgia[,instanceconvert4]*model_scores10)

data2011_Georgia$factor1_2003<-rowSums(data2011_Georgia[,instanceconvert4]*model_scores3)
data2011_Georgia$factor2_2003<-rowSums(data2011_Georgia[,instanceconvert4]*model_scores4)


data2011_Georgia_1<-data2011_Georgia[data2011_Georgia$V228==268123,]
data2011_Georgia_2<-data2011_Georgia[data2011_Georgia$V228==268101,]


#Factor 1 on y axis
plot(factor1_2003~factor2_2003, data=data2011_Georgia[data2011_Georgia$V228==268123,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Georgia 2011', ylab='Distrust of Institutions', xlab='Distrust of Rural Traditions')
#legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(21,21,21,21), col=c('red', 'blue', 'green', 'black'), bty='n')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2011_Georgia[data2011_Georgia$V228==268101,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2011_Georgia_1$factor2_2003)),median(na.omit(data2011_Georgia_1$factor1_2003)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2011_Georgia_2$factor2_2003)),median(na.omit(data2011_Georgia_2$factor1_2003)), pch=21, col='white', bg='blue', cex=1.5)

#Using 2011 Factors
plot(factor1~factor2, data=data2011_Georgia[data2011_Georgia$V228==268123,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Georgia 2011', ylab='Distrust of Institutions', xlab='Distrust of Democracy')
#legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(21,21,21,21), col=c('red', 'blue', 'green', 'black'), bty='n')
par(new=T)
plot(factor1~factor2, data=data2011_Georgia[data2011_Georgia$V228==268101,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2011_Georgia_1$factor2)),median(na.omit(data2011_Georgia_1$factor1)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2011_Georgia_2$factor2)),median(na.omit(data2011_Georgia_2$factor1)), pch=21, col='white', bg='blue', cex=1.5)



###
#Import Hungary
###
data2009_Hungary<-read.spss('WV5_Data_Hungary_2009_spss_v_2015_04_18.sav', use.value.labels=F, to.data.frame = TRUE)

instanceconvert5<-c('V37', 'V114', 'V116', 'V118', 'V138', 'V146_00',
                    'V147', 'V148', 'V151', 'V186', 'V192', 'V201', 'V209',
                    'V211', 'V253', 'V238')

data2009_Hungary[,instanceconvert5] <- 
  lapply(data2009_Hungary[,instanceconvert5,drop=FALSE],as.character)
data2009_Hungary[,instanceconvert5] <- 
  lapply(data2009_Hungary[,instanceconvert5,drop=FALSE],as.numeric)

data2009_Hungary_subset<-data2009_Hungary[,instanceconvert5]

###Table 5: Hungary Columns
model16<-factanal(x=na.omit(data2009_Hungary_subset), factors=2, rotation='varimax', na.action=na.omit)
model_scores11<-model16$loadings[,1]
model_scores12<-model16$loadings[,2]
data2009_Hungary$factor1<-rowSums(data2009_Hungary[,instanceconvert5]*model_scores11)
data2009_Hungary$factor2<-rowSums(data2009_Hungary[,instanceconvert5]*model_scores12)

data2009_Hungary$factor1_2003<-rowSums(data2009_Hungary[,instanceconvert5]*model_scores3)
data2009_Hungary$factor2_2003<-rowSums(data2009_Hungary[,instanceconvert5]*model_scores4)

data2009_Hungary_1<-data2009_Hungary[data2009_Hungary$V231==348004,]
data2009_Hungary_2<-data2009_Hungary[data2009_Hungary$V231==348006,]

#Using 2009 Factors
plot(factor1~factor2, data=data2009_Hungary[data2009_Hungary$V231==348004,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Hungary 2009', ylab='Distrust of Institutions', xlab='Distrust of Democracy')
#legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(21,21,21,21), col=c('red', 'blue', 'green', 'black'), bty='n')
par(new=T)
plot(factor1~factor2, data=data2009_Hungary[data2009_Hungary$V231==348006,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2009_Hungary_1$factor2)),median(na.omit(data2009_Hungary_1$factor1)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2009_Hungary_2$factor2)),median(na.omit(data2009_Hungary_2$factor1)), pch=21, col='white', bg='blue', cex=1.5)


data2009_Hungary_3<-data2009_Hungary[,c('V231', 'factor1', 'factor2', 'V257', 'V237', 'V235')]
colnames(data2009_Hungary_3)<-c('Party', 'factor1', 'factor2', 'Region', 'Age', 'Gender')
data2009_Hungary_3$Region<-as.factor(data2009_Hungary_3$Region)
data2009_Hungary_3$Gender<-as.factor(data2009_Hungary_3$Gender)
data2009_Hungary_3<-data2009_Hungary_3[data2009_Hungary_3$Party==348006 | data2009_Hungary_3$Party==348004,]
data2009_Hungary_3$Party<-ifelse(data2009_Hungary_3$Party==348006, 1,0)

###Table 6
model20<-glm(Party~factor1+factor2+Age+Gender+Region, data=data2009_Hungary_3, family=binomial(link='logit'))
stargazer(model20)

#Using 2003 Factors
plot(factor1_2003~factor2_2003, data=data2009_Hungary[data2009_Hungary$V231==348004,], col=alpha('red',0.5), ylim=c(-10,25), xlim=c(-7,30), main='Vote Dispersion in Hungary 2009', ylab='Distrust of Institutions', xlab='Distrust of Democracy')
#legend(18, 28, c('SDPK', "Ata-Zhurt", 'Ar-Namys', 'Ata-Meken'), pch=c(21,21,21,21), col=c('red', 'blue', 'green', 'black'), bty='n')
par(new=T)
plot(factor1_2003~factor2_2003, data=data2009_Hungary[data2009_Hungary$V231==348006,], col=alpha('blue',0.5), ylim=c(-10,25), xlim=c(-7,30), axes=F, xlab='', ylab='')
points(median(na.omit(data2009_Hungary_1$factor2_2003)),median(na.omit(data2009_Hungary_1$factor1_2003)), pch=21, col='white', bg='red', cex=1.5)
points(median(na.omit(data2009_Hungary_2$factor2_2003)),median(na.omit(data2009_Hungary_2$factor1_2003)), pch=21, col='white', bg='blue', cex=1.5)

