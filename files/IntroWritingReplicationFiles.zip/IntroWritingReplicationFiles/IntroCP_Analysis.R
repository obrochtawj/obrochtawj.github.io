#######################################################################################################
### Replication code for: Completing the Research Article Writing Process in an Introductory Course ###
### William O'Brochta, Louisiana Tech University                                                    ###
### Published in the Journal of Political Science Education                                         ###
#######################################################################################################

library(lmtest)
library(irr)
library(psy)

results<-read.csv("IntroCP_PrePostSurvey.csv", header=T, stringsAsFactors = F)
mean(results$Pre.Confidence.Key.Points)
t.test(results$Pre.Confidence.Key.Points,results$Post.Confidence.Key.Points, paired=T)
t.test(results$Pre.Confidence.RQ,results$Post.Confidence.RQ, paired=T)
t.test(results$Pre.Confidence.Literature,results$Post.Confidence.Literature, paired=T)
t.test(results$Pre.Confidence.Sources,results$Post.Confidence.Sources, paired=T)
t.test(results$Pre.Confidence.Hypotheses,results$Post.Confidence.Hypotheses, paired=T)
t.test(results$Pre.Confidence.Variables,results$Post.Confidence.Variables, paired=T)
t.test(results$Pre.Confidence.RD,results$Post.Confidence.RD, paired=T)
t.test(results$Pre.Confidence.Writing,results$Post.Confidence.Writing, paired=T)
t.test(results$Pre.Understand.PS,results$Post.Understand.PS, paired=T)
t.test(results$Pre.Understand.PS.Research.Methods,results$Post.Understand.PS.Research.Methods, paired=T)
t.test(results$Pre.Social.Scientist,results$Post.Social.Scientist, paired=T)


#Independent coder results for applied skills
combined<-read.csv("IntroCP_CombinedCoding.csv", header=T, stringsAsFactors = F)

coded<-combined[combined$Coder=='1',]
mean(coded2$Pre.Data..IV.DV.Score)
t.test(coded$Pre.Summary.Score,coded$Post.Summary.Score, paired=T)
t.test(coded$Pre.RQ.Score,coded$Post.RQ.Score, paired=T)
t.test(coded$Pre.Literature.Score,coded$Post.Literature.Score, paired=T)
t.test(coded$Pre.Hypothesis.Score,coded$Post.Hypothesis.Score, paired=T)
t.test(coded$Pre.Data..IV.DV.Score,coded$Post.Data..IV.DV.Score, paired=T)

coded2<-combined[combined$Coder=='2',]
t.test(coded2$Pre.Summary.Score,coded2$Post.Summary.Score, paired=T)
t.test(coded2$Pre.RQ.Score,coded2$Post.RQ.Score, paired=T)
t.test(coded2$Pre.Literature.Score,coded2$Post.Literature.Score, paired=T)
t.test(coded2$Pre.Hypothesis.Score,coded2$Post.Hypothesis.Score, paired=T)
t.test(coded2$Pre.Data..IV.DV.Score,coded2$Post.Data..IV.DV.Score, paired=T)

coded3<-combined[combined$Coder=='Average',]
mean(coded3$Post.Data..IV.DV.Score, na.rm=T)
t.test(coded3$Pre.Summary.Score,coded3$Post.Summary.Score, paired=T)
t.test(coded3$Pre.RQ.Score,coded3$Post.RQ.Score, paired=T)
t.test(coded3$Pre.Literature.Score,coded3$Post.Literature.Score, paired=T)
t.test(coded3$Pre.Hypothesis.Score,coded3$Post.Hypothesis.Score, paired=T)
t.test(coded3$Pre.Data..IV.DV.Score,coded3$Post.Data..IV.DV.Score, paired=T)

coded4<-combined[combined$Coder=='Difference',]
mean(colMeans(abs(coded4[,c(seq(4,22,by=2))])))

irr<-read.csv("IntroCP_CombinedCodingIRR.csv", header=T, stringsAsFactors = F)
#Agreement at 90%
agree(irr[,1:2], tolerance=1)
#Above 0.6 is "substantial agreement"
kappa2(irr[, c("Coder.1", "Coder.2")], weight = "square")
#Above 0.7 is high
cronbach(irr)




