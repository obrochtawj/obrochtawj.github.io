###############################################################
### Ethnic Cabinet Diversity, Co-Ethnic Representation, and ###
### Attitudes Toward Government                             ###
### Afrobarometer Data Analysis                             ###
### William O'Brochta, Texas Lutheran University            ###
################################################################ 


library(lme4)
library(plyr)
library(dplyr)
library(xtable)
#library(interplot)
library(stargazer)


load("afb4.RData")
afb4$year_f<-as.factor(afb4$year)
afb4$join_others<-ifelse(afb4$join_others==9,NA,afb4$join_others)
afb4$ethnic_notincabinet<-ifelse(afb4$ethnic_ps==0,1,0)
afb4$ethnic_notincabinet_l<-ifelse(afb4$ethnic_ps_l==0,1,0)
afb4$ethnic_incabinet<-1-afb4$ethnic_notincabinet
afb4$ethnic_incabinet_l<-1-afb4$ethnic_notincabinet_l

#Descriptive Statistics
attach(afb4)
data_summary<-as.data.frame(cbind(ethnic_unfair, #join_others,
                                  #attend_protest, contact_councillor,
                                  #attend_meeting, voted,
                                  ethnic_incabinet_l,
                                  leader_ethnicity_match_l, ethnic_minority,
                                  female, unemployed,
                                  own_tv, had_food,
                                  ed_belowsecondary, ed_somesecondary, ed_secondary,
                                  ed_ba, age18_35,
                                  age35_49, age50_64, age65over, pol_interest))

detach(afb4)
data_summary2<-as.data.frame(matrix(nrow=17, ncol=6))
for(i in 1:17){
  data_summary2[i,1]<-names(data_summary)[i]
  data_summary2[i,2]<-min(data_summary[,i], na.rm=T)
  data_summary2[i,3]<-max(data_summary[,i], na.rm=T)
  data_summary2[i,4]<-sqrt(var(data_summary[,i], na.rm=T))
  data_summary2[i,5]<-mean(data_summary[,i], na.rm=T)
  data_summary2[i,6]<-median(data_summary[,i], na.rm=T)
}
colnames(data_summary2)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")

library(xtable)
#Table SI.2.1
print(xtable(data_summary2, type='latex', digits=2), file='data_summary_individual.tex', include.rownames=FALSE)


afb_country<-dplyr::select(afb4, c("country_name", "year", "ethnicity_hh_l",
                                   "ethnic_ps_l", "elf_afb", "polity2_l", "gdppc_ln_l",
                                   "pct_women_l", "pct_wm_leg_l"))
afb_country<-unique(afb_country)
data_summary<-afb_country[,-1]

data_summary2<-as.data.frame(matrix(nrow=8, ncol=6))
for(i in 1:8){
  data_summary2[i,1]<-names(data_summary)[i]
  data_summary2[i,2]<-min(data_summary[,i], na.rm=T)
  data_summary2[i,3]<-max(data_summary[,i], na.rm=T)
  data_summary2[i,4]<-sqrt(var(data_summary[,i], na.rm=T))
  data_summary2[i,5]<-mean(data_summary[,i], na.rm=T)
  data_summary2[i,6]<-median(data_summary[,i], na.rm=T)
}
colnames(data_summary2)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")

#Table SI.2.2
print(xtable(data_summary2, type='latex', digits=2), file='data_summary_country.tex', include.rownames=FALSE)



#ethnicity_hh: HH of cabinet (country-year)
#pct_ethnic_rep: percentage of an individual's ethnic group makes up the cabinet (individual-year)
#ethnic_ps: Power score for each ethnic group (individual-year)
#Country level ethnic diversity: elf_hief (only through 2013), elf_afb (using AFB data)

###Analysis
model_mlm1<-lmer(ethnic_unfair~female*pct_women_l+unemployed+own_tv+had_food
                +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                +ethnic_incabinet_l*ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                +(1|country_name)+(1|year_f), afb4)
summary(model_mlm1)

model_mlm1.0<-lmer(ethnic_unfair~female*pct_women_l+unemployed+own_tv+had_food
                 +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                 +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                 +ethnic_incabinet_l+ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                 +(1|country_name)+(1|year_f), afb4)
summary(model_mlm1.0)



#Robustness with pct_ethnic_rep_l
#Correlation between pct_ethnic_rep and ethnic_ps
ethnic_scores<-dplyr::select(afb4, c("COWCode", "year", "pol_ethnic_identity", "ethnic_ps", "pct_ethnic_rep"))
ethnic_scores<-unique(ethnic_scores)
ethnic_scores<-ethnic_scores[!is.na(ethnic_scores$pol_ethnic_identity),]

cor(ethnic_scores$pct_ethnic_rep, ethnic_scores$ethnic_ps, use="complete.obs")
plot(ethnic_scores$pct_ethnic_rep, ethnic_scores$ethnic_ps)

hist(ethnic_scores$pct_ethnic_rep)
hist(ethnic_scores$ethnic_ps)


model_mlm3<-lmer(ethnic_unfair~female*pct_women_l+unemployed+own_tv+had_food
                 +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                 +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                 +pct_ethnic_rep_l*ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                 +(1|country_name)+(1|year_f), afb4)
summary(model_mlm3)


model_mlm3.0<-lmer(ethnic_unfair~female*pct_women_l+unemployed+own_tv+had_food
                 +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                 +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                 +pct_ethnic_rep_l+ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                 +(1|country_name)+(1|year_f), afb4)
summary(model_mlm3.0)


#Check AFB ethnic minority dominance
country_year<-dplyr::select(afb4, c("country_name", "round"))
country_year<-unique(country_year)
country_year$majority<-NA
country_year$minority<-NA

for(i in 1:69){
  country_name<-country_year[i,1]
  round<-country_year[i,2]
  temp<-afb4[afb4$country_name==country_name & afb4$round==round,]
  temp2<-table(temp$ethnic_minority)
  country_year[i,3]<-temp2[1]
  country_year[i,4]<-temp2[2]
}

country_year<-country_year[!is.na(country_year$country_name),]

#Good descriptive statistic: percent minority per country-year
country_year$total_sample<-country_year$majority+country_year$minority
country_year$pct_majority<-country_year$majority/country_year$total_sample
country_year$pct_minority<-1-country_year$pct_majority

summary(country_year$pct_minority)
hist(country_year$pct_minority)
mean(table(country_year$country_name))


#Correlation between country level and cabinet level diversity
diversity_rep<-dplyr::select(afb4, c("country_name", "year", "elf_afb", "ethnicity_hh"))
diversity_rep<-unique(diversity_rep)
diversity_rep<-diversity_rep[!is.na(diversity_rep$ethnicity_hh),]

plot(diversity_rep$elf_afb, diversity_rep$ethnicity_hh)
cor(diversity_rep$elf_afb, diversity_rep$ethnicity_hh, use="complete.obs")

diversity_country<-as.data.frame(diversity_rep[,c(1,4)]%>%
  group_by(country_name)%>%
  summarise_all(max))

diversity_country2<-as.data.frame(diversity_rep[,c(1,4)]%>%
                group_by(country_name)%>%
                summarise_all(min))

colnames(diversity_country)<-c("country_name", "cabinet_diversity_max")
diversity_country$cabinet_diversity_min<-diversity_country2$ethnicity_hh

diversity_country$cabinet_diversity_delta<-diversity_country$cabinet_diversity_max-diversity_country$cabinet_diversity_min
summary(diversity_country$cabinet_diversity_delta)



###Subset to those with and without representation
afb4.1<-afb4[afb4$ethnic_incabinet_l==1,]

model_mlm4<-lmer(ethnic_unfair~female*pct_women_l+unemployed+own_tv+had_food
                 +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                 +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                 +ethnic_ps_l*ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                 +(1|country_name)+(1|year_f), afb4.1)
summary(model_mlm4)

model_mlm4.0<-lmer(ethnic_unfair~female*pct_women_l+unemployed+own_tv+had_food
                 +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                 +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                 +ethnic_ps_l+ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                 +(1|country_name)+(1|year_f), afb4.1)
summary(model_mlm4.0)


#Table SI.3.2
#May need fix here: https://gist.github.com/alexeyknorre/b0780836f4cec04d41a863a683f91b53
stargazer(model_mlm1.0, model_mlm1, model_mlm3.0, model_mlm3, model_mlm4.0, model_mlm4, 
          out="models_unfair.tex")



