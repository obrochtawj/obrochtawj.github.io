###############################################################
### Ethnic Cabinet Diversity, Co-Ethnic Representation, and ###
### Attitudes Toward Government                             ###
### Afrobarometer Data Preparation                          ###
### William O'Brochta, Texas Lutheran University            ###
################################################################ 

library(labelled)
library(stringr)
library(stringi)
library(haven)
library(plyr)
library(dplyr)
library(fastDummies)

###Cabinet ethnicity table
#Need to download data (see Read_Me)
cabinet<-read.csv("Public Version July 10_Finalised.csv", header = T, stringsAsFactors = F)
cabinet$keep<-ifelse(cabinet$country_id==1 | cabinet$country_id==2 |
                       cabinet$country_id==3 | cabinet$country_id==4 |
                       cabinet$country_id==7 | cabinet$country_id==8 |
                       cabinet$country_id==9 | cabinet$country_id==10 |
                       cabinet$country_id==11 | cabinet$country_id==12 |
                       cabinet$country_id==13 | cabinet$country_id==14 | 
                       cabinet$country_id==15 | cabinet$country_id==17 |
                       cabinet$country_id==18 | cabinet$country_id==20 |
                       cabinet$country_id==21 | cabinet$country_id==22 | cabinet$country_id==23, 1, 0)
cabinet<-cabinet[cabinet$keep==1,]

#Change Estim Arab to match Afrobarometer coding
cabinet$pol_ethnic_identity<-ifelse(cabinet$pol_ethnic_identity=="Estim Arab", "Arab", cabinet$pol_ethnic_identity)



cabinet_freq<-as.data.frame(table(cabinet$prgroupid))
colnames(cabinet_freq)<-c("prgroupid", "freq")

cabinet_ethnicity<-as.data.frame(unique(cbind(cabinet$prgroupid, cabinet$pol_ethnic_identity)))
colnames(cabinet_ethnicity)<-c("prgroupid", "pol_ethnic_identity")

cabinet_cntry<-reshape(as.data.frame(table(cabinet$prgroupid, cabinet$country)), idvar="Var1", timevar="Var2", direction="wide")
cabinet_cntry$maxCntry<-colnames(cabinet_cntry[,-1])[max.col(cabinet_cntry[,-1],ties.method="first")]
cabinet_cntry$maxCntry<-stri_sub(cabinet_cntry$maxCntry,6)

cabinet2<-merge(cabinet_ethnicity, cabinet_freq, by="prgroupid", all.x=T)
cabinet3<-merge(cabinet2, cabinet_cntry, by.x="prgroupid", by.y="Var1", all.x=T)

#write.csv(cabinet3, file="cabinet3.csv", row.names=F)



###Create table of ethnicities with frequencies
#Known issue with opening the Afrobarometer in R using Haven. This is an encoding error.
#Need to download data (see Read_Me)
r6<-read_sav("merged_r6_data_2016_36countries2.sav", encoding = "latin1")
r6$keep<-ifelse(r6$COUNTRY==1 | r6$COUNTRY==3 | r6$COUNTRY==6 |
                  r6$COUNTRY==12 | r6$COUNTRY==8 | r6$COUNTRY==13 |
                  r6$COUNTRY==15 | r6$COUNTRY==17 | r6$COUNTRY==18 |
                  r6$COUNTRY==20 | r6$COUNTRY==24 | r6$COUNTRY==27 | 
                  r6$COUNTRY==28 | r6$COUNTRY==31 | r6$COUNTRY==34 |
                  r6$COUNTRY==36, 1, 0)
r6<-r6[r6$keep==1,]


r6_ethnicity<-as.data.frame(val_labels(r6$Q87, prefixed = T))
r6_ethnicity$ethnicity<-row.names(r6_ethnicity)
r6_ethnicity$ethnicity<-str_split_fixed(r6_ethnicity$ethnicity, "] ", n=2)[,2]
r_6_ethnicity_freq<-as.data.frame(table(r6$Q87))
colnames(r_6_ethnicity_freq)<-c("r6_ethnicity_code", "r6_freq")
colnames(r6_ethnicity)<-c("r6_ethnicity_code", "ethnicity")
r6_2<-merge(r6_ethnicity, r_6_ethnicity_freq, by="r6_ethnicity_code", all.x=T, all.y=F)

r6_ethnicity_cntry<-reshape(as.data.frame(table(r6$Q87, r6$COUNTRY)), idvar="Var1", timevar="Var2", direction="wide")
r6_ethnicity_cntry$maxCntry<-colnames(r6_ethnicity_cntry[,-1])[max.col(r6_ethnicity_cntry[,-1],ties.method="first")]
r6_ethnicity_cntry$maxCntry<-stri_sub(r6_ethnicity_cntry$maxCntry,6)

r6_cntry<-as.data.frame(val_labels(r6$COUNTRY, prefixed = T))
r6_cntry$country_name<-row.names(r6_cntry)
r6_cntry$country_name<-str_split_fixed(r6_cntry$country_name, "] ", n=2)[,2]
colnames(r6_cntry)<-c("country_code", "max_country_name")

r6_3<-merge(r6_ethnicity_cntry, r6_cntry, by.x="maxCntry", by.y="country_code")
r6_3<-r6_3[,c(1,2,19)]
colnames(r6_3)<-c("r6_maxCntry", "r6_ethnicity_code", "r6_max_country_name")

r6_4<-merge(r6_2, r6_3, by="r6_ethnicity_code")


###Repeat for round 5
#Need to download data (see Read_Me)
r5<-read_sav("merged-round-5-data-34-countries-2011-2013-last-update-july-2015.sav")
r5$keep<-ifelse(r5$COUNTRY==2 | r5$COUNTRY==27 | r5$COUNTRY==6 |
         r5$COUNTRY==8 | r5$COUNTRY==10 | r5$COUNTRY==11 | 
         r5$COUNTRY==14 | r5$COUNTRY==16 | r5$COUNTRY==17 | 
         r5$COUNTRY==18 | r5$COUNTRY==20 | r5$COUNTRY==25 | 
         r5$COUNTRY==26 | r5$COUNTRY==28 | r5$COUNTRY==29 |
         r5$COUNTRY==31 | r5$COUNTRY==33 | r5$COUNTRY==35, 1, 0)
r5<-r5[r5$keep==1,]

r5_ethnicity<-as.data.frame(val_labels(r5$Q84, prefixed = T))
r5_ethnicity$ethnicity<-row.names(r5_ethnicity)
r5_ethnicity$ethnicity<-str_split_fixed(r5_ethnicity$ethnicity, "] ", n=2)[,2]
r_5_ethnicity_freq<-as.data.frame(table(r5$Q84))
colnames(r_5_ethnicity_freq)<-c("r5_ethnicity_code", "r5_freq")
colnames(r5_ethnicity)<-c("r5_ethnicity_code", "ethnicity")
r5_2<-merge(r5_ethnicity, r_5_ethnicity_freq, by="r5_ethnicity_code", all.x=T, all.y=F)

r5_ethnicity_cntry<-reshape(as.data.frame(table(r5$Q84, r5$COUNTRY)), idvar="Var1", timevar="Var2", direction="wide")
r5_ethnicity_cntry$maxCntry<-colnames(r5_ethnicity_cntry[,-1])[max.col(r5_ethnicity_cntry[,-1],ties.method="first")]
r5_ethnicity_cntry$maxCntry<-stri_sub(r5_ethnicity_cntry$maxCntry,6)

r5_cntry<-as.data.frame(val_labels(r5$COUNTRY, prefixed = T))
r5_cntry$country_name<-row.names(r5_cntry)
r5_cntry$country_name<-str_split_fixed(r5_cntry$country_name, "] ", n=2)[,2]
colnames(r5_cntry)<-c("country_code", "max_country_name")

r5_3<-merge(r5_ethnicity_cntry, r5_cntry, by.x="maxCntry", by.y="country_code")
r5_3<-r5_3[,c(1,2,20)]
colnames(r5_3)<-c("r5_maxCntry", "r5_ethnicity_code", "r5_max_country_name")

r5_4<-merge(r5_2, r5_3, by="r5_ethnicity_code")

r6_r5<-merge(r6_4, r5_4, by="ethnicity", all.x=T, all.y=T)
r6_r5$r6_r5_match<-ifelse(r6_r5$r6_ethnicity_code==r6_r5$r5_ethnicity_code,1,0)


###Round 4
#Need to download data (see Read_Me)
r4<-read_sav("merged_r4_data.sav")
r4$keep<-ifelse(r4$COUNTRY==2 | r4$COUNTRY==6 | r4$COUNTRY==8 |
                  r4$COUNTRY==10 | r4$COUNTRY==14 | r4$COUNTRY==16 | 
                  r4$COUNTRY==18 | r4$COUNTRY==20, 1, 0)
r4<-r4[r4$keep==1,]


r4_ethnicity<-as.data.frame(val_labels(r4$Q79, prefixed = T))
r4_ethnicity$ethnicity<-row.names(r4_ethnicity)
r4_ethnicity$ethnicity<-str_split_fixed(r4_ethnicity$ethnicity, "] ", n=2)[,2]
r4_ethnicity_freq<-as.data.frame(table(r4$Q79))
colnames(r4_ethnicity_freq)<-c("r4_ethnicity_code", "r4_freq")
colnames(r4_ethnicity)<-c("r4_ethnicity_code", "ethnicity")
r4_2<-merge(r4_ethnicity, r4_ethnicity_freq, by="r4_ethnicity_code", all.x=T, all.y=F)

r4_ethnicity_cntry<-reshape(as.data.frame(table(r4$Q79, r4$COUNTRY)), idvar="Var1", timevar="Var2", direction="wide")
r4_ethnicity_cntry$maxCntry<-colnames(r4_ethnicity_cntry[,-1])[max.col(r4_ethnicity_cntry[,-1],ties.method="first")]
r4_ethnicity_cntry$maxCntry<-stri_sub(r4_ethnicity_cntry$maxCntry,6)

r4_cntry<-as.data.frame(val_labels(r4$COUNTRY, prefixed = T))
r4_cntry$country_name<-row.names(r4_cntry)
r4_cntry$country_name<-str_split_fixed(r4_cntry$country_name, "] ", n=2)[,2]
colnames(r4_cntry)<-c("country_code", "max_country_name")

r4_3<-merge(r4_ethnicity_cntry, r4_cntry, by.x="maxCntry", by.y="country_code")
r4_3<-r4_3[,c(1,2,11)]
colnames(r4_3)<-c("r4_maxCntry", "r4_ethnicity_code", "r4_max_country_name")

r4_4<-merge(r4_2, r4_3, by="r4_ethnicity_code")

r6_r5_r4<-merge(r6_r5, r4_4, by="ethnicity", all.x=T, all.y=T)



###Round 3
#Need to download data (see Read_Me)
r3<-read_sav("merged_r3_data.sav")
r3$keep<-ifelse(r3$country==2 | r3$country==5 | r3$country==8 | 
                  r3$country==9 | r3$country==12 | r3$country==14 |
                  r3$country==15 | r3$country==16 | r3$country==18, 1, 0)
r3<-r3[r3$keep==1,]


r3_ethnicity<-as.data.frame(val_labels(r3$q79, prefixed = T))
r3_ethnicity$ethnicity<-row.names(r3_ethnicity)
r3_ethnicity$ethnicity<-str_split_fixed(r3_ethnicity$ethnicity, "] ", n=2)[,2]
r3_ethnicity_freq<-as.data.frame(table(r3$q79))
colnames(r3_ethnicity_freq)<-c("r3_ethnicity_code", "r3_freq")
colnames(r3_ethnicity)<-c("r3_ethnicity_code", "ethnicity")
r3_2<-merge(r3_ethnicity, r3_ethnicity_freq, by="r3_ethnicity_code", all.x=T, all.y=F)

r3_ethnicity_cntry<-reshape(as.data.frame(table(r3$q79, r3$country)), idvar="Var1", timevar="Var2", direction="wide")
r3_ethnicity_cntry$maxCntry<-colnames(r3_ethnicity_cntry[,-1])[max.col(r3_ethnicity_cntry[,-1],ties.method="first")]
r3_ethnicity_cntry$maxCntry<-stri_sub(r3_ethnicity_cntry$maxCntry,6)

r3_cntry<-as.data.frame(val_labels(r3$country, prefixed = T))
r3_cntry$country_name<-row.names(r3_cntry)
r3_cntry$country_name<-str_split_fixed(r3_cntry$country_name, "] ", n=2)[,2]
colnames(r3_cntry)<-c("country_code", "max_country_name")

r3_3<-merge(r3_ethnicity_cntry, r3_cntry, by.x="maxCntry", by.y="country_code")
r3_3<-r3_3[,c(1,2,12)]
colnames(r3_3)<-c("r3_maxCntry", "r3_ethnicity_code", "r3_max_country_name")

r3_4<-merge(r3_2, r3_3, by="r3_ethnicity_code")

r6_r5_r4_r3<-merge(r6_r5_r4, r3_4, by="ethnicity", all.x=T, all.y=T)



###Round 7
#Need to download data (see Read_Me)
r7<-read_sav("r7_merged_data_34ctry.release.sav")
r7$keep<-ifelse(r7$COUNTRY==2 | r7$COUNTRY==5 | r7$COUNTRY==6 |
                  r7$COUNTRY==11 | r7$COUNTRY==12 | r7$COUNTRY==14 |
                  r7$COUNTRY==16 | r7$COUNTRY==17 | r7$COUNTRY==19 |
                  r7$COUNTRY==23 | r7$COUNTRY==26 | r7$COUNTRY==27 |
                  r7$COUNTRY==29 | r7$COUNTRY==31 | r7$COUNTRY==32 | r7$COUNTRY==34, 1, 0)
r7<-r7[r7$keep==1,]


r7_ethnicity<-as.data.frame(val_labels(r7$Q84, prefixed = T))
r7_ethnicity$ethnicity<-row.names(r7_ethnicity)
r7_ethnicity$ethnicity<-str_split_fixed(r7_ethnicity$ethnicity, "] ", n=2)[,2]
r7_ethnicity_freq<-as.data.frame(table(r7$Q84))
colnames(r7_ethnicity_freq)<-c("r7_ethnicity_code", "r7_freq")
colnames(r7_ethnicity)<-c("r7_ethnicity_code", "ethnicity")
r7_2<-merge(r7_ethnicity, r7_ethnicity_freq, by="r7_ethnicity_code", all.x=T, all.y=F)

r7_ethnicity_cntry<-reshape(as.data.frame(table(r7$Q84, r7$COUNTRY)), idvar="Var1", timevar="Var2", direction="wide")
r7_ethnicity_cntry$maxCntry<-colnames(r7_ethnicity_cntry[,-1])[max.col(r7_ethnicity_cntry[,-1],ties.method="first")]
r7_ethnicity_cntry$maxCntry<-stri_sub(r7_ethnicity_cntry$maxCntry,6)

r7_cntry<-as.data.frame(val_labels(r7$COUNTRY, prefixed = T))
r7_cntry$country_name<-row.names(r7_cntry)
r7_cntry$country_name<-str_split_fixed(r7_cntry$country_name, "] ", n=2)[,2]
colnames(r7_cntry)<-c("country_code", "max_country_name")

r7_3<-merge(r7_ethnicity_cntry, r7_cntry, by.x="maxCntry", by.y="country_code")
r7_3<-r7_3[,c(1,2,19)]
colnames(r7_3)<-c("r7_maxCntry", "r7_ethnicity_code", "r7_max_country_name")

r7_4<-merge(r7_2, r7_3, by="r7_ethnicity_code")


###Full Afb ethnicity code list
r_full<-merge(r6_r5_r4_r3, r7_4, by="ethnicity", all.x=T, all.y=T)
r_full$ethnicity_uniqueid<-row.names(r_full)

#write.csv(r_full, file="r_full.csv", row.names=F)
#save(r_full, file="r_full.RData")




###Combine and check ethnicity coding
#load("r_full.RData")

r_matched<-read.csv("afrobarometer_matched_withexplanation.csv", 
                    header=T, stringsAsFactors = F)
r_matched$pol_ethnic_identity<-ifelse(r_matched$pol_ethnic_identity=="None", NA, r_matched$pol_ethnic_identity)
r_matched$recheck<-ifelse(r_matched$recheck=="No match", NA, r_matched$recheck)
r_matched$recheck<-ifelse(r_matched$recheck=="", NA, r_matched$recheck)

r_matched$ethnicity_combined<-ifelse(!is.na(r_matched$pol_ethnic_identity), 
                                     r_matched$pol_ethnic_identity,
                                     r_matched$recheck)

#Pull out coding into individual rounds
r3_matched<-r_matched[!is.na(r_matched$r3_freq),]
r3_matched<-dplyr::select(r3_matched, c("r3_ethnicity_code", "ethnicity_combined"))
colnames(r3_matched)<-c("r3_ethnicity_code", "pol_ethnic_identity")

r4_matched<-r_matched[!is.na(r_matched$r4_freq),]
r4_matched<-dplyr::select(r4_matched, c("r4_ethnicity_code", "ethnicity_combined"))
colnames(r4_matched)<-c("r4_ethnicity_code", "pol_ethnic_identity")

r5_matched<-r_matched[!is.na(r_matched$r5_freq),]
r5_matched<-dplyr::select(r5_matched, c("r5_ethnicity_code", "ethnicity_combined"))
colnames(r5_matched)<-c("r5_ethnicity_code", "pol_ethnic_identity")

r6_matched<-r_matched[!is.na(r_matched$r6_freq),]
r6_matched<-dplyr::select(r6_matched, c("r6_ethnicity_code", "ethnicity_combined"))
colnames(r6_matched)<-c("r6_ethnicity_code", "pol_ethnic_identity")

r7_matched<-r_matched[!is.na(r_matched$r7_freq),]
r7_matched<-dplyr::select(r7_matched, c("r7_ethnicity_code", "ethnicity_combined"))
colnames(r7_matched)<-c("r7_ethnicity_code", "pol_ethnic_identity")


#Merge with Afrobarometer on each round
colnames(r3_cntry)<-c("country", "country_name")
r3_match_cntry<-merge(r3, r3_cntry, by="country", all.x=T)
r3_match_merge<-merge(r3_match_cntry, r3_matched, by.x="q79", by.y="r3_ethnicity_code", all.x=T)
#write.csv(table(r3_match_merge$pol_ethnic_identity, r3_match_merge$country_name), file="r3_match_merge.csv", row.names=T)

colnames(r4_cntry)<-c("COUNTRY", "country_name")
r4_match_cntry<-merge(r4, r4_cntry, by="COUNTRY", all.x=T)
r4_match_merge<-merge(r4_match_cntry, r4_matched, by.x="Q79", by.y="r4_ethnicity_code", all.x=T)
#write.csv(table(r4_match_merge$pol_ethnic_identity, r4_match_merge$country_name), file="r4_match_merge.csv", row.names=T)

colnames(r5_cntry)<-c("COUNTRY", "country_name")
r5_match_cntry<-merge(r5, r5_cntry, by="COUNTRY", all.x=T)
r5_match_merge<-merge(r5_match_cntry, r5_matched, by.x="Q84", by.y="r5_ethnicity_code", all.x=T)
#write.csv(table(r5_match_merge$pol_ethnic_identity, r5_match_merge$country_name), file="r5_match_merge.csv", row.names=T)

colnames(r6_cntry)<-c("COUNTRY", "country_name")
r6_match_cntry<-merge(r6, r6_cntry, by="COUNTRY", all.x=T)
r6_match_merge<-merge(r6_match_cntry, r6_matched, by.x="Q87", by.y="r6_ethnicity_code", all.x=T)
#write.csv(table(r6_match_merge$pol_ethnic_identity, r6_match_merge$country_name), file="r6_match_merge.csv", row.names=T)

colnames(r7_cntry)<-c("COUNTRY", "country_name")
r7_match_cntry<-merge(r7, r7_cntry, by="COUNTRY", all.x=T)
r7_match_merge<-merge(r7_match_cntry, r7_matched, by.x="Q84", by.y="r7_ethnicity_code", all.x=T)
#write.csv(table(r7_match_merge$pol_ethnic_identity, r7_match_merge$country_name), file="r7_match_merge.csv", row.names=T)

#Make modifications to ensure country-year match
#Eliminate non-response or "other" response
#R3
r3_match_merge$nonresponse<-ifelse(r3_match_merge$q79==-1|r3_match_merge$q79==999|
                                     r3_match_merge$q79==990| r3_match_merge$q79==997|
                                     r3_match_merge$q79==995| r3_match_merge$q79==998,1,0)
r3_match_merge<-r3_match_merge[r3_match_merge$nonresponse==0,]

r3_match_merge$pol_ethnic_identity<-ifelse(r3_match_merge$country_name=="Botswana" & 
  r3_match_merge$pol_ethnic_identity=="Ndebele-Kalanga-(Tonga)",
  "Kalanga", r3_match_merge$pol_ethnic_identity)

r3_match_merge$pol_ethnic_identity<-ifelse(r3_match_merge$country_name=="Kenya" & 
                                             r3_match_merge$pol_ethnic_identity=="Luhya",
                                           "Luyha", r3_match_merge$pol_ethnic_identity)

r3_match_merge$pol_ethnic_identity<-ifelse(r3_match_merge$country_name=="Mali" & 
                                             r3_match_merge$pol_ethnic_identity=="Fulani",
                                           "Peul-Fulani", r3_match_merge$pol_ethnic_identity)

r3_match_merge$pol_ethnic_identity<-ifelse(r3_match_merge$country_name=="Mali" & 
                                             r3_match_merge$pol_ethnic_identity=="Senogu",
                                           "Senufo", r3_match_merge$pol_ethnic_identity)

r3_match_merge$pol_ethnic_identity<-ifelse(r3_match_merge$pol_ethnic_identity=="Malinke ",
                                           "Malinke", r3_match_merge$pol_ethnic_identity)

r3_match_merge$pol_ethnic_identity<-ifelse(r3_match_merge$country_name=="South Africa" & 
                                             r3_match_merge$pol_ethnic_identity=="Afrikaner",
                                           "White", r3_match_merge$pol_ethnic_identity)

#Not asked in Zimbabwe
r3_match_merge<-r3_match_merge[r3_match_merge$country_name!="Zimbabwe",]


#R4
r4_match_merge$nonresponse<-ifelse(r4_match_merge$Q79==-1|r4_match_merge$Q79==9999|
                                     r4_match_merge$Q79==9990|
                                     r4_match_merge$Q79==9995| r4_match_merge$Q79==9998,1,0)
r4_match_merge<-r4_match_merge[r4_match_merge$nonresponse==0,]

r4_match_merge$pol_ethnic_identity<-ifelse(r4_match_merge$country_name=="Botswana" & 
                                             r4_match_merge$pol_ethnic_identity=="Ndebele-Kalanga-(Tonga)",
                                           "Kalanga", r4_match_merge$pol_ethnic_identity)

r4_match_merge$pol_ethnic_identity<-ifelse(r4_match_merge$country_name=="South Africa" & 
                                             r4_match_merge$pol_ethnic_identity=="Afrikaner",
                                           "White", r4_match_merge$pol_ethnic_identity)

r4_match_merge$pol_ethnic_identity<-ifelse(r4_match_merge$country_name=="South Africa" & 
                                             r4_match_merge$pol_ethnic_identity=="White ",
                                           "White", r4_match_merge$pol_ethnic_identity)


r4_match_merge$pol_ethnic_identity<-ifelse(r4_match_merge$country_name=="Zimbabwe" & 
                                             r4_match_merge$pol_ethnic_identity=="Tumbuka-Tonga-Nyakusya",
                                           "Ndebele-Kalanga-(Tonga)", r4_match_merge$pol_ethnic_identity)


#R5
r5_match_merge$nonresponse<-ifelse(r5_match_merge$Q84==-1|r5_match_merge$Q84==9999|
                                     r5_match_merge$Q84==9990|
                                     r5_match_merge$Q84==9995| r5_match_merge$Q84==9998,1,0)
r5_match_merge<-r5_match_merge[r5_match_merge$nonresponse==0,]


#Not asked in Algeria or Morocco or Tunisia
r5_match_merge<-r5_match_merge[r5_match_merge$country_name!="Algeria",]
r5_match_merge<-r5_match_merge[r5_match_merge$country_name!="Morocco",]
r5_match_merge<-r5_match_merge[r5_match_merge$country_name!="Tunisia",]


r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Botswana" & 
                                             r5_match_merge$pol_ethnic_identity=="Ndebele-Kalanga-(Tonga)",
                                           "Kalanga", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Cameroon" & 
                                             r5_match_merge$pol_ethnic_identity=="Bassa",
                                           "Bassa-Bakoko-Douala", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$pol_ethnic_identity=="Malinke ",
                                           "Malinke", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Mali" & 
                                             r5_match_merge$pol_ethnic_identity=="Fulani",
                                           "Peul-Fulani", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Mali" & 
                                             r5_match_merge$pol_ethnic_identity=="Senogu",
                                           "Senufo", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="South Africa" & 
                                             r5_match_merge$pol_ethnic_identity=="Afrikaner",
                                           "White", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="South Africa" & 
                                             r5_match_merge$pol_ethnic_identity=="White ",
                                           "White", r5_match_merge$pol_ethnic_identity)


r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Tanzania" & 
                                             r5_match_merge$pol_ethnic_identity=="Yao",
                                           "Yao-Mwera", r5_match_merge$pol_ethnic_identity)


r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Zimbabwe" & 
                                             r5_match_merge$pol_ethnic_identity=="Zezru",
                                           "Zezuru", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Zimbabwe" & 
                                             r5_match_merge$pol_ethnic_identity=="Maniyka",
                                           "Manyika", r5_match_merge$pol_ethnic_identity)

r5_match_merge$pol_ethnic_identity<-ifelse(r5_match_merge$country_name=="Zimbabwe" & 
                                             r5_match_merge$pol_ethnic_identity=="Tumbuka-Tonga-Nyakusya",
                                           "Ndebele-Kalanga-(Tonga)", r5_match_merge$pol_ethnic_identity)

#R6
r6_match_merge$nonresponse<-ifelse(r6_match_merge$Q87==-1|r6_match_merge$Q87==9999|
                                     r6_match_merge$Q87==9990|
                                     r6_match_merge$Q87==9995| r6_match_merge$Q87==9998,1,0)
r6_match_merge<-r6_match_merge[r6_match_merge$nonresponse==0,]


r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$pol_ethnic_identity=="Malinke ",
                                           "Malinke", r6_match_merge$pol_ethnic_identity)

r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="Mali" & 
                                             r6_match_merge$pol_ethnic_identity=="Fulani",
                                           "Peul-Fulani", r6_match_merge$pol_ethnic_identity)

r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="Mali" & 
                                             r6_match_merge$pol_ethnic_identity=="Senogu",
                                           "Senufo", r6_match_merge$pol_ethnic_identity)

r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="Morocco" & 
                                             r6_match_merge$pol_ethnic_identity=="Arab",
                                           "Arab-Berber", r6_match_merge$pol_ethnic_identity)

r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="South Africa" & 
                                             r6_match_merge$pol_ethnic_identity=="Afrikaner",
                                           "White", r6_match_merge$pol_ethnic_identity)

r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="South Africa" & 
                                             r6_match_merge$pol_ethnic_identity=="White ",
                                           "White", r6_match_merge$pol_ethnic_identity)

r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="Tanzania" & 
                                             r6_match_merge$pol_ethnic_identity=="Yao",
                                           "Yao-Mwera", r6_match_merge$pol_ethnic_identity)


r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="Zimbabwe" & 
                                             r6_match_merge$pol_ethnic_identity=="Zezru",
                                           "Zezuru", r6_match_merge$pol_ethnic_identity)


r6_match_merge$pol_ethnic_identity<-ifelse(r6_match_merge$country_name=="Zimbabwe" & 
                                             r6_match_merge$pol_ethnic_identity=="Tumbuka-Tonga-Nyakusya",
                                           "Ndebele-Kalanga-(Tonga)", r6_match_merge$pol_ethnic_identity)


#R7
r7_match_merge$nonresponse<-ifelse(r7_match_merge$Q84==-1|r7_match_merge$Q84==9999|
                                     r7_match_merge$Q84==9990|r7_match_merge$Q84==9995|
                                     r7_match_merge$Q84==9996| r7_match_merge$Q84==9998,1,0)
r7_match_merge<-r7_match_merge[r7_match_merge$nonresponse==0,]


r7_match_merge<-r7_match_merge[r7_match_merge$country_name!="Tunisia",]

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Botswana" & 
                                             r7_match_merge$pol_ethnic_identity=="Ndebele-Kalanga-(Tonga)",
                                           "Kalanga", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Cameroon" & 
                                             r7_match_merge$pol_ethnic_identity=="Bassa",
                                           "Bassa-Bakoko-Douala", r7_match_merge$pol_ethnic_identity)


r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$pol_ethnic_identity=="Malinke ",
                                           "Malinke", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Mali" & 
                                             r7_match_merge$pol_ethnic_identity=="Fulani",
                                           "Peul-Fulani", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Mali" & 
                                             r7_match_merge$pol_ethnic_identity=="Senogu",
                                           "Senufo", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Morocco" & 
                                             r7_match_merge$pol_ethnic_identity=="Arab",
                                           "Arab-Berber", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="South Africa" & 
                                             r7_match_merge$pol_ethnic_identity=="Afrikaner",
                                           "White", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="South Africa" & 
                                             r7_match_merge$pol_ethnic_identity=="White ",
                                           "White", r7_match_merge$pol_ethnic_identity)

r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Tanzania" & 
                                             r7_match_merge$pol_ethnic_identity=="Yao",
                                           "Yao-Mwera", r7_match_merge$pol_ethnic_identity)


r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Zimbabwe" & 
                                             r7_match_merge$pol_ethnic_identity=="Zezru",
                                           "Zezuru", r7_match_merge$pol_ethnic_identity)


r7_match_merge$pol_ethnic_identity<-ifelse(r7_match_merge$country_name=="Zimbabwe" & 
                                             r7_match_merge$pol_ethnic_identity=="Tumbuka-Tonga-Nyakusya",
                                           "Ndebele-Kalanga-(Tonga)", r7_match_merge$pol_ethnic_identity)



###Select Variables from each round and recode

###R3
r3_match_merge$ethnicity<-as.numeric(as.character(r3_match_merge$q79))
r3_match_merge$year<-format(as.Date(r3_match_merge$dateintr, format="%Y-%m-%d"),"%Y")


#Age: in years
r3_match_merge$q1<-ifelse(r3_match_merge$q1==-1|
                            r3_match_merge$q1==998|
                            r3_match_merge$q1==999, NA, r3_match_merge$q1)
r3_match_merge$age<-as.numeric(as.character(r3_match_merge$q1))

r3_match_merge$age18_35<-ifelse(r3_match_merge$age<35,1,0)
r3_match_merge$age35_49<-ifelse(r3_match_merge$age<50 & r3_match_merge$age>34,1,0)
r3_match_merge$age50_64<-ifelse(r3_match_merge$age<65 & r3_match_merge$age>49,1,0)
r3_match_merge$age65over<-ifelse(r3_match_merge$age>64,1,0)


#Political Interest: 1-3
r3_match_merge$q17<-ifelse(r3_match_merge$q17==-1|
                          r3_match_merge$q17==9|
                          r3_match_merge$q17==98|
                          r3_match_merge$q17==998, NA, r3_match_merge$q17)
r3_match_merge$pol_interest<-as.numeric(as.character(r3_match_merge$q17))
r3_match_merge$pol_interest<-car::recode(r3_match_merge$pol_interest, '0=1;1=2;2=3')

#Leaders help own community to leaders help everyone: 1-5
r3_match_merge$q21<-ifelse(r3_match_merge$q21==-1|
                            r3_match_merge$q21==9|
                            r3_match_merge$q21==98|
                            r3_match_merge$q21==998, NA, r3_match_merge$q21)
r3_match_merge$ethnic_help<-as.numeric(as.character(r3_match_merge$q21))
r3_match_merge$ethnic_help<-car::recode(r3_match_merge$ethnic_help, '4=1;3=2;5=3;2=4;1=5')


#Men better leaders to women equal chance: 1-5
r3_match_merge$q24<-ifelse(r3_match_merge$q24==-1|
                             r3_match_merge$q24==9|
                             r3_match_merge$q24==98|
                             r3_match_merge$q24==998, NA, r3_match_merge$q24)
r3_match_merge$wm_leaders<-as.numeric(as.character(r3_match_merge$q24))
r3_match_merge$wm_leaders<-car::recode(r3_match_merge$wm_leaders, '4=1;3=2;5=3;2=4;1=5')

#Voted in last election: 1,0
r3_match_merge$q30<-ifelse(r3_match_merge$q30==-1|
                             r3_match_merge$q30==9|
                             r3_match_merge$q30==98|
                             r3_match_merge$q30==998, NA, r3_match_merge$q30)
r3_match_merge$voted<-as.numeric(as.character(r3_match_merge$q30))
r3_match_merge$voted<-ifelse(r3_match_merge$voted==1,1,0)

#Attend community meeting: 1-5
r3_match_merge$q31a<-ifelse(r3_match_merge$q31a==-1|
                             r3_match_merge$q31a==9|
                             r3_match_merge$q31a==98|
                             r3_match_merge$q31a==998, NA, r3_match_merge$q31a)
r3_match_merge$attend_meeting<-as.numeric(as.character(r3_match_merge$q31a))
r3_match_merge$attend_meeting<-r3_match_merge$attend_meeting+1

#Join others to raise an issue: 1-5
r3_match_merge$q31b<-ifelse(r3_match_merge$q31b==-1|
                              r3_match_merge$q31b==9|
                              r3_match_merge$q31b==98|
                              r3_match_merge$q31b==998, NA, r3_match_merge$q31b)
r3_match_merge$join_others<-as.numeric(as.character(r3_match_merge$q31b))
r3_match_merge$join_others<-r3_match_merge$join_others+1

#Attend protest: 1-5
r3_match_merge$q31c<-ifelse(r3_match_merge$q31c==-1|
                              r3_match_merge$q31c==9|
                              r3_match_merge$q31c==98|
                              r3_match_merge$q31c==998, NA, r3_match_merge$q31c)
r3_match_merge$attend_protest<-as.numeric(as.character(r3_match_merge$q31c))
r3_match_merge$attend_protest<-r3_match_merge$attend_protest+1

#Contact local councillor: 1-4
r3_match_merge$q32a<-ifelse(r3_match_merge$q32a==-1|
                              r3_match_merge$q32a==9|
                              r3_match_merge$q32a==98|
                              r3_match_merge$q32a==998, NA, r3_match_merge$q32a)
r3_match_merge$contact_councillor<-as.numeric(as.character(r3_match_merge$q32a))
r3_match_merge$contact_councillor<-r3_match_merge$contact_councillor+1

#How often is ethnic group treated unfairly by the government?: 1-4
r3_match_merge$q81<-ifelse(r3_match_merge$q81==-1|
                              r3_match_merge$q81==9|
                              r3_match_merge$q81==98|r3_match_merge$q81==998|
                              r3_match_merge$q81==7, NA, r3_match_merge$q81)
r3_match_merge$ethnic_unfair<-as.numeric(as.character(r3_match_merge$q81))
r3_match_merge$ethnic_unfair<-r3_match_merge$ethnic_unfair+1


#Trust people from other ethnic groups: 1-4
r3_match_merge$q84d<-ifelse(r3_match_merge$q84d==-1|
                             r3_match_merge$q84d==9|r3_match_merge$q84d==997|
                             r3_match_merge$q84d==98|r3_match_merge$q84d==998|
                             r3_match_merge$q84d==7, NA, r3_match_merge$q84d)
r3_match_merge$trust_outgroup<-as.numeric(as.character(r3_match_merge$q84d))
r3_match_merge$trust_outgroup<-r3_match_merge$trust_outgroup+1

#Neighbor outgroup
r3_match_merge$neighbor_outgroup<-NA
r3_match_merge$ethnic_discriminated<-NA

#Education
r3_match_merge$q90<-ifelse(r3_match_merge$q90==-1|
                              r3_match_merge$q90==998|
                              r3_match_merge$q90==98|
                              r3_match_merge$q90==99, NA, r3_match_merge$q90)
r3_match_merge$education<-as.numeric(as.character(r3_match_merge$q90))

r3_match_merge$ed_belowsecondary<-ifelse(r3_match_merge$education==0|r3_match_merge$education==1|
                                           r3_match_merge$education==2|r3_match_merge$education==3,1,0)
r3_match_merge$ed_somesecondary<-ifelse(r3_match_merge$education==4,1,0)
r3_match_merge$ed_secondary<-ifelse(r3_match_merge$education==5|r3_match_merge$education==6|
                                        r3_match_merge$education==7,1,0)
r3_match_merge$ed_ba<-ifelse(r3_match_merge$education==8|r3_match_merge$education==9,1,0)



#Unemployed: 1,0
r3_match_merge$q94<-ifelse(r3_match_merge$q94==-1|
                             r3_match_merge$q94==9|
                             r3_match_merge$q94==98|r3_match_merge$q94==998|
                             r3_match_merge$q94==99, NA, r3_match_merge$q94)
r3_match_merge$unemployed<-as.numeric(as.character(r3_match_merge$q94))
r3_match_merge$unemployed<-ifelse(r3_match_merge$unemployed==1, 1, 0)

#Female: 1,0
r3_match_merge$q101<-ifelse(r3_match_merge$q101==-1|
                             r3_match_merge$q101==9|
                             r3_match_merge$q101==98|
                             r3_match_merge$q101==99, NA, r3_match_merge$q101)
r3_match_merge$female<-as.numeric(as.character(r3_match_merge$q101))
r3_match_merge$female<-ifelse(r3_match_merge$female==2,1,0)


#Never gone without food: 1,0
r3_match_merge$q8a<-ifelse(r3_match_merge$q8a==-1|
                              r3_match_merge$q8a==9|
                              r3_match_merge$q8a==98|
                              r3_match_merge$q8a==998, NA, r3_match_merge$q8a)
r3_match_merge$had_food<-as.numeric(as.character(r3_match_merge$q8a))
r3_match_merge$had_food<-ifelse(r3_match_merge$had_food==0,1,0)

#Own a television: 1,0
r3_match_merge$q93c<-ifelse(r3_match_merge$q93c==-1|
                             r3_match_merge$q93c==9|
                             r3_match_merge$q93c==98|
                             r3_match_merge$q93c==998, NA, r3_match_merge$q93c)
r3_match_merge$own_tv<-as.numeric(as.character(r3_match_merge$q93c))
r3_match_merge$own_tv<-ifelse(r3_match_merge$own_tv==1,1,0)





###R4
r4_match_merge$ethnicity<-as.numeric(as.character(r4_match_merge$Q79))
r4_match_merge$year<-format(as.Date(r4_match_merge$DATEINTR, format="%Y-%m-%d"),"%Y")


#Age: in years
r4_match_merge$Q1<-ifelse(r4_match_merge$Q1==-1|
                            r4_match_merge$Q1==998|
                            r4_match_merge$Q1==999, NA, r4_match_merge$Q1)
r4_match_merge$age<-as.numeric(as.character(r4_match_merge$Q1))

r4_match_merge$age18_35<-ifelse(r4_match_merge$age<35,1,0)
r4_match_merge$age35_49<-ifelse(r4_match_merge$age<50 & r4_match_merge$age>34,1,0)
r4_match_merge$age50_64<-ifelse(r4_match_merge$age<65 & r4_match_merge$age>49,1,0)
r4_match_merge$age65over<-ifelse(r4_match_merge$age>64,1,0)


#Political Interest: 1-3
r4_match_merge$Q14<-ifelse(r4_match_merge$Q14==-1|
                             r4_match_merge$Q14==9|
                             r4_match_merge$Q14==98|
                             r4_match_merge$Q14==998, NA, r4_match_merge$Q14)
r4_match_merge$pol_interest<-as.numeric(as.character(r4_match_merge$Q14))
r4_match_merge$pol_interest<-car::recode(r4_match_merge$pol_interest, '0=1;1=2;2=3')

#Women leaders
r4_match_merge$wm_leaders<-NA

#Leaders help own community to leaders help everyone: 1-5
r4_match_merge$Q17<-ifelse(r4_match_merge$Q17==-1|
                             r4_match_merge$Q17==9|
                             r4_match_merge$Q17==98|
                             r4_match_merge$Q17==998, NA, r4_match_merge$Q17)
r4_match_merge$ethnic_help<-as.numeric(as.character(r4_match_merge$Q17))
r4_match_merge$ethnic_help<-car::recode(r4_match_merge$ethnic_help, '4=1;3=2;5=3;2=4;1=5')

#Voted in last election: 1,0
r4_match_merge$Q23D<-ifelse(r4_match_merge$Q23D==-1|
                             r4_match_merge$Q23D==9|
                             r4_match_merge$Q23D==98|
                             r4_match_merge$Q23D==998, NA, r4_match_merge$Q23D)
r4_match_merge$voted<-as.numeric(as.character(r4_match_merge$Q23D))
r4_match_merge$voted<-ifelse(r4_match_merge$voted==1,1,0)

#Attend community meeting: 1-5
r4_match_merge$Q23A<-ifelse(r4_match_merge$Q23A==-1|
                              r4_match_merge$Q23A==9|
                              r4_match_merge$Q23A==98|
                              r4_match_merge$Q23A==998, NA, r4_match_merge$Q23A)
r4_match_merge$attend_meeting<-as.numeric(as.character(r4_match_merge$Q23A))
r4_match_merge$attend_meeting<-r4_match_merge$attend_meeting+1

#Join others to raise an issue: 1-5
r4_match_merge$Q23B<-ifelse(r4_match_merge$Q23B==-1|
                              r4_match_merge$Q23B==9|
                              r4_match_merge$Q23B==98|
                              r4_match_merge$Q23B==998, NA, r4_match_merge$Q23B)
r4_match_merge$join_others<-as.numeric(as.character(r4_match_merge$Q23B))
r4_match_merge$join_others<-r4_match_merge$join_others+1

#Attend protest: 1-5
r4_match_merge$Q23C<-ifelse(r4_match_merge$Q23C==-1|
                              r4_match_merge$Q23C==9|
                              r4_match_merge$Q23C==98|
                              r4_match_merge$Q23C==998, NA, r4_match_merge$Q23C)
r4_match_merge$attend_protest<-as.numeric(as.character(r4_match_merge$Q23C))
r4_match_merge$attend_protest<-r4_match_merge$attend_protest+1

#Contact local councillor: 1-4
r4_match_merge$Q25A<-ifelse(r4_match_merge$Q25A==-1|
                              r4_match_merge$Q25A==9|
                              r4_match_merge$Q25A==98|
                              r4_match_merge$Q25A==998, NA, r4_match_merge$Q25A)
r4_match_merge$contact_councillor<-as.numeric(as.character(r4_match_merge$Q25A))
r4_match_merge$contact_councillor<-r4_match_merge$contact_councillor+1

#How often is ethnic group treated unfairly by the government?: 1-4
r4_match_merge$Q82<-ifelse(r4_match_merge$Q82==-1|
                             r4_match_merge$Q82==9|
                             r4_match_merge$Q82==98|r4_match_merge$Q82==998|
                             r4_match_merge$Q82==7, NA, r4_match_merge$Q82)
r4_match_merge$ethnic_unfair<-as.numeric(as.character(r4_match_merge$Q82))
r4_match_merge$ethnic_unfair<-r4_match_merge$ethnic_unfair+1

#Trust outgroup
r4_match_merge$trust_outgroup<-NA
r4_match_merge$neighbor_outgroup<-NA
r4_match_merge$ethnic_discriminated<-NA

#Education
r4_match_merge$Q89<-ifelse(r4_match_merge$Q89==-1|
                             r4_match_merge$Q89==998|
                             r4_match_merge$Q89==98|
                             r4_match_merge$Q89==99, NA, r4_match_merge$Q89)
r4_match_merge$education<-as.numeric(as.character(r4_match_merge$Q89))

r4_match_merge$ed_belowsecondary<-ifelse(r4_match_merge$education==0|r4_match_merge$education==1|
                                           r4_match_merge$education==2|r4_match_merge$education==3,1,0)
r4_match_merge$ed_somesecondary<-ifelse(r4_match_merge$education==4,1,0)
r4_match_merge$ed_secondary<-ifelse(r4_match_merge$education==5|r4_match_merge$education==6|
                                      r4_match_merge$education==7,1,0)
r4_match_merge$ed_ba<-ifelse(r4_match_merge$education==8|r4_match_merge$education==9,1,0)



#Unemployed: 1,0
r4_match_merge$Q94<-ifelse(r4_match_merge$Q94==-1|
                             r4_match_merge$Q94==9|
                             r4_match_merge$Q94==98|r4_match_merge$Q94==998|
                             r4_match_merge$Q94==99, NA, r4_match_merge$Q94)
r4_match_merge$unemployed<-as.numeric(as.character(r4_match_merge$Q94))
r4_match_merge$unemployed<-ifelse(r4_match_merge$unemployed==1, 1, 0)

#Female: 1,0
r4_match_merge$Q101<-ifelse(r4_match_merge$Q101==-1|
                              r4_match_merge$Q101==9|
                              r4_match_merge$Q101==98|
                              r4_match_merge$Q101==99, NA, r4_match_merge$Q101)
r4_match_merge$female<-as.numeric(as.character(r4_match_merge$Q101))
r4_match_merge$female<-ifelse(r4_match_merge$female==2,1,0)


#Never gone without food: 1,0
r4_match_merge$Q8A<-ifelse(r4_match_merge$Q8A==-1|
                             r4_match_merge$Q8A==9|
                             r4_match_merge$Q8A==98|
                             r4_match_merge$Q8A==998, NA, r4_match_merge$Q8A)
r4_match_merge$had_food<-as.numeric(as.character(r4_match_merge$Q8A))
r4_match_merge$had_food<-ifelse(r4_match_merge$had_food==0,1,0)

#Own a television: 1,0
r4_match_merge$Q92B<-ifelse(r4_match_merge$Q92B==-1|
                              r4_match_merge$Q92B==9|
                              r4_match_merge$Q92B==98|
                              r4_match_merge$Q92B==998, NA, r4_match_merge$Q92B)
r4_match_merge$own_tv<-as.numeric(as.character(r4_match_merge$Q92B))
r4_match_merge$own_tv<-ifelse(r4_match_merge$own_tv==1,1,0)






###R5
r5_match_merge$ethnicity<-as.numeric(as.character(r5_match_merge$Q84))
r5_match_merge$year<-format(as.Date(r5_match_merge$DATEINTR, format="%Y-%m-%d"),"%Y")


#Age: in years
r5_match_merge$Q1<-ifelse(r5_match_merge$Q1==-1|
                            r5_match_merge$Q1==998|
                            r5_match_merge$Q1==999, NA, r5_match_merge$Q1)
r5_match_merge$age<-as.numeric(as.character(r5_match_merge$Q1))

r5_match_merge$age18_35<-ifelse(r5_match_merge$age<35,1,0)
r5_match_merge$age35_49<-ifelse(r5_match_merge$age<50 & r5_match_merge$age>34,1,0)
r5_match_merge$age50_64<-ifelse(r5_match_merge$age<65 & r5_match_merge$age>49,1,0)
r5_match_merge$age65over<-ifelse(r5_match_merge$age>64,1,0)


#Political Interest: 1-3
r5_match_merge$Q15<-ifelse(r5_match_merge$Q15==-1|
                             r5_match_merge$Q15==9|
                             r5_match_merge$Q15==98|
                             r5_match_merge$Q15==998, NA, r5_match_merge$Q15)
r5_match_merge$pol_interest<-as.numeric(as.character(r5_match_merge$Q15))
r5_match_merge$pol_interest<-car::recode(r5_match_merge$pol_interest, '0=1;1=2;2=3')

#Leaders help own community to leaders help everyone: 1-5
r5_match_merge$Q18<-ifelse(r5_match_merge$Q18==-1|
                             r5_match_merge$Q18==9|
                             r5_match_merge$Q18==98|
                             r5_match_merge$Q18==998, NA, r5_match_merge$Q18)
r5_match_merge$ethnic_help<-as.numeric(as.character(r5_match_merge$Q18))
r5_match_merge$ethnic_help<-car::recode(r5_match_merge$ethnic_help, '1=1;2=2;5=3;3=4;4=5')


#Men better leaders to women equal chance: 1-5
r5_match_merge$Q22<-ifelse(r5_match_merge$Q22==-1|
                             r5_match_merge$Q22==9|
                             r5_match_merge$Q22==98|
                             r5_match_merge$Q22==998, NA, r5_match_merge$Q22)
r5_match_merge$wm_leaders<-as.numeric(as.character(r5_match_merge$Q22))
r5_match_merge$wm_leaders<-car::recode(r5_match_merge$wm_leaders, '1=1;2=2;5=3;3=4;4=5')

#Voted in last election: 1,0
r5_match_merge$Q27<-ifelse(r5_match_merge$Q27==-1|
                             r5_match_merge$Q27==9|
                             r5_match_merge$Q27==98|
                             r5_match_merge$Q27==998, NA, r5_match_merge$Q27)
r5_match_merge$voted<-as.numeric(as.character(r5_match_merge$Q27))
r5_match_merge$voted<-ifelse(r5_match_merge$voted==1,1,0)

#Attend community meeting: 1-5
r5_match_merge$Q26A<-ifelse(r5_match_merge$Q26A==-1|
                              r5_match_merge$Q26A==9|
                              r5_match_merge$Q26A==98|
                              r5_match_merge$Q26A==998, NA, r5_match_merge$Q26A)
r5_match_merge$attend_meeting<-as.numeric(as.character(r5_match_merge$Q26A))
r5_match_merge$attend_meeting<-r5_match_merge$attend_meeting+1

#Join others to raise an issue: 1-5
r5_match_merge$Q26B<-ifelse(r5_match_merge$Q26B==-1|
                              r5_match_merge$Q26B==9|
                              r5_match_merge$Q26B==98|
                              r5_match_merge$Q26B==998, NA, r5_match_merge$Q26B)
r5_match_merge$join_others<-as.numeric(as.character(r5_match_merge$Q26B))
r5_match_merge$join_others<-r5_match_merge$join_others+1

#Attend protest: 1-5
r5_match_merge$Q26D<-ifelse(r5_match_merge$Q26D==-1|
                              r5_match_merge$Q26D==9|
                              r5_match_merge$Q26D==98|
                              r5_match_merge$Q26D==998, NA, r5_match_merge$Q26D)
r5_match_merge$attend_protest<-as.numeric(as.character(r5_match_merge$Q26D))
r5_match_merge$attend_protest<-r5_match_merge$attend_protest+1

#Contact local councillor: 1-4
r5_match_merge$Q30A<-ifelse(r5_match_merge$Q30A==-1|
                              r5_match_merge$Q30A==9|
                              r5_match_merge$Q30A==98|
                              r5_match_merge$Q30A==998, NA, r5_match_merge$Q30A)
r5_match_merge$contact_councillor<-as.numeric(as.character(r5_match_merge$Q30A))
r5_match_merge$contact_councillor<-r5_match_merge$contact_councillor+1

#How often is ethnic group treated unfairly by the government?: 1-4
r5_match_merge$Q85A<-ifelse(r5_match_merge$Q85A==-1|
                             r5_match_merge$Q85A==9|
                             r5_match_merge$Q85A==98|r5_match_merge$Q85A==998|
                             r5_match_merge$Q85A==7, NA, r5_match_merge$Q85A)
r5_match_merge$ethnic_unfair<-as.numeric(as.character(r5_match_merge$Q85A))
r5_match_merge$ethnic_unfair<-r5_match_merge$ethnic_unfair+1

#Trust outgroup
r5_match_merge$trust_outgroup<-NA
r5_match_merge$neighbor_outgroup<-NA
r5_match_merge$ethnic_discriminated<-NA

#Education
r5_match_merge$Q97<-ifelse(r5_match_merge$Q97==-1|
                             r5_match_merge$Q97==998|
                             r5_match_merge$Q97==98|
                             r5_match_merge$Q97==99, NA, r5_match_merge$Q97)
r5_match_merge$education<-as.numeric(as.character(r5_match_merge$Q97))

r5_match_merge$ed_belowsecondary<-ifelse(r5_match_merge$education==0|r5_match_merge$education==1|
                                           r5_match_merge$education==2|r5_match_merge$education==3,1,0)
r5_match_merge$ed_somesecondary<-ifelse(r5_match_merge$education==4,1,0)
r5_match_merge$ed_secondary<-ifelse(r5_match_merge$education==5|r5_match_merge$education==6|
                                      r5_match_merge$education==7,1,0)
r5_match_merge$ed_ba<-ifelse(r5_match_merge$education==8|r5_match_merge$education==9,1,0)



#Unemployed: 1,0
r5_match_merge$Q96<-ifelse(r5_match_merge$Q96==-1|
                             r5_match_merge$Q96==9|
                             r5_match_merge$Q96==98|r5_match_merge$Q96==998|
                             r5_match_merge$Q96==99, NA, r5_match_merge$Q96)
r5_match_merge$unemployed<-as.numeric(as.character(r5_match_merge$Q96))
r5_match_merge$unemployed<-ifelse(r5_match_merge$unemployed==1, 1, 0)

#Female: 1,0
r5_match_merge$Q101<-ifelse(r5_match_merge$Q101==-1|
                              r5_match_merge$Q101==9|
                              r5_match_merge$Q101==98|
                              r5_match_merge$Q101==99, NA, r5_match_merge$Q101)
r5_match_merge$female<-as.numeric(as.character(r5_match_merge$Q101))
r5_match_merge$female<-ifelse(r5_match_merge$female==2,1,0)


#Never gone without food: 1,0
r5_match_merge$Q8A<-ifelse(r5_match_merge$Q8A==-1|
                             r5_match_merge$Q8A==9|
                             r5_match_merge$Q8A==98|
                             r5_match_merge$Q8A==998, NA, r5_match_merge$Q8A)
r5_match_merge$had_food<-as.numeric(as.character(r5_match_merge$Q8A))
r5_match_merge$had_food<-ifelse(r5_match_merge$had_food==0,1,0)

#Own a television: 1,0
r5_match_merge$Q90B<-ifelse(r5_match_merge$Q90B==-1|
                              r5_match_merge$Q90B==9|
                              r5_match_merge$Q90B==98|
                              r5_match_merge$Q90B==998, NA, r5_match_merge$Q90B)
r5_match_merge$own_tv<-as.numeric(as.character(r5_match_merge$Q90B))
r5_match_merge$own_tv<-ifelse(r5_match_merge$own_tv==1,1,0)





###R6
r6_match_merge$ethnicity<-as.numeric(as.character(r6_match_merge$Q87))
r6_match_merge$year<-format(as.Date(r6_match_merge$DATEINTR, format="%Y-%m-%d"),"%Y")


#Age: in years
r6_match_merge$Q1<-ifelse(r6_match_merge$Q1==-1|
                            r6_match_merge$Q1==998|
                            r6_match_merge$Q1==999, NA, r6_match_merge$Q1)
r6_match_merge$age<-as.numeric(as.character(r6_match_merge$Q1))

r6_match_merge$age18_35<-ifelse(r6_match_merge$age<35,1,0)
r6_match_merge$age35_49<-ifelse(r6_match_merge$age<50 & r6_match_merge$age>34,1,0)
r6_match_merge$age50_64<-ifelse(r6_match_merge$age<65 & r6_match_merge$age>49,1,0)
r6_match_merge$age65over<-ifelse(r6_match_merge$age>64,1,0)


#Political Interest: 1-4
r6_match_merge$Q14<-ifelse(r6_match_merge$Q14==-1|
                             r6_match_merge$Q14==9|
                             r6_match_merge$Q14==98|
                             r6_match_merge$Q14==998, NA, r6_match_merge$Q14)
r6_match_merge$pol_interest<-as.numeric(as.character(r6_match_merge$Q14))
r6_match_merge$pol_interest<-car::recode(r6_match_merge$pol_interest, '0=1;1=2;2=3;3=4')

#Men better leaders to women equal chance: 1-5
r6_match_merge$Q18<-ifelse(r6_match_merge$Q18==-1|
                             r6_match_merge$Q18==9|
                             r6_match_merge$Q18==98|
                             r6_match_merge$Q18==998, NA, r6_match_merge$Q18)
r6_match_merge$wm_leaders<-as.numeric(as.character(r6_match_merge$Q18))
r6_match_merge$wm_leaders<-car::recode(r6_match_merge$wm_leaders, '1=1;2=2;5=3;3=4;4=5')

#Ethnic help
r6_match_merge$ethnic_help<-NA

#Voted in last election: 1,0
r6_match_merge$Q21<-ifelse(r6_match_merge$Q21==-1|
                             r6_match_merge$Q21==9|
                             r6_match_merge$Q21==98|
                             r6_match_merge$Q21==998, NA, r6_match_merge$Q21)
r6_match_merge$voted<-as.numeric(as.character(r6_match_merge$Q21))
r6_match_merge$voted<-ifelse(r6_match_merge$voted==1,1,0)

#Attend community meeting: 1-5
r6_match_merge$Q20A<-ifelse(r6_match_merge$Q20A==-1|
                              r6_match_merge$Q20A==9|
                              r6_match_merge$Q20A==98|
                              r6_match_merge$Q20A==998, NA, r6_match_merge$Q20A)
r6_match_merge$attend_meeting<-as.numeric(as.character(r6_match_merge$Q20A))
r6_match_merge$attend_meeting<-r6_match_merge$attend_meeting+1

#Join others to raise an issue: 1-5
r6_match_merge$Q20B<-ifelse(r6_match_merge$Q20B==-1|
                              r6_match_merge$Q20B==9|
                              r6_match_merge$Q20B==98|
                              r6_match_merge$Q20B==998, NA, r6_match_merge$Q20B)
r6_match_merge$join_others<-as.numeric(as.character(r6_match_merge$Q20B))
r6_match_merge$join_others<-r6_match_merge$join_others+1

#Attend protest: 1-5
r6_match_merge$Q27E<-ifelse(r6_match_merge$Q27E==-1|
                              r6_match_merge$Q27E==9|
                              r6_match_merge$Q27E==98|
                              r6_match_merge$Q27E==998, NA, r6_match_merge$Q27E)
r6_match_merge$attend_protest<-as.numeric(as.character(r6_match_merge$Q27E))
r6_match_merge$attend_protest<-r6_match_merge$attend_protest+1

#Contact local councillor: 1-4
r6_match_merge$Q24A<-ifelse(r6_match_merge$Q24A==-1|
                              r6_match_merge$Q24A==9|
                              r6_match_merge$Q24A==98|r6_match_merge$Q24A==99|
                              r6_match_merge$Q24A==998, NA, r6_match_merge$Q24A)
r6_match_merge$contact_councillor<-as.numeric(as.character(r6_match_merge$Q24A))
r6_match_merge$contact_councillor<-r6_match_merge$contact_councillor+1

#How often is ethnic group treated unfairly by the government?: 1-4
r6_match_merge$Q88A<-ifelse(r6_match_merge$Q88A==-1|
                             r6_match_merge$Q88A==9|
                             r6_match_merge$Q88A==98|r6_match_merge$Q88A==998|
                             r6_match_merge$Q88A==7, NA, r6_match_merge$Q88A)
r6_match_merge$ethnic_unfair<-as.numeric(as.character(r6_match_merge$Q88A))
r6_match_merge$ethnic_unfair<-r6_match_merge$ethnic_unfair+1


#Neighbor ethnic groups: 1-5
r6_match_merge$Q89B<-ifelse(r6_match_merge$Q89B==-1|r6_match_merge$Q89B==99|
                              r6_match_merge$Q89B==9|r6_match_merge$Q89B==997|
                              r6_match_merge$Q89B==98|r6_match_merge$Q89B==998|
                              r6_match_merge$Q89B==7, NA, r6_match_merge$Q89B)
r6_match_merge$neighbor_outgroup<-as.numeric(as.character(r6_match_merge$Q89B))
r6_match_merge$neighbor_outgroup<-r6_match_merge$neighbor_outgroup

r6_match_merge$trust_outgroup<-NA
r6_match_merge$ethnic_discriminated<-NA

#Education
r6_match_merge$Q97<-ifelse(r6_match_merge$Q97==-1|
                             r6_match_merge$Q97==998|
                             r6_match_merge$Q97==98|
                             r6_match_merge$Q97==99, NA, r6_match_merge$Q97)
r6_match_merge$education<-as.numeric(as.character(r6_match_merge$Q97))

r6_match_merge$ed_belowsecondary<-ifelse(r6_match_merge$education==0|r6_match_merge$education==1|
                                           r6_match_merge$education==2|r6_match_merge$education==3,1,0)
r6_match_merge$ed_somesecondary<-ifelse(r6_match_merge$education==4,1,0)
r6_match_merge$ed_secondary<-ifelse(r6_match_merge$education==5|r6_match_merge$education==6|
                                      r6_match_merge$education==7,1,0)
r6_match_merge$ed_ba<-ifelse(r6_match_merge$education==8|r6_match_merge$education==9,1,0)



#Unemployed: 1,0
r6_match_merge$Q95<-ifelse(r6_match_merge$Q95==-1|
                             r6_match_merge$Q95==9|
                             r6_match_merge$Q95==98|r6_match_merge$Q95==998|
                             r6_match_merge$Q95==99, NA, r6_match_merge$Q95)
r6_match_merge$unemployed<-as.numeric(as.character(r6_match_merge$Q95))
r6_match_merge$unemployed<-ifelse(r6_match_merge$unemployed==1, 1, 0)

#Female: 1,0
r6_match_merge$Q101<-ifelse(r6_match_merge$Q101==-1|
                              r6_match_merge$Q101==9|
                              r6_match_merge$Q101==98|
                              r6_match_merge$Q101==99, NA, r6_match_merge$Q101)
r6_match_merge$female<-as.numeric(as.character(r6_match_merge$Q101))
r6_match_merge$female<-ifelse(r6_match_merge$female==2,1,0)


#Never gone without food: 1,0
r6_match_merge$Q8A<-ifelse(r6_match_merge$Q8A==-1|
                             r6_match_merge$Q8A==9|
                             r6_match_merge$Q8A==98|
                             r6_match_merge$Q8A==998, NA, r6_match_merge$Q8A)
r6_match_merge$had_food<-as.numeric(as.character(r6_match_merge$Q8A))
r6_match_merge$had_food<-ifelse(r6_match_merge$had_food==0,1,0)

#Own a television: 1,0
r6_match_merge$Q91B<-ifelse(r6_match_merge$Q91B==-1|
                              r6_match_merge$Q91B==9|
                              r6_match_merge$Q91B==98|
                              r6_match_merge$Q91B==998, NA, r6_match_merge$Q91B)
r6_match_merge$own_tv<-as.numeric(as.character(r6_match_merge$Q91B))
r6_match_merge$own_tv<-ifelse(r6_match_merge$own_tv==1,1,0)







###R7
r7_match_merge$ethnicity<-as.numeric(as.character(r7_match_merge$Q84))
r7_match_merge$year<-format(as.Date(r7_match_merge$DATEINTR, format="%Y-%m-%d"),"%Y")


#Age: in years
r7_match_merge$Q1<-ifelse(r7_match_merge$Q1==-1|
                            r7_match_merge$Q1==998|
                            r7_match_merge$Q1==999, NA, r7_match_merge$Q1)
r7_match_merge$age<-as.numeric(as.character(r7_match_merge$Q1))

r7_match_merge$age18_35<-ifelse(r7_match_merge$age<35,1,0)
r7_match_merge$age35_49<-ifelse(r7_match_merge$age<50 & r7_match_merge$age>34,1,0)
r7_match_merge$age50_64<-ifelse(r7_match_merge$age<65 & r7_match_merge$age>49,1,0)
r7_match_merge$age65over<-ifelse(r7_match_merge$age>64,1,0)


#Political Interest: 1-3
r7_match_merge$Q13<-ifelse(r7_match_merge$Q13==-1|
                             r7_match_merge$Q13==9|
                             r7_match_merge$Q13==8|
                             r7_match_merge$Q13==998, NA, r7_match_merge$Q13)
r7_match_merge$pol_interest<-as.numeric(as.character(r7_match_merge$Q13))
r7_match_merge$pol_interest<-car::recode(r7_match_merge$pol_interest, '0=1;1=2;2=3')

#Men better leaders to women equal chance: 1-5
r7_match_merge$Q16<-ifelse(r7_match_merge$Q16==-1|
                             r7_match_merge$Q16==9|
                             r7_match_merge$Q16==8|
                             r7_match_merge$Q16==998, NA, r7_match_merge$Q16)
r7_match_merge$wm_leaders<-as.numeric(as.character(r7_match_merge$Q16))
r7_match_merge$wm_leaders<-car::recode(r7_match_merge$wm_leaders, '1=1;2=2;5=3;3=4;4=5')

#Ethnic help
r7_match_merge$ethnic_help<-NA

#Voted in last election: 1,0
r7_match_merge$Q22<-ifelse(r7_match_merge$Q22==-1|
                             r7_match_merge$Q22==9|
                             r7_match_merge$Q22==98|
                             r7_match_merge$Q22==998, NA, r7_match_merge$Q22)
r7_match_merge$voted<-as.numeric(as.character(r7_match_merge$Q22))
r7_match_merge$voted<-ifelse(r7_match_merge$voted==1,1,0)

#Attend community meeting: 1-5
r7_match_merge$Q21A<-ifelse(r7_match_merge$Q21A==-1|
                              r7_match_merge$Q21A==9|
                              r7_match_merge$Q21A==8|
                              r7_match_merge$Q21A==998, NA, r7_match_merge$Q21A)
r7_match_merge$attend_meeting<-as.numeric(as.character(r7_match_merge$Q21A))
r7_match_merge$attend_meeting<-r7_match_merge$attend_meeting+1

#Join others to raise an issue: 1-5
r7_match_merge$Q21B<-ifelse(r7_match_merge$Q21B==-1|
                              r7_match_merge$Q21B==9|
                              r7_match_merge$Q21B==98|
                              r7_match_merge$Q21B==998, NA, r7_match_merge$Q21B)
r7_match_merge$join_others<-as.numeric(as.character(r7_match_merge$Q21B))
r7_match_merge$join_others<-r7_match_merge$join_others+1

#Attend protest: 1-5
r7_match_merge$Q26E<-ifelse(r7_match_merge$Q26E==-1|
                              r7_match_merge$Q26E==9|
                              r7_match_merge$Q26E==8|
                              r7_match_merge$Q26E==998, NA, r7_match_merge$Q26E)
r7_match_merge$attend_protest<-as.numeric(as.character(r7_match_merge$Q26E))
r7_match_merge$attend_protest<-r7_match_merge$attend_protest+1

#Contact local councillor: 1-4
r7_match_merge$Q25A<-ifelse(r7_match_merge$Q25A==-1|
                              r7_match_merge$Q25A==9|
                              r7_match_merge$Q25A==8|
                              r7_match_merge$Q25A==998, NA, r7_match_merge$Q25A)
r7_match_merge$contact_councillor<-as.numeric(as.character(r7_match_merge$Q25A))
r7_match_merge$contact_councillor<-r7_match_merge$contact_councillor+1

#How often is ethnic group treated unfairly by the government?: 1-4
r7_match_merge$Q85A<-ifelse(r7_match_merge$Q85A==-1|
                             r7_match_merge$Q85A==9|
                             r7_match_merge$Q85A==8|r7_match_merge$Q85A==99|
                             r7_match_merge$Q85A==7, NA, r7_match_merge$Q85A)
r7_match_merge$ethnic_unfair<-as.numeric(as.character(r7_match_merge$Q85A))
r7_match_merge$ethnic_unfair<-r7_match_merge$ethnic_unfair+1


#Neighbors from other ethnic groups: 1-4
r7_match_merge$Q86C<-ifelse(r7_match_merge$Q86C==-1|
                              r7_match_merge$Q86C==9|r7_match_merge$Q86C==997|
                              r7_match_merge$Q86C==98|r7_match_merge$Q86C==998|
                              r7_match_merge$Q86C==8, NA, r7_match_merge$Q86C)
r7_match_merge$ethnic_discriminated<-as.numeric(as.character(r7_match_merge$Q86C))
r7_match_merge$ethnic_discriminated<-r7_match_merge$ethnic_discriminated+1

r7_match_merge$neighbor_outgroup<-NA
r7_match_merge$trust_outgroup<-NA

#Education
r7_match_merge$Q97<-ifelse(r7_match_merge$Q97==-1|
                             r7_match_merge$Q97==998|
                             r7_match_merge$Q97==98|
                             r7_match_merge$Q97==99, NA, r7_match_merge$Q97)
r7_match_merge$education<-as.numeric(as.character(r7_match_merge$Q97))

r7_match_merge$ed_belowsecondary<-ifelse(r7_match_merge$education==0|r7_match_merge$education==1|
                                           r7_match_merge$education==2|r7_match_merge$education==3,1,0)
r7_match_merge$ed_somesecondary<-ifelse(r7_match_merge$education==4,1,0)
r7_match_merge$ed_secondary<-ifelse(r7_match_merge$education==5|r7_match_merge$education==6|
                                      r7_match_merge$education==7,1,0)
r7_match_merge$ed_ba<-ifelse(r7_match_merge$education==8|r7_match_merge$education==9,1,0)



#Unemployed: 1,0
r7_match_merge$Q94<-ifelse(r7_match_merge$Q94==-1|
                             r7_match_merge$Q94==9|
                             r7_match_merge$Q94==98|r7_match_merge$Q94==998|
                             r7_match_merge$Q94==99, NA, r7_match_merge$Q94)
r7_match_merge$unemployed<-as.numeric(as.character(r7_match_merge$Q94))
r7_match_merge$unemployed<-ifelse(r7_match_merge$unemployed==1, 1, 0)

#Female: 1,0
r7_match_merge$Q101<-ifelse(r7_match_merge$Q101==-1|
                              r7_match_merge$Q101==9|
                              r7_match_merge$Q101==98|
                              r7_match_merge$Q101==99, NA, r7_match_merge$Q101)
r7_match_merge$female<-as.numeric(as.character(r7_match_merge$Q101))
r7_match_merge$female<-ifelse(r7_match_merge$female==2,1,0)


#Never gone without food: 1,0
r7_match_merge$Q8A<-ifelse(r7_match_merge$Q8A==-1|
                             r7_match_merge$Q8A==9|
                             r7_match_merge$Q8A==8|
                             r7_match_merge$Q8A==998, NA, r7_match_merge$Q8A)
r7_match_merge$had_food<-as.numeric(as.character(r7_match_merge$Q8A))
r7_match_merge$had_food<-ifelse(r7_match_merge$had_food==0,1,0)

#Own a television: 1,0
r7_match_merge$Q89B<-ifelse(r7_match_merge$Q89B==-1|
                              r7_match_merge$Q89B==9|
                              r7_match_merge$Q89B==8|
                              r7_match_merge$Q89B==998, NA, r7_match_merge$Q89B)
r7_match_merge$own_tv<-as.numeric(as.character(r7_match_merge$Q89B))
r7_match_merge$own_tv<-ifelse(r7_match_merge$own_tv==2,1,0)




###Gather into one dataframe
r3_match_merge$round<-3
r4_match_merge$round<-4
r5_match_merge$round<-5
r6_match_merge$round<-6
r7_match_merge$round<-7

#Fix Ivory Coast spelling
r5_match_merge$country_name<-ifelse(r5_match_merge$country_name=="Cote d’Ivoire", "Ivory Coast", r5_match_merge$country_name)
r6_match_merge$country_name<-ifelse(r6_match_merge$country_name=="Cote d'Ivoire", "Ivory Coast", r6_match_merge$country_name)
r7_match_merge$country_name<-ifelse(r7_match_merge$country_name=="Côte d'Ivoire", "Ivory Coast", r7_match_merge$country_name)

r3_match_final<-dplyr::select(r3_match_merge, c("pol_ethnic_identity", "country_name","ethnicity", "year",
                                                "age", "age18_35", "age35_49",
                                                "age50_64", "age65over", "pol_interest", "wm_leaders", "voted", "attend_meeting",
                                                "join_others", "attend_protest", "contact_councillor", "ethnic_unfair",
                                                "trust_outgroup", "ethnic_discriminated", "neighbor_outgroup", "education", "ed_belowsecondary",
                                                "ed_somesecondary", "ed_secondary", "ed_ba", "unemployed", "female",
                                                "had_food", "own_tv", "round"))

r4_match_final<-dplyr::select(r4_match_merge, c("pol_ethnic_identity", "country_name","ethnicity", "year", 
                                                "age", "age18_35", "age35_49",
                                                "age50_64", "age65over", "pol_interest", "wm_leaders", "voted", "attend_meeting",
                                                "join_others", "attend_protest", "contact_councillor", "ethnic_unfair",
                                                "trust_outgroup", "ethnic_discriminated", "neighbor_outgroup", "education", "ed_belowsecondary",
                                                "ed_somesecondary", "ed_secondary", "ed_ba", "unemployed", "female",
                                                "had_food", "own_tv", "round"))

r5_match_final<-dplyr::select(r5_match_merge, c("pol_ethnic_identity", "country_name","ethnicity", "year",
                                                "age", "age18_35", "age35_49",
                                                "age50_64", "age65over", "pol_interest", "wm_leaders", "voted", "attend_meeting",
                                                "join_others", "attend_protest", "contact_councillor", "ethnic_unfair",
                                                "trust_outgroup", "ethnic_discriminated", "neighbor_outgroup", "education", "ed_belowsecondary",
                                                "ed_somesecondary", "ed_secondary", "ed_ba", "unemployed", "female",
                                                "had_food", "own_tv", "round"))

r6_match_final<-dplyr::select(r6_match_merge, c("pol_ethnic_identity", "country_name","ethnicity", "year",
                                                "age", "age18_35", "age35_49",
                                                "age50_64", "age65over", "pol_interest", "wm_leaders", "voted", "attend_meeting",
                                                "join_others", "attend_protest", "contact_councillor", "ethnic_unfair",
                                                "trust_outgroup", "ethnic_discriminated", "neighbor_outgroup", "education", "ed_belowsecondary",
                                                "ed_somesecondary", "ed_secondary", "ed_ba", "unemployed", "female",
                                                "had_food", "own_tv", "round"))

r7_match_final<-dplyr::select(r7_match_merge, c("pol_ethnic_identity", "country_name","ethnicity", "year",
                                                "age", "age18_35", "age35_49",
                                                "age50_64", "age65over", "pol_interest", "wm_leaders", "voted", "attend_meeting",
                                                "join_others", "attend_protest", "contact_councillor", "ethnic_unfair",
                                                "trust_outgroup", "ethnic_discriminated", "neighbor_outgroup", "education", "ed_belowsecondary",
                                                "ed_somesecondary", "ed_secondary", "ed_ba", "unemployed", "female",
                                                "had_food", "own_tv", "round"))



afb1<-rbind(r3_match_final, r4_match_final, r5_match_final, r6_match_final, r7_match_final)
#Drop NA rows
afb1<-afb1[!is.na(afb1$country_name),]
#NAs in pol_ethnic_identity are unmatched ethnicities, so they will be coded as ethnic minorities when merged

library(countrycode)
afb1$COWCode<-countrycode(afb1$country_name, 'country.name', 'cown')


###Need to calculate majority and minority ethnic status using these data
#be sure to count people with NAs in ethnicity

#Need to break down unique country-year pairs
afb_ccode_year<-as.data.frame(cbind(afb1$COWCode, afb1$year))
colnames(afb_ccode_year)<-c("COWCode", "year")
afb_ccode_year$COWCode<-as.numeric(as.character(afb_ccode_year$COWCode))
afb_ccode_year$year<-as.numeric(as.character(afb_ccode_year$year))
afb_ccode_year<-unique(afb_ccode_year)

afb_ethnic_maj<-as.data.frame(matrix(nrow=69,ncol=3))

#Pull majority ethnic groups in each country based on self-identification
#tryCatch as there are two coding errors in the dataset
for(i in 1:69){
  tryCatch({
    print(i)
    #Country
    j<-afb_ccode_year[i,1]
    #Year
    k<-afb_ccode_year[i,2]
    temp<-as.data.frame(table(afb1[(afb1$COWCode==j) & (afb1$year==k),]$ethnicity))
    afb_ethnic_maj[i,3]<-as.numeric(as.character(temp[which.max(temp$Freq),1]))
    afb_ethnic_maj[i,1]<-j
    afb_ethnic_maj[i,2]<-k
  }, error=function(e){})
}

colnames(afb_ethnic_maj)<-c('COWCode','year', 'ethnicity')
afb_ethnic_maj$ethnic_majority<-1

afb1$year<-as.numeric(as.character(afb1$year))
afb1.1<-merge(afb1, afb_ethnic_maj, by=c("COWCode", "year", "ethnicity"), all.x=T)
afb1.1$ethnic_majority<-ifelse(is.na(afb1.1$ethnic_majority),0,1)
afb1.1$ethnic_minority<-1-afb1.1$ethnic_majority

#save(afb1.1, file="afb1.1.RData")




###Calculate ethnic elf by round
afb_hh<-dplyr::select(afb1.1, c("COWCode", "round", "ethnicity"))
afb_hh$ethnicity_counter<-1

afb_hh2<-as.data.frame(afb_hh %>%
                         group_by(COWCode, round, ethnicity) %>%
                         summarise_all(sum, na.rm=T))


afb_resp<-as.data.frame(afb_hh[,-3] %>%
                          group_by(COWCode, round) %>%
                          summarise_all(sum, na.rm=T))
colnames(afb_resp)<-c("COWCode", "round", "round_size")

afb_hh3<-merge(afb_hh2, afb_resp, by=c("COWCode", "round"), all.x=T)
afb_hh3$ethnicity_pct<-afb_hh3$ethnicity_counter/afb_hh3$round_size
afb_hh3$ethnicity_pct2<-afb_hh3$ethnicity_pct^2

afb_hh4<-select(afb_hh3, c("COWCode", "round", "ethnicity_pct2"))

afb_hh5<-as.data.frame(afb_hh4 %>%
                         group_by(COWCode, round) %>%
                         summarise_all(sum, na.rm=T))
afb_hh5$elf_afb<-1-afb_hh5$ethnicity_pct2

afb_elf<-select(afb_hh5, c("COWCode", "round", "elf_afb"))

#save(afb_elf, file="afb_elf.RData")





###############################################################################


###Prep Cabinets
#Choose only July to align with other dataset
cabinet4<-cabinet[cabinet$month==7,]

#Classify ministries by prestige
cabinet_positions<-as.data.frame(cbind(cabinet4$cabinet_position, cabinet4$type_ministry))
cabinet_positions<-unique(cabinet_positions)
colnames(cabinet_positions)<-c("cabinet_position", "type_ministry")
row.names(cabinet_positions)<-NULL
cabinet_positions$position_id<-row.names(cabinet_positions)
#write.csv(cabinet_positions, file="cabinet_positions.csv", row.names=F)

cabinet_positions<-read.csv("cabinet_positions.csv", header=T, stringsAsFactors = F)

ministry_names<-read.csv("Ministry names.csv", header = T, stringsAsFactors = F)

cabinet_positions2<-merge(cabinet_positions, ministry_names, by.x="ministry_classification", by.y="Name", all.x=T)

cabinet_positions3<-dplyr::select(cabinet_positions2, c("cabinet_position", "ministry_classification", "Prestige", "Gender"))
cabinet_postions3<-unique(cabinet_positions3)

#Merge cabinet with ministry prestige
cabinet4.1<-merge(cabinet4, cabinet_positions3, by="cabinet_position", all.x=T, all.y=F)
cabinet4.1<-unique(cabinet4.1)

#Split up Chief of State (President and Prime Minister)
#Eliminate ceremonial roles
cabinet4.2<-cabinet4.1[cabinet4.1$ministry_classification=="Chief of State",]
cabinet4.2<-cabinet4.2[cabinet4.2$leader==1,]

#Check to ensure one leader per country-year
table(cabinet4.2$country, cabinet4.2$year)

#Use minister_gender and polethnicid 
leaders<-dplyr::select(cabinet4.2, c("country", "year", "minister_gender", "pol_ethnic_identity"))
colnames(leaders)<-c("country", "year", "leader_gender", "leader_ethnic_identity")
library(plm)
leaders<-pdata.frame(leaders,index=c("country","year")) 
leaders$leader_gender_l<-plm::lag(leaders$leader_gender)
leaders$leader_ethnic_identity_l<-plm::lag(leaders$leader_ethnic_identity)

leaders_gender<-dplyr::select(leaders, c("country", "year", "leader_gender"))
leaders_gender$leader_gender_match<-1

leaders_ethnicity<-dplyr::select(leaders, c("country", "year", "leader_ethnic_identity"))
leaders_ethnicity$leader_ethnicity_match<-1

#Lags
leaders_gender_l<-dplyr::select(leaders, c("country", "year", "leader_gender_l"))
leaders_gender_l<-leaders_gender_l[!is.na(leaders_gender_l$leader_gender_l),]
leaders_gender_l$leader_gender_match_l<-1

leaders_ethnicity_l<-dplyr::select(leaders, c("country", "year", "leader_ethnic_identity_l"))
leaders_ethnicity_l<-leaders_ethnicity_l[!is.na(leaders_ethnicity_l$leader_ethnic_identity_l),]
leaders_ethnicity_l$leader_ethnicity_match_l<-1

#Forget about co-gender leader because they are all men except for Liberia
#save(leaders_ethnicity, file="leaders_ethnicity.RData")
#save(leaders_ethnicity_l, file="leaders_ethnicity_l.RData")


#Remaining ministers
cabinet4.3<-cabinet4.1[cabinet4.1$ministry_classification!="Chief of State",]
cabinet4.3$minister_female<-cabinet4.3$minister_gender
cabinet4.3$minister_male<-1-cabinet4.3$minister_gender
cabinet4.3$prestige_high<-ifelse(cabinet4.3$Prestige=="High",1,0)
cabinet4.3$prestige_medium<-ifelse(cabinet4.3$Prestige=="Medium",1,0)
cabinet4.3$prestige_low<-ifelse(cabinet4.3$Prestige=="Low",1,0)
cabinet4.3$ministry_masculine<-ifelse(cabinet4.3$Gender=="Masculine",1,0)
cabinet4.3$ministry_feminine<-ifelse(cabinet4.3$Gender=="Feminine",1,0)
cabinet4.3$ministry_neutral<-ifelse(cabinet4.3$Gender=="Neutral",1,0)

#Gender power score variables
cabinet4.3$prestige_high_m<-ifelse(cabinet4.3$prestige_high==1 & 
                                   cabinet4.3$ministry_masculine==1, 1, 0)
cabinet4.3$prestige_high_f<-ifelse(cabinet4.3$prestige_high==1 & 
                                     cabinet4.3$ministry_feminine==1, 1, 0)
cabinet4.3$prestige_high_n<-ifelse(cabinet4.3$prestige_high==1 & 
                                     cabinet4.3$ministry_neutral==1, 1, 0)

cabinet4.3$prestige_medium_m<-ifelse(cabinet4.3$prestige_medium==1 & 
                                     cabinet4.3$ministry_masculine==1, 1, 0)
cabinet4.3$prestige_medium_f<-ifelse(cabinet4.3$prestige_medium==1 & 
                                     cabinet4.3$ministry_feminine==1, 1, 0)
cabinet4.3$prestige_medium_n<-ifelse(cabinet4.3$prestige_medium==1 & 
                                     cabinet4.3$ministry_neutral==1, 1, 0)

cabinet4.3$prestige_low_m<-ifelse(cabinet4.3$prestige_low==1 & 
                                     cabinet4.3$ministry_masculine==1, 1, 0)
cabinet4.3$prestige_low_f<-ifelse(cabinet4.3$prestige_low==1 & 
                                     cabinet4.3$ministry_feminine==1, 1, 0)
cabinet4.3$prestige_low_n<-ifelse(cabinet4.3$prestige_low==1 & 
                                     cabinet4.3$ministry_neutral==1, 1, 0)

#Gender power score variables
cabinet4.3$prestige_high_m_women<-ifelse(cabinet4.3$prestige_high==1 & 
                                     cabinet4.3$ministry_masculine==1 &
                                       cabinet4.3$minister_female==1, 1, 0)
cabinet4.3$prestige_high_f_women<-ifelse(cabinet4.3$prestige_high==1 & 
                                     cabinet4.3$ministry_feminine==1 &
                                       cabinet4.3$minister_female==1, 1, 0)
cabinet4.3$prestige_high_n_women<-ifelse(cabinet4.3$prestige_high==1 & 
                                     cabinet4.3$ministry_neutral==1 &
                                       cabinet4.3$minister_female==1, 1, 0)

cabinet4.3$prestige_medium_m_women<-ifelse(cabinet4.3$prestige_medium==1 & 
                                       cabinet4.3$ministry_masculine==1 &
                                         cabinet4.3$minister_female==1, 1, 0)
cabinet4.3$prestige_medium_f_women<-ifelse(cabinet4.3$prestige_medium==1 & 
                                       cabinet4.3$ministry_feminine==1 &
                                         cabinet4.3$minister_female==1, 1, 0)
cabinet4.3$prestige_medium_n_women<-ifelse(cabinet4.3$prestige_medium==1 & 
                                       cabinet4.3$ministry_neutral==1 &
                                         cabinet4.3$minister_female==1, 1, 0)

cabinet4.3$prestige_low_m_women<-ifelse(cabinet4.3$prestige_low==1 & 
                                    cabinet4.3$ministry_masculine==1 &
                                      cabinet4.3$minister_female==1, 1, 0)
cabinet4.3$prestige_low_f_women<-ifelse(cabinet4.3$prestige_low==1 & 
                                    cabinet4.3$ministry_feminine==1 &
                                      cabinet4.3$minister_female==1, 1, 0)
cabinet4.3$prestige_low_n_women<-ifelse(cabinet4.3$prestige_low==1 & 
                                    cabinet4.3$ministry_neutral==1 &
                                      cabinet4.3$minister_female==1, 1, 0)

cabinet4.3$cabinet_size_counter<-1


cabinet4.3<-dummy_cols(cabinet4.3, select_columns="pol_ethnic_identity")

#Prestige times each ethnic group
cabinet4.4<-cbind(cabinet4.3, cabinet4.3[,c(73:230)], cabinet4.3[,c(73:230)], cabinet4.3[,c(73:230)])

#Prestige high
names(cabinet4.4)[231:388]<-paste0("prestige_high_",names(cabinet4.4)[231:388])
cabinet4.4[,231:388]<-cabinet4.4[,231:388]*cabinet4.4$prestige_high

#Prestige medium
names(cabinet4.4)[389:546]<-paste0("prestige_medium_",names(cabinet4.4)[389:546])
cabinet4.4[,389:546]<-cabinet4.4[,389:546]*cabinet4.4$prestige_high

#Prestige low
names(cabinet4.4)[547:704]<-paste0("prestige_low_",names(cabinet4.4)[547:704])
cabinet4.4[,547:704]<-cabinet4.4[,547:704]*cabinet4.4$prestige_low


#Aggregate to country-year
cabinet5<-cabinet4.4[,c(5,8,46:704)]

cabinet5.1<-as.data.frame(cabinet5 %>%
                            group_by(country, year) %>%
                            summarise_all(sum, na.rm=T))


#Calculate Percent Women
cabinet5.1$pct_women<-cabinet5.1$minister_female/cabinet5.1$cabinet_size_counter
cabinet5.1$pct_men<-cabinet5.1$minister_male/cabinet5.1$cabinet_size_counter


#Calculate Gender PS
cabinet5.1$pct_women_masculine<-(cabinet5.1$prestige_high_m_women+
  cabinet5.1$prestige_medium_m_women+cabinet5.1$prestige_low_m_women)/cabinet5.1$cabinet_size_counter
cabinet5.1$pct_women_neutral<-(cabinet5.1$prestige_high_n_women+
  cabinet5.1$prestige_medium_n_women+cabinet5.1$prestige_low_n_women)/cabinet5.1$cabinet_size_counter
cabinet5.1$pct_women_feminine<-(cabinet5.1$prestige_high_f_women+
  cabinet5.1$prestige_medium_f_women+cabinet5.1$prestige_low_f_women)/cabinet5.1$cabinet_size_counter
cabinet5.1$pct_women_high<-(cabinet5.1$prestige_high_m_women+
  cabinet5.1$prestige_high_f_women+cabinet5.1$prestige_high_n_women)/cabinet5.1$cabinet_size_counter
cabinet5.1$pct_women_medium<-(cabinet5.1$prestige_medium_m_women+
  cabinet5.1$prestige_medium_f_women+cabinet5.1$prestige_medium_n_women)/cabinet5.1$cabinet_size_counter
cabinet5.1$pct_women_low<-(cabinet5.1$prestige_low_m_women+
  cabinet5.1$prestige_low_f_women+cabinet5.1$prestige_low_n_women)/cabinet5.1$cabinet_size_counter


cabinet5.1$gender_ps<-((3*cabinet5.1$pct_women_masculine+2*cabinet5.1$pct_women_neutral+
  cabinet5.1$pct_women_feminine)+(3*cabinet5.1$pct_women_high+2*cabinet5.1$pct_women_medium+
  cabinet5.1$pct_women_low))*cabinet5.1$pct_women


#Calculate HH
cabinet5.1$ethnicity_number<-rowSums(cabinet5.1[,c(30:187)]!=0)

#Keep "other" as a single ethnic group because no way to do anything else with it
for(i in 1:nrow(cabinet5.1)){
    cabinet5.1$ethnicity_hh[i]<-1-(sum((cabinet5.1[i,c(30:187)]/cabinet5.1$cabinet_size_counter[i])^2))}


#Calculate percentage of the cabinet for each ethnic group
cabinet5.1[,c(30:187)]<-cabinet5.1[,c(30:187)]/cabinet5.1$cabinet_size_counter

#Calculate ethnic PS for each ethnic group
#High
cabinet5.1[,c(188:345)]<-cabinet5.1[,c(188:345)]/cabinet5.1$cabinet_size_counter

#Medium
cabinet5.1[,c(346:503)]<-cabinet5.1[,c(346:503)]/cabinet5.1$cabinet_size_counter

#Low
cabinet5.1[,c(504:661)]<-cabinet5.1[,c(504:661)]/cabinet5.1$cabinet_size_counter



#Take country-year variables for merging
#Do lags
cabinet6<-dplyr::select(cabinet5.1, c("country", "year", "pct_women", "pct_men",
                                      "gender_ps", "ethnicity_number", "ethnicity_hh"))

cabinet6<-pdata.frame(cabinet6,index=c("country","year")) 
cabinet6$pct_women_l<-plm::lag(cabinet6$pct_women)
cabinet6$pct_men_l<-plm::lag(cabinet6$pct_men)
cabinet6$gender_ps_l<-plm::lag(cabinet6$gender_ps)
cabinet6$ethnicity_number_l<-plm::lag(cabinet6$ethnicity_number)
cabinet6$ethnicity_hh_l<-plm::lag(cabinet6$ethnicity_hh)


#save(cabinet6, file="cabinet6.RData")


###Data for each ethnic group
#Ethnic PS (3*high+2*medium+low)*percent of cabinet from the ethnic group
ethnic_ps<-(3*cabinet5.1[,c(188:345)]+2*cabinet5.1[,c(346:503)]+cabinet5.1[,c(504:661)])*
  cabinet5.1[,c(30:187)]

names(ethnic_ps)<-paste0("ethnic_ps_",names(cabinet5.1)[c(30:187)])

cabinet5.2<-cbind(cabinet5.1, ethnic_ps)

#Select only percent ethnicity to go wide to long, then do ethnic_ps
pct_ethnicity<-cabinet5.2[,c(1,2,30:187)]

library(tidyr)
pct_ethnicity2<-gather(pct_ethnicity, pol_ethnic_identity, pct_ethnic_rep, pol_ethnic_identity_Kalanga:pol_ethnic_identity_Ebira)

#Do lag
pct_ethnicity2_lag<-pct_ethnicity2
pct_ethnicity2_lag$year<-pct_ethnicity2_lag$year+1
pct_ethnicity2_lag<-pct_ethnicity2_lag[pct_ethnicity2_lag$year!="2018",]
colnames(pct_ethnicity2_lag)<-c("country", "year", "pol_ethnic_identity", "pct_ethnic_rep_l")

#Merge
pct_ethnicity3<-merge(pct_ethnicity2, pct_ethnicity2_lag, by=c("country", "year", "pol_ethnic_identity"), all.x=T)

#Clean pol_ethnic_identity column
pct_ethnicity3$pol_ethnic_identity<-str_replace(pct_ethnicity3$pol_ethnic_identity, "pol_ethnic_identity_", "")



#Repeat for ethnicity score
ethnic_score<-cabinet5.2[,c(1,2,673:830)]

ethnic_score2<-gather(ethnic_score, pol_ethnic_identity, ethnic_ps, ethnic_ps_pol_ethnic_identity_Kalanga:ethnic_ps_pol_ethnic_identity_Ebira)

ethnic_score2_lag<-ethnic_score2
ethnic_score2_lag$year<-ethnic_score2_lag$year+1
ethnic_score2_lag<-ethnic_score2_lag[ethnic_score2_lag$year!="2018",]
colnames(ethnic_score2_lag)<-c("country", "year", "pol_ethnic_identity", "ethnic_ps_l")
ethnic_score3<-merge(ethnic_score2, ethnic_score2_lag, by=c("country", "year", "pol_ethnic_identity"), all.x=T)
ethnic_score3$pol_ethnic_identity<-str_replace(ethnic_score3$pol_ethnic_identity, "ethnic_ps_pol_ethnic_identity_", "")

#Merge ethnic measures
ethnic_score4<-merge(pct_ethnicity3, ethnic_score3, by=c("country", "year", "pol_ethnic_identity"), all.x=T, all.y=T)

#save(ethnic_score4, file="ethnic_score4.RData")





###Merging

#Afrobarometer data
#load("afb1.1.RData")

#Country-year variables (merge on country-year)
#load("cabinet6.RData")

afb2<-merge(afb1.1, cabinet6, by.x=c("country_name", "year"), by.y=c("country", "year"), all.x=T)


#Leader variables (merge on country, year, ethnicity)
#load("leaders_ethnicity.RData")

afb2.1<-merge(afb2, leaders_ethnicity, by.x=c("country_name", "year", "pol_ethnic_identity"), 
              by.y=c("country", "year", "leader_ethnic_identity"), all.x=T)

#Fill NAs with zero, since leader is not represented
afb2.1$leader_ethnicity_match<-ifelse(is.na(afb2.1$leader_ethnicity_match),0,
                                      afb2.1$leader_ethnicity_match)


#load("leaders_ethnicity_l.RData")

afb2.2<-merge(afb2.1, leaders_ethnicity_l, by.x=c("country_name", "year", "pol_ethnic_identity"), 
              by.y=c("country", "year", "leader_ethnic_identity_l"), all.x=T)

#Fill NAs (don't worry about lags because no afrobarometer data for 1997, when leader data starts)
afb2.2$leader_ethnicity_match_l<-ifelse(is.na(afb2.2$leader_ethnicity_match_l),0,
                                      afb2.2$leader_ethnicity_match_l)


#Ethnic measures (merge on country, year ethnicity)
#load("ethnic_score4.RData")

afb2.3<-merge(afb2.2, ethnic_score4, by.x=c("country_name", "year", "pol_ethnic_identity"), 
                      by.y=c("country", "year", "pol_ethnic_identity"), all.x=T)

#Fill NAs
afb2.3$pct_ethnic_rep<-ifelse(is.na(afb2.3$pct_ethnic_rep),0,
                                      afb2.3$pct_ethnic_rep)

afb2.3$pct_ethnic_rep_l<-ifelse(is.na(afb2.3$pct_ethnic_rep_l),0,
                              afb2.3$pct_ethnic_rep_l)

afb2.3$ethnic_ps<-ifelse(is.na(afb2.3$ethnic_ps),0,
                                afb2.3$ethnic_ps)

afb2.3$ethnic_ps_l<-ifelse(is.na(afb2.3$ethnic_ps_l),0,
                                afb2.3$ethnic_ps_l)

#Merge with Afrobarometer ELF measure (no lag possible because country-round measure)
#load("afb_elf.RData")

afb2.4<-merge(afb2.3, afb_elf, by=c("COWCode", "round"), all.x=T)



#Get country-year ethnicity measures (but does not extend past 2013)
library(countrycode)
#Need to download data (see Read_Me)
load("HIEF_data.RData")
x$COWCode<-countrycode(x$Country, "country.name", "cown")
x$COWCode<-ifelse(x$Country=="Serbia", 345, x$COWCode)
x$COWCode<-ifelse(x$Country=="Republic of Vietnam", 816, x$COWCode)
x<-dplyr::select(x, c("COWCode", "Year", "EFindex"))

x<-unique(x)
x<-pdata.frame(x,index=c("COWCode","Year"))
colnames(x)<-c("COWCode", "year", "elf_hief")
x$elf_hief_l<-plm::lag(x$elf_hief)

afb2.5<-merge(afb2.4, x, by=c("COWCode", "year"), all.x=T)




#Vdem data (merge on country-year)
#Need to download data (see Read_Me)
load("vdem.RData")
#v2lgfemleg: pct females in lower chamber
#e_polity2: Polity 2
#e_migdppcln: GDP per capita
vdem<-pdata.frame(vdem,index=c("COWcode","year")) 
vdem$pct_wm_leg<-vdem$v2lgfemleg
vdem$gdppc_ln<-vdem$e_migdppcln
vdem$polity2<-vdem$e_polity2

vdem$pct_wm_leg_l<-dplyr::lag(vdem$pct_wm_leg, k=1)
vdem$gdppc_ln_l<-dplyr::lag(vdem$gdppc_ln, k=1)
vdem$polity2_l<-dplyr::lag(vdem$polity2, k=1)

vdem<-dplyr::select(vdem, c("COWcode", "year", "pct_wm_leg", "gdppc_ln", "polity2",
                            "pct_wm_leg_l", "gdppc_ln_l", "polity2_l"))

afb4<-merge(afb2.5, vdem, by.x=c("COWCode", "year"), by.y=c("COWcode", "year"), all.x=T)


#save(afb4, file="afb4.RData")



