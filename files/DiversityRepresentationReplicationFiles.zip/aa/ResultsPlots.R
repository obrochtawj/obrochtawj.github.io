###############################################################
### Ethnic Cabinet Diversity, Co-Ethnic Representation, and ###
### Attitudes Toward Government                             ###
### Plots                                                   ###
### William O'Brochta, Texas Lutheran University            ###
################################################################ 


library(lme4)
library(lmerTest)
library(plyr)
library(dplyr)
library(xtable)
library(interplot)
library(margins)
library(sandwich)

#Load WVS
load("wvs3.2.RData")

country_year<-dplyr::select(wvs3.2, c("country_name", "year_f"))
country_year<-unique(country_year)
country_year$majority<-NA
country_year$minority<-NA

for(i in 1:291){
  country_name<-country_year[i,1]
  year<-country_year[i,2]
  temp<-wvs3.2[wvs3.2$country_name==country_name & wvs3.2$year_f==year,]
  temp2<-table(temp$ethnic_minority_wvs)
  country_year[i,3]<-temp2[1]
  country_year[i,4]<-temp2[2]
}

country_year$majority_only<-ifelse(!is.na(country_year$majority)&is.na(country_year$minority),1,0)

country_year$total_sample<-country_year$majority+country_year$minority
country_year$pct_majority<-country_year$majority/country_year$total_sample
country_year$pct_minority<-1-country_year$pct_majority
country_year<-country_year[!is.na(country_year$majority),]


wvs3.2<-merge(wvs3.2, country_year, by=c("country_name", "year_f"), all.x=T)
wvs3.2<-wvs3.2[wvs3.2$majority_only==0,]
wvs3.2$ethnic_incabinet_l<-stats::lag(wvs3.2$ethnic_incabinet, k=1)
wvs3.2$ethnic_notincabinet_l<-stats::lag(wvs3.2$ethnic_notincabinet, k=1)

#Load AFB
load("afb4.RData")
afb4$year_f<-as.factor(afb4$year)
afb4$join_others<-ifelse(afb4$join_others==9,NA,afb4$join_others)
afb4$ethnic_notincabinet<-ifelse(afb4$ethnic_ps==0,1,0)
afb4$ethnic_notincabinet_l<-ifelse(afb4$ethnic_ps_l==0,1,0)
afb4$ethnic_incabinet<-1-afb4$ethnic_notincabinet
afb4$ethnic_incabinet_l<-1-afb4$ethnic_notincabinet_l

#WVS linear models for main text
wvs3.2$conf_government_n<-(wvs3.2$conf_government-1)/3

model_wvs<-lm(conf_government_n~female*pct_female_l+married+unemployed+income
                +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                +pol_interest+ideology_left+polity2_l+gdppc_ln_l+pct_wm_leg_l
                +ethnic_incabinet_l+pct_ethnicity_rep_l+elf_hief+ethnic_minority_wvs
                +country_name+year_f, wvs3.2)
summary(model_wvs)

marginal<-as.data.frame(summary(margins(model_wvs, 
                                        variables=c("ethnic_incabinet_l"), 
                                        vcov = vcovHC(model_wvs, type="HC0"))))
marginal$dv<-"confidence"


model_wvs1<-lm(conf_government_n~female*pct_female_l+married+unemployed+income
              +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
              +pol_interest+ideology_left+polity2_l+gdppc_ln_l+pct_wm_leg_l
              +ethnic_incabinet_l*pct_ethnicity_rep_l+elf_hief+ethnic_minority_wvs
              +country_name+year_f, wvs3.2)
summary(model_wvs1)

#Figure 1, Panel A
source("interaction_plots2.R")
par(mar=c(5.1, 4.3, 4.1, 2.1))
interaction_plot_binary(model_wvs1, effect="pct_ethnicity_rep_l", moderator="ethnic_incabinet_l", interaction="ethnic_incabinet_l:pct_ethnicity_rep_l", 
                        conf=0.95, xlab='In Cabinet', ylab='Marginal Effect of Representation',
                        title='World Values Survey Government Confidence')



#AFB linear models for main text
afb4$ethnic_unfair_n<-(afb4$ethnic_unfair-1)/3

model_afb<-lm(ethnic_unfair_n~female*pct_women_l+unemployed+own_tv+had_food
                 +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                 +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
                 +ethnic_incabinet_l+ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
                 +country_name+year_f, afb4)
summary(model_afb)


marginal_temp<-as.data.frame(summary(margins(model_afb, 
                                             variables=c("ethnic_incabinet_l"), 
                                             vcov = vcovHC(model_afb, type="HC0"))))
marginal_temp$dv<-"unfair"
marginal<-rbind(marginal, marginal_temp)



model_afb1<-lm(ethnic_unfair_n~female*pct_women_l+unemployed+own_tv+had_food
              +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
              +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
              +ethnic_incabinet_l*ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
              +country_name+year_f, afb4)
summary(model_afb1)

#Figure 1, Panel B
par(mar=c(5.1, 4.3, 4.1, 2.1))
interaction_plot_binary(model_afb1, effect="ethnicity_hh_l", moderator="ethnic_incabinet_l", interaction="ethnic_incabinet_l:ethnicity_hh_l", 
                        conf=0.95, xlab='In Cabinet', ylab='Marginal Effect of Cabinet Diversity',
                        title='Afrobarometer Ethnic Unfairness')


#Ethnic power score
model_afb2<-lm(ethnic_unfair_n~female*pct_women_l+unemployed+own_tv+had_food
               +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
               +pol_interest+polity2_l+gdppc_ln_l+pct_wm_leg_l
               +ethnic_ps_l+ethnicity_hh_l+elf_afb+leader_ethnicity_match_l+ethnic_minority
               +country_name+year_f, afb4)
summary(model_afb2)

marginal_temp<-as.data.frame(summary(margins(model_afb2, 
                                             variables=c("ethnic_ps_l"), 
                                             vcov = vcovHC(model_afb2, type="HC0"))))
marginal_temp$dv<-"powerscore"
marginal<-rbind(marginal, marginal_temp)
#save(marginal, file="marginal.RData")





#Coefficient plot
par(mar=c(5.1, 4.3, 4.1, 2.1))
#load("marginal.RData")

marginal$dv<-factor(marginal$dv,levels = c("powerscore", "unfair", "confidence"),
                           labels=c("Unfair\n (Pwr. Score)", "Unfair", "Confidence"))

marginal1 <- ggplot(data=marginal, aes(dv, AME)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()

marginal2 <- marginal1 + geom_linerange(data=marginal, 
                                                      aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="Estimate") + 
  coord_flip(ylim = c(-0.5, 0.015)) +  theme(axis.title=element_text(size=14)) + theme(axis.text=element_text(size=14)) + 
  theme(legend.text=element_text(size=14)) + theme(legend.title=element_text(size=14)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 14))+
  theme(plot.margin = unit(c(5.5,10.5,5.5,5.5), "pt"))

#Figure SI.3.1
marginal2

