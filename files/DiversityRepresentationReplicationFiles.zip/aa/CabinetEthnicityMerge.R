###############################################################
### Ethnic Cabinet Diversity, Co-Ethnic Representation, and ###
### Attitudes Toward Government                             ###
### World Values Survey Preparation                         ###
### William O'Brochta, Texas Lutheran University            ###
################################################################ 

library(plyr)
library(dplyr)
library(tidyr)
library(countrycode)
#library(nomine)
library(haven)
library(labelled)
library(tidyr)
library(stringr)
library(plm)

#Obtain on your own (see Read_Me)
cabinet<-read.csv("WhoGov_within_V1.1.csv", header=T, stringsAsFactors = F)
cabinet$name_lower<-tolower(cabinet$name)
cabinet$name_lower<-gsub("[[:punct:][:blank:]]+", " ", cabinet$name_lower)

#Check and fix unambiguous matching
cabinet$COWCode<-countrycode(cabinet$country_isocode, "iso3c", "cown")
cabinet$COWCode<-ifelse(cabinet$country_isocode=="DDR", 265, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="DVN", 816, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="RVN", 817, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="YPR", 680, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="SUN", 365, cabinet$COWCode)

#Yugoslavia continues until 1997 and then transitions to Serbia's ministers after.
cabinet$COWCode<-ifelse(cabinet$country_isocode=="YUG" & cabinet$year<1997, 345, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="SRB", 345, cabinet$COWCode)


###Read in WVS
#Obtain on your own (see Read_Me)
wvs<-readRDS("WVS_TimeSeries_R_v1_2.rds")
wvs$COWCode<-as.numeric(as.character(wvs$COW_NUM))
wvs$year<-as.numeric(as.character(wvs$S020))
wvs$party_name<-wvs$E179WVS
wvs$respondent<-1
wvs$country_name<-countrycode(wvs$COWCode, 'cown', "country.name")

###Recode
#Lebanon
wvs$E179WVS<-ifelse(wvs$E179WVS==422024, 422007, wvs$E179WVS)
#Tunisia
wvs$E179WVS<-ifelse(wvs$E179WVS==788023, 788002, wvs$E179WVS)
#Ukraine
wvs$E179WVS<-ifelse(wvs$E179WVS==804011, 804010, wvs$E179WVS)
#Serbia
wvs$E179WVS<-ifelse(wvs$E179WVS==911002, 688005, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911001, 688001, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911004, 688029, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==891030, 688029, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911008, 688033, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911019, 688019, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911020, 688020, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911015, 688015, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==688003, 688015, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911025, 688025, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==688009, 688039, wvs$E179WVS)
wvs$E179WVS<-ifelse(wvs$E179WVS==911006, 688031, wvs$E179WVS)

#Code WVS variables
#Predicting response to diverse cabinet (gender and ethnic), so government, outgroup, women
#along with standard controls
wvs$wave<-as.numeric(as.character(wvs$S002))

#Country-year indicator
wvs$S025<-ifelse(wvs$S025=='-5'|
                   wvs$S025=='-4'|
                   wvs$S025=='-3'|
                   wvs$S025=='-2'|
                   wvs$S025=='-1', NA, wvs$S025)
wvs$country_year<-as.numeric(as.character(wvs$S025))

#Important Child Qualities: Respect for other people mentioned
wvs$A035<-ifelse(wvs$A035=='-4'|
                   wvs$A035=='-2'|
                   wvs$A025=='-1', NA, wvs$A035)
wvs$child_respect<-as.numeric(as.character(wvs$A035))

#Discuss politics: 3=frequently, 1=never
wvs$A062<-ifelse(wvs$A062=='-5'|
                   wvs$A062=='-4'|
                   wvs$A062=='-2'|
                   wvs$A062=='-1', NA, wvs$A062)
wvs$discuss_pol<-as.numeric(as.character(wvs$A062))
wvs$discuss_pol<-car::recode(wvs$discuss_pol, '1=3;2=2;3=1')

#Do not want outgroup neighbor: 1=do not want outgroup neighbor, 0=not mentioned
wvs$A124_02<-ifelse(wvs$A124_02=='-5'|
                      wvs$A124_02=='-4'|
                   wvs$A124_02=='-2'|
                   wvs$A124_02=='-1', NA, wvs$A124_02)
wvs$neighbor<-as.numeric(as.character(wvs$A124_02))

#Men make better political leaders than women do: 1=strongly disagree, 4=strongly agree
wvs$D059<-ifelse(wvs$D059=='-5'|
                   wvs$D059=='-4'|
                   wvs$D059=='-3'|
                   wvs$D059=='-2'|
                   wvs$D059=='-1', NA, wvs$D059)
wvs$wm_leaders<-as.numeric(as.character(wvs$D059))
wvs$wm_leaders<-car::recode(wvs$wm_leaders, '1=4;2=3;3=2;4=1')

#University is more important for a boy than a girl: 1=strongly disagree, 4=strongly agree
wvs$D060<-ifelse(wvs$D060=='-5'|
                   wvs$D060=='-4'|
                   wvs$D060=='-3'|
                   wvs$D060=='-2'|
                   wvs$D060=='-1', NA, wvs$D060)
wvs$wm_university<-as.numeric(as.character(wvs$D060))
wvs$wm_university<-car::recode(wvs$wm_university, '1=4;2=3;3=2;4=1')

#Men make better business executives than women do: 1=strongly disagree, 4=strongly agree
wvs$D078<-ifelse(wvs$D078=='-5'|
                   wvs$D078=='-4'|
                   wvs$D078=='-3'|
                   wvs$D078=='-2'|
                   wvs$D078=='-1', NA, wvs$D078)
wvs$wm_executives<-as.numeric(as.character(wvs$D078))
wvs$wm_executives<-car::recode(wvs$wm_executives, '1=4;2=3;3=2;4=1')


#Aims of country (use to code most important cabinet ministry)
wvs$E001<-ifelse(wvs$E001=='-5'|
                   wvs$E001=='-4'|
                   wvs$E001=='-2'|
                   wvs$E001=='-1', NA, wvs$E001)
wvs$aims<-as.numeric(as.character(wvs$E001))

wvs$aims_economy<-ifelse(wvs$aims==1,1,0)
wvs$aims_defense<-ifelse(wvs$aims==2,1,0)
wvs$aims_participation<-ifelse(wvs$aims==3,1,0)
wvs$aims_beautiful<-ifelse(wvs$aims==4,1,0)

#Interest in Politics: 1=not at all interested, 4=very interested
wvs$E023<-ifelse(wvs$E023=='-5'|
                   wvs$E023=='-4'|
                   wvs$E023=='-2'|
                   wvs$E023=='-1', NA, wvs$E023)
wvs$pol_interest<-as.numeric(as.character(wvs$E023))
wvs$pol_interest<-car::recode(wvs$pol_interest, '1=4;2=3;3=2;4=1')

#Has signed a petition: 1=would never do, 2=might do, 3=has done
wvs$E025<-ifelse(wvs$E025=='-4'|
                   wvs$E025=='-2'|
                   wvs$E025=='-1', NA, wvs$E025)
wvs$pol_petition<-as.numeric(as.character(wvs$E025))
wvs$pol_petition<-car::recode(wvs$pol_petition, '1=3;2=2;3=1')

#Has participated in a boycott: 1=would never do, 2=might do, 3=has done
wvs$E026<-ifelse(wvs$E026=='-5'|
                   wvs$E026=='-4'|
                   wvs$E026=='-3'|
                   wvs$E026=='-2'|
                   wvs$E026=='-1', NA, wvs$E026)
wvs$pol_boycott<-as.numeric(as.character(wvs$E026))
wvs$pol_boycott<-car::recode(wvs$pol_boycott, '1=3;2=2;3=1')

#Has participated in protest: 1=would never do, 2=might do, 3=has done
wvs$E027<-ifelse(wvs$E027=='-5'|
                   wvs$E027=='-4'|
                   wvs$E027=='-3'|
                   wvs$E027=='-2'|
                   wvs$E027=='-1', NA, wvs$E027)
wvs$pol_protest<-as.numeric(as.character(wvs$E027))
wvs$pol_protest<-car::recode(wvs$pol_protest, '1=3;2=2;3=1')

#Confidence in government: 1=none, 4=a great deal
wvs$E069_11<-ifelse(wvs$E069_11=='-5'|
                   wvs$E069_11=='-4'|
                   wvs$E069_11=='-3'|
                   wvs$E069_11=='-2'|
                   wvs$E069_11=='-1', NA, wvs$E069_11)
wvs$conf_government<-as.numeric(as.character(wvs$E069_11))
wvs$conf_government<-car::recode(wvs$conf_government, '1=4;2=3;3=2;4=1')


#Confidence in women's movement: 1=none, 4=a great deal
wvs$E069_15<-ifelse(wvs$E069_15=='-5'|
                      wvs$E069_15=='-4'|
                      wvs$E069_15=='-3'|
                      wvs$E069_15=='-2'|
                      wvs$E069_15=='-1', NA, wvs$E069_15)
wvs$conf_wmmovement<-as.numeric(as.character(wvs$E069_15))
wvs$conf_wmmovement<-car::recode(wvs$conf_wmmovement, '1=4;2=3;3=2;4=1')

#Party vote for (first choice): keep people who would not vote (2),
#who would vote blank (3), who would vote for none (4), who who would cast null vote (7)
#have to exclude people who would vote for other because no way to match to cabinet (5)
#exclude independents (8)
wvs$E179WVS<-ifelse(wvs$E179WVS=='-5'|
                      wvs$E179WVS=='-4'|
                      wvs$E179WVS=='-3'|
                      wvs$E179WVS=='-2'|
                      wvs$E179WVS=='-1'|
                      wvs$E179WVS=='1'|
                      wvs$E179WVS=='5'|
                      wvs$E179WVS=='6'|
                      wvs$E179WVS=='8', NA, wvs$E179WVS)
wvs$party_vote<-as.numeric(as.character(wvs$E179WVS))

#Female
wvs$X001<-ifelse(wvs$X001=='-5'|
                      wvs$X001=='-4'|
                      wvs$X001=='-3'|
                      wvs$X001=='-2'|
                      wvs$X001=='-1', NA, wvs$X001)
wvs$female<-ifelse(wvs$X001==2,1,0)


#Age (in years)
wvs$X003<-ifelse(wvs$X003=='-5'|
                   wvs$X003=='-4'|
                   wvs$X003=='-3'|
                   wvs$X003=='-2'|
                   wvs$X003=='-1', NA, wvs$X003)
wvs$age<-as.numeric(as.character(wvs$X003))

#Married: 1=yes, 0=no
wvs$X007<-ifelse(wvs$X007=='-4'|
                   wvs$X007=='-2', NA, wvs$X007)
wvs$married<-ifelse(wvs$X007==1, 1, 0)

#Education (have to merge two scales)
wvs$ed_belowsecondary<-rowSums(cbind(ifelse(wvs$X025==-3|wvs$X025==1|wvs$X025==2,1,0),
                                       ifelse(wvs$X025A2==0|wvs$X025A2==1,1,0)),na.rm=T)    
wvs$ed_somesecondary<-rowSums(cbind(ifelse(wvs$X025==3|wvs$X025==5,1,0),
                                    ifelse(wvs$X025A2==2,1,0)),na.rm=T)    
wvs$ed_secondary<-rowSums(cbind(ifelse(wvs$X025==4|wvs$X025==6|wvs$X025==7, 1, 0),
                                ifelse(wvs$X025A2==3|wvs$X025A2==4|wvs$X025A2==5,1,0)),na.rm=T)     
wvs$ed_ba<-rowSums(cbind(ifelse(wvs$X025==8, 1, 0),ifelse(wvs$X025A2==6|wvs$X025A2==7|wvs$X025A2==8,1,0)),
                         na.rm=T)
#No education question in wave 1
wvs$ed_belowsecondary<-ifelse(wvs$wave==1,NA,wvs$ed_belowsecondary)
wvs$ed_somesecondary<-ifelse(wvs$wave==1,NA,wvs$ed_somesecondary)
wvs$ed_secondary<-ifelse(wvs$wave==1,NA,wvs$ed_secondary)
wvs$ed_ba<-ifelse(wvs$wave==1,NA,wvs$ed_ba)



#Unemployed: 1=yes, 0=No
wvs$unemployed<-ifelse(wvs$X028==7,1,0)

#Income Ladder: 1=lowest, 10=highest
wvs$X047<-ifelse(wvs$X047=='-5'|
                   wvs$X047=='-4'|
                   wvs$X047=='-3'|
                   wvs$X047=='-2'|
                   wvs$X047=='-1', NA, wvs$X047)
wvs$income<-as.numeric(as.character(wvs$X047))

#Town size: 1=under 2000 to 8=500,000 or more
wvs$X049<-ifelse(wvs$X049=='-5'|
                   wvs$X049=='-4'|
                   wvs$X049=='-3'|
                   wvs$X049=='-2'|
                   wvs$X049=='-1', NA, wvs$X049)
wvs$townsize<-as.numeric(as.character(wvs$X049))


#Ethnic group (see codes)
wvs$X051<-ifelse(wvs$X051=='-5'|
                 wvs$X051=='-4'|
                 wvs$X051=='-3'|
                 wvs$X051=='-2'|
                 wvs$X051=='-1', NA, wvs$X051)
wvs$ethnicity<-as.numeric(as.character(wvs$X051))

#Left right: 1=left, 10=right
wvs$E033<-ifelse(wvs$E033=='-5'|
                   wvs$E033=='-4'|
                   wvs$E033=='-3'|
                   wvs$E033=='-2'|
                   wvs$E033=='-1', NA, wvs$E033)
wvs$ideology<-as.numeric(as.character(wvs$E033))

#Men deserve jobs more than women: 1=disagree, 2=neither agree/disagree, 3=agree
wvs$C001<-ifelse(wvs$C001=='-5'|
                   wvs$C001=='-4'|
                   wvs$C001=='-3'|
                   wvs$C001=='-2'|
                   wvs$C001=='-1', NA, wvs$C001)
wvs$men_jobs<-as.numeric(as.character(wvs$C001))
wvs$men_jobs<-car::recode(wvs$men_jobs, '1=3;2=1;3=2')


#Select key variables
wvs2<-dplyr::select(wvs, c('COWCode', 'year', 'country_name', 'wave', 'country_year',
                           'child_respect', 'discuss_pol', 
                           'neighbor', 'wm_leaders', 'wm_university', 
                           'wm_executives', 'men_jobs', 'aims', 'aims_economy', 
                           'aims_defense', 'aims_participation', 'aims_beautiful', 
                           'pol_interest', 'pol_petition', 'pol_boycott', 
                           'pol_protest', 'conf_government', 'conf_wmmovement', 
                           'party_vote', 'female', 'age', 'married', 'ideology',
                           'ed_belowsecondary', 'ed_somesecondary', 'ed_secondary', 
                           'ed_ba', 'unemployed', 'income', 'townsize', 'ethnicity'))


sum(table(wvs$A062, wvs$wave))
#save(wvs2, file="wvs2.RData")









###Extract WVS party names and party names of parties in cabinets
#Obtain on your own (see Read_Me)
wvs_temp<-readRDS("WVS_TimeSeries_R_v1_2.rds")
wvs_party<-as.data.frame(t(data.frame(as.list(val_labels(wvs_temp$E179WVS)))))
wvs_party$name<-row.names(wvs_party)
#write.csv(wvs_party, file="wvs_party.csv", row.names=F)

#Subset to country years where there were respondents and get the ministers' party
wvs_subset<-dplyr::select(wvs, c("COWCode", "year", "respondent"))
wvs_subset<-unique(wvs_subset)

wvs_cabinet<-merge(wvs_subset, cabinet, by=c("COWCode", "year"))

wvs_cabinet2<-dplyr::select(wvs_cabinet, c("country_name", "COWCode", "party_english"))
wvs_cabinet2<-unique(wvs_cabinet2)
#write.csv(wvs_cabinet2, file="wvs_cabinet2.csv", row.names=F)


#Now import finished data with respective WVS code
wvs_party_coded<-read.csv("wvs_cabinet2.csv", header=T, stringsAsFactors = F)
wvs_party_coded2<-wvs_party_coded[wvs_party_coded$party_english!="independent",]
wvs_party_coded2<-wvs_party_coded2[!is.na(wvs_party_coded2$party_english),]

#This can merge directly with WVS
cabinet2<-merge(cabinet, wvs_party_coded2, by=c("COWCode", "party_english"), all.x=T, all.y=F)

#Get cabinet-year aggregates for gender and gender subset to prestigious positions
#distinguish between leader and cabinet minister

#Merge on prestige again because it is miscoded in the dataset
#Prestige includes all COS named positions excluding the "leader" in a given year
cabinet2$portfolio_1<-ifelse(!is.na(cabinet2$portfolio_1), cabinet2$portfolio_1, cabinet2$classification)
cabinet2<-subset(cabinet2, select=-c(prestige_1, prestige_2, prestige_3, prestige_4))

ministry_correspondence<-read.csv("MinistryGenderType.csv", header=T, stringsAsFactors = F)

#Portfolio_1
colnames(ministry_correspondence)<-c("portfolio_1", "gender_1", "prestige_1")
cabinet3<-merge(cabinet2, ministry_correspondence, by="portfolio_1", all.x=T)

#Portfolio_2
colnames(ministry_correspondence)<-c("portfolio_2", "gender_2", "prestige_2")
cabinet3<-merge(cabinet3, ministry_correspondence, by="portfolio_2", all.x=T)

#Portfolio_3
colnames(ministry_correspondence)<-c("portfolio_3", "gender_3", "prestige_3")
cabinet3<-merge(cabinet3, ministry_correspondence, by="portfolio_3", all.x=T)

#Portfolio_4
colnames(ministry_correspondence)<-c("portfolio_4", "gender_4", "prestige_4")
cabinet3<-merge(cabinet3, ministry_correspondence, by="portfolio_4", all.x=T)

#No presige for country leaders; they are coded separately
cabinet3$prestige_1<-ifelse(cabinet3$leader==1, NA, cabinet3$prestige_1)
cabinet3$prestige_2<-ifelse(cabinet3$leader==1, NA, cabinet3$prestige_2)
cabinet3$prestige_3<-ifelse(cabinet3$leader==1, NA, cabinet3$prestige_3)
cabinet3$prestige_4<-ifelse(cabinet3$leader==1, NA, cabinet3$prestige_4)

#Create prestige dummies
cabinet3$prestige_1_h<-ifelse(cabinet3$prestige_1=="High",1,0)
cabinet3$prestige_1_m<-ifelse(cabinet3$prestige_1=="Medium",1,0)
cabinet3$prestige_1_l<-ifelse(cabinet3$prestige_1=="Low",1,0)
cabinet3$prestige_2_h<-ifelse(cabinet3$prestige_2=="High",1,0)
cabinet3$prestige_2_m<-ifelse(cabinet3$prestige_2=="Medium",1,0)
cabinet3$prestige_2_l<-ifelse(cabinet3$prestige_2=="Low",1,0)
cabinet3$prestige_3_h<-ifelse(cabinet3$prestige_3=="High",1,0)
cabinet3$prestige_3_m<-ifelse(cabinet3$prestige_3=="Medium",1,0)
cabinet3$prestige_3_l<-ifelse(cabinet3$prestige_3=="Low",1,0)
cabinet3$prestige_4_h<-ifelse(cabinet3$prestige_4=="High",1,0)
cabinet3$prestige_4_m<-ifelse(cabinet3$prestige_4=="Medium",1,0)
cabinet3$prestige_4_l<-ifelse(cabinet3$prestige_4=="Low",1,0)

cabinet3$portfolio_max_h<-ifelse(cabinet3$prestige_3_h==1,cabinet3$portfolio_3,NA)
cabinet3$portfolio_max_h<-ifelse(cabinet3$prestige_2_h==1,cabinet3$portfolio_2,cabinet3$portfolio_max_h)
cabinet3$portfolio_max_h<-ifelse(cabinet3$prestige_1_h==1,cabinet3$portfolio_1,cabinet3$portfolio_max_h)

cabinet3$portfolio_max_m<-ifelse(cabinet3$prestige_4_m==1,cabinet3$portfolio_4,NA)
cabinet3$portfolio_max_m<-ifelse(cabinet3$prestige_3_m==1,cabinet3$portfolio_3,cabinet3$portfolio_max_m)
cabinet3$portfolio_max_m<-ifelse(cabinet3$prestige_2_m==1,cabinet3$portfolio_2,cabinet3$portfolio_max_m)
cabinet3$portfolio_max_m<-ifelse(cabinet3$prestige_1_m==1,cabinet3$portfolio_1,cabinet3$portfolio_max_m)

cabinet3$portfolio_max_l<-ifelse(cabinet3$prestige_4_l==1,cabinet3$portfolio_4,NA)
cabinet3$portfolio_max_l<-ifelse(cabinet3$prestige_3_l==1,cabinet3$portfolio_3,cabinet3$portfolio_max_l)
cabinet3$portfolio_max_l<-ifelse(cabinet3$prestige_2_l==1,cabinet3$portfolio_2,cabinet3$portfolio_max_l)
cabinet3$portfolio_max_l<-ifelse(cabinet3$prestige_1_l==1,cabinet3$portfolio_1,cabinet3$portfolio_max_l)

cabinet3$portfolio_max<-ifelse(!is.na(cabinet3$portfolio_max_h), cabinet3$portfolio_max_h, cabinet3$portfolio_max_m)
cabinet3$portfolio_max<-ifelse(is.na(cabinet3$portfolio_max), cabinet3$portfolio_max_l, cabinet3$portfolio_max)

colnames(ministry_correspondence)<-c("portfolio_max", "gender_max", "prestige_max")
cabinet3<-merge(cabinet3, ministry_correspondence, by="portfolio_max", all.x=T)

#Subset to where minister names are available
cabinet3<-cabinet3[!is.na(cabinet3$name),]



#Now create dummies for the aggregation
#Subset to cases where the leader is excluded
cabinet3.1<-cabinet3[cabinet3$leader==0,]
#Subset out President, Prime minister, Chief of State
cabinet3.1<-cabinet3.1[cabinet3.1$classification!="President",]
cabinet3.1<-cabinet3.1[cabinet3.1$classification!="Prime minister",]
cabinet3.1<-cabinet3.1[cabinet3.1$classification!="Prime Minister",]
cabinet3.1<-cabinet3.1[cabinet3.1$classification!="Chief of State",]
#Miscoding
cabinet3.1<-cabinet3.1[cabinet3.1$classification!="STATEMENT",]

#Create dummy columns
cabinet3.1$counter<-1
cabinet3.1$female<-ifelse(cabinet3.1$gender=="Female",1,0)
cabinet3.1$male<-ifelse(cabinet3.1$gender=="Male",1,0)
cabinet3.1$counter_gender<-cabinet3.1$female+cabinet3.1$male

#Variables for Gender Power Score
cabinet3.1$prestige_max_h<-ifelse(cabinet3.1$prestige_max=="High",1,0)
cabinet3.1$prestige_max_m<-ifelse(cabinet3.1$prestige_max=="Medium",1,0)
cabinet3.1$prestige_max_l<-ifelse(cabinet3.1$prestige_max=="Low",1,0)
cabinet3.1$counter_prestige<-cabinet3.1$prestige_max_h+cabinet3.1$prestige_max_m+cabinet3.1$prestige_max_l

cabinet3.1$gender_max_m<-ifelse(cabinet3.1$gender_max=="Masculine",1,0)
cabinet3.1$gender_max_n<-ifelse(cabinet3.1$gender_max=="Neutral",1,0)
cabinet3.1$gender_max_f<-ifelse(cabinet3.1$gender_max=="Feminine",1,0)
cabinet3.1$counter_gendermax<-cabinet3.1$gender_max_m+cabinet3.1$gender_max_n+cabinet3.1$gender_max_f


#Counter for women in each of these positions and prestige
cabinet3.1$prestige_max_h_f<-cabinet3.1$prestige_max_h*cabinet3.1$female
cabinet3.1$prestige_max_m_f<-cabinet3.1$prestige_max_m*cabinet3.1$female
cabinet3.1$prestige_max_l_f<-cabinet3.1$prestige_max_l*cabinet3.1$female
cabinet3.1$gender_max_m_f<-cabinet3.1$gender_max_m*cabinet3.1$female
cabinet3.1$gender_max_n_f<-cabinet3.1$gender_max_n*cabinet3.1$female
cabinet3.1$gender_max_f_f<-cabinet3.1$gender_max_f*cabinet3.1$female



#Party Power Score (calculate percentage of ministers as well as pct. times power)
library(fastDummies)
#Get rid of countries where there aren't multiple parties
cabinet3.1$party_wvs<-ifelse(cabinet3.1$multiparty_citizens=="No", NA, cabinet3.1$party_wvs)
cabinet3.1$party_wvs<-ifelse(cabinet3.1$party_wvs=="",NA,cabinet3.1$party_wvs)
cabinet3.1$party_wvs<-ifelse(cabinet3.1$party_wvs=="No party",NA,cabinet3.1$party_wvs)
cabinet3.1$party_wvs<-ifelse(cabinet3.1$party_wvs=="None",NA,cabinet3.1$party_wvs)
cabinet3.1$counter_party<-ifelse(is.na(cabinet3.1$party_wvs),0,1)
cabinet3.1<-dummy_cols(cabinet3.1, select_columns="party_wvs")
#Remove party_wvs_NA column
cabinet3.1<-cabinet3.1[,-461]

#Age
cabinet3.1$age<-cabinet3.1$year-cabinet3.1$birthyear
cabinet3.1$counter_age<-ifelse(is.na(cabinet3.1$age),0,1)

#Now get counts for each year using summarise_all
#COWCode, year, from counter to the end
cabinet3.1.1<-cabinet3.1[,c(6,9,58:462)]

cabinet3.1.2<-as.data.frame(cabinet3.1.1%>%
                              group_by(COWCode, year)%>%
                              summarise_all(sum, na.rm=T))

cabinet3.1.2$avg_age<-round(cabinet3.1.2$age/cabinet3.1.2$counter_age)
cabinet3.1.2$pct_female<-cabinet3.1.2$female/cabinet3.1.2$counter_gender
cabinet3.1.2$pct_male<-cabinet3.1.2$male/cabinet3.1.2$counter_gender

cabinet3.1.2$pct_prestige_max_h<-cabinet3.1.2$prestige_max_h/cabinet3.1.2$counter_prestige
cabinet3.1.2$pct_prestige_max_m<-cabinet3.1.2$prestige_max_m/cabinet3.1.2$counter_prestige
cabinet3.1.2$pct_prestige_max_l<-cabinet3.1.2$prestige_max_l/cabinet3.1.2$counter_prestige

cabinet3.1.2$pct_prestige_max_h_f<-cabinet3.1.2$prestige_max_h_f/cabinet3.1.2$counter_prestige
cabinet3.1.2$pct_prestige_max_m_f<-cabinet3.1.2$prestige_max_m_f/cabinet3.1.2$counter_prestige
cabinet3.1.2$pct_prestige_max_l_f<-cabinet3.1.2$prestige_max_l_f/cabinet3.1.2$counter_prestige

cabinet3.1.2$pct_gender_max_m<-cabinet3.1.2$gender_max_m/cabinet3.1.2$counter_prestige
cabinet3.1.2$pct_gender_max_f<-cabinet3.1.2$gender_max_f/cabinet3.1.2$counter_prestige
cabinet3.1.2$pct_gender_max_n<-cabinet3.1.2$gender_max_n/cabinet3.1.2$counter_prestige

cabinet3.1.2$pct_gender_max_m_f<-cabinet3.1.2$gender_max_m_f/cabinet3.1.2$counter_gendermax
cabinet3.1.2$pct_gender_max_f_f<-cabinet3.1.2$gender_max_f_f/cabinet3.1.2$counter_gendermax
cabinet3.1.2$pct_gender_max_n_f<-cabinet3.1.2$gender_max_n_f/cabinet3.1.2$counter_gendermax




#GPS: (3xmasculine+2xneutral+1xfeminine + 3xhigh+2xmedium+1xlow)xtotal percentage
#Get rid of NAs
#Much lower when including more people as ministers (Finland 2009 is 1.35 compared to 3.67)
#Download the Krook and O'Brien data to check correlation (different month July vs August)
cabinet3.1.2$gender_ps<-((3*ifelse(is.na(cabinet3.1.2$pct_gender_max_m_f),0,cabinet3.1.2$pct_gender_max_m_f)+
                        2*ifelse(is.na(cabinet3.1.2$pct_gender_max_n_f),0,cabinet3.1.2$pct_gender_max_n_f)+
                          ifelse(is.na(cabinet3.1.2$pct_gender_max_f_f),0,cabinet3.1.2$pct_gender_max_f_f))+
                        3*ifelse(is.na(cabinet3.1.2$pct_prestige_max_h_f),0,cabinet3.1.2$pct_prestige_max_h_f)+
                           2*ifelse(is.na(cabinet3.1.2$pct_prestige_max_m_f),0,cabinet3.1.2$pct_prestige_max_m_f)+
                           ifelse(is.na(cabinet3.1.2$pct_prestige_max_l_f),0,cabinet3.1.2$pct_prestige_max_l_f))*
                        ifelse(is.na(cabinet3.1.2$pct_female),0,cabinet3.1.2$pct_female)
#Ready to merge with WVS



#Compare to Krook and O'Brien (original GPS in 2009)
#Obtain on your own (see Read_Me)
ko<-read.csv("KrookOBrien.csv", header=T, stringsAsFactors = F)
ko$year<-2009

#Correlation is very high
cabinet3.1.3<-merge(cabinet3.1.2, ko, by=c("COWCode", "year"), all.x=F, all.y=F)
cor(cabinet3.1.3$gender_ps, cabinet3.1.3$GPS)
plot(cabinet3.1.3$gender_ps, cabinet3.1.3$GPS)
mean(cabinet3.1.3$gender_ps)
mean(cabinet3.1.3$GPS)

#Cabinet in my dataset is about 4 members bigger; includes ministers w/o portfolio,
#central bank, etc.
cor(cabinet3.1.3$counter, cabinet3.1.3$Total)
plot(cabinet3.1.3$counter, cabinet3.1.3$Total)
mean(cabinet3.1.3$counter)
mean(cabinet3.1.3$Total)

#Percentage female is about the same
cor(cabinet3.1.3$pct_female, cabinet3.1.3$PerWom)
plot(cabinet3.1.3$pct_female, cabinet3.1.3$PerWom)
mean(cabinet3.1.3$pct_female)
mean(cabinet3.1.3$PerWom)

#Collect and save
cabinet3.1.6<-dplyr::select(cabinet3.1.2, c("COWCode", "year", "counter", "pct_female",
                                            "pct_male", "avg_age","gender_ps",
                                            "counter_party", "counter_gender",
                                            "counter_age"))

#save(cabinet3.1.6, file="cabinet3.1.6.RData")




###Calculate percentage of cabinet from respondent's party
#To merge with WVS will then need to create new df with rows for each party percentage (wide to long)
#Get percentages
cabinet3.1.2[,22:405]<-cabinet3.1.2[,22:405] / cabinet3.1.2$counter_party 

#Create new df going from wide to long
cabinet3.1.5<-cabinet3.1.2[,c(1,2,22:405)]
cabinet3.1.4 <- gather(cabinet3.1.5, party_name, party_pct, party_wvs_554005:party_wvs_643031, factor_key=TRUE)

#Get rid of NAs, but keep zeroes because indicates a potential party in a given country
cabinet3.1.4<-cabinet3.1.4[!is.na(cabinet3.1.4$party_pct),]
#Split and get party code
cabinet3.1.4$party_code<-str_split_fixed(cabinet3.1.4$party_name, "_", n=3)[,3]
#Ready to merge with WVS
#save(cabinet3.1.4, file="cabinet3.1.4.RData")



###Calculate party diversity score
#DF with country-year and party percentages
cabinet_year<-cabinet3.1.5

#Create counter for number of parties
cabinet_year$party_counter<-rowSums(cabinet_year[,3:386]!=0)
#Square
cabinet_year[,3:386]<-cabinet_year[,3:386]^2
#Create HH index for each party
cabinet_year$party_hh<-1-rowSums(cabinet_year[,3:386])
cabinet_year$party_hh<-ifelse(cabinet_year$party_counter==0,0,cabinet_year$party_hh)
cabinet_year<-dplyr::select(cabinet_year, c("COWCode", "year", "party_counter", "party_hh"))


#Read in NamePrism
#Obtain on your own (see Read_Me)
nameprism<-read.csv("cabinet_nameprism.csv", header=T, stringsAsFactors = F)
nameprism$ethnicity_hh<-nameprism$elf
nameprism$ethnicity_max<-nameprism$Max
nameprism<-dplyr::select(nameprism, c("COWCode", "year", "ethnicity_hh", "ethnicity_max"))

#Extra observations for where party information is missing
cabinet_year2<-merge(cabinet_year, nameprism, by=c("COWCode", "year"), all.x=T, all.y=T)

#save(cabinet_year2, file="cabinet_year2.RData")
#Ready to merge


#Calculate leader characteristics
cabinet3.2<-cabinet3[cabinet3$leader==1,]
cabinet3.2$l_female<-ifelse(cabinet3.2$gender=="Female",1,0)
cabinet3.2$l_male<-ifelse(cabinet3.2$gender=="Male",1,0)

cabinet3.2$party_wvs<-ifelse(cabinet3.2$multiparty_citizens=="No", NA, cabinet3.2$party_wvs)
cabinet3.2$party_wvs<-ifelse(cabinet3.2$party_wvs=="",NA,cabinet3.2$party_wvs)
cabinet3.2$party_wvs<-ifelse(cabinet3.2$party_wvs=="No party",NA,cabinet3.2$party_wvs)
cabinet3.2$party_wvs<-ifelse(cabinet3.2$party_wvs=="None",NA,cabinet3.2$party_wvs)
cabinet3.2$l_party<-cabinet3.2$party_wvs

cabinet3.2$l_age<-cabinet3.2$year-cabinet3.2$birthyear

cabinet3.2<-dplyr::select(cabinet3.2, c("COWCode", "year", "l_female", 
                                        "l_male", "l_party", "l_age"))
#Ready to merge with WVS
#save(cabinet3.2, file="cabinet3.2.RData")





###EPR Dominant Cabinet Power
#Obtain on your own (see Read_Me)
epr<-read.csv("EPR-2019.csv", header=T, stringsAsFactors = F)

#Fix EPR COWCodes
epr$COWCode<-epr$gwid
#Germany
epr$COWCode<-ifelse(epr$COWCode==260, 255, epr$COWCode)
#Yemen
epr$COWCode<-ifelse(epr$COWCode==678, 679, epr$COWCode)


#Create ethnicity coding list
wvs_subset<-dplyr::select(wvs, c("COWCode", "year", "respondent"))
wvs_subset<-unique(wvs_subset)

wvs_cabinet<-merge(wvs_subset, cabinet, by=c("COWCode", "year"))

wvs_cabinet3<-dplyr::select(wvs_cabinet, c("country_name", "COWCode", "party_english"))
wvs_cabinet3<-unique(wvs_cabinet3)
#write.csv(wvs_cabinet2, file="wvs_cabinet2.csv", row.names=F)

#Table to check
wvs_ethnicity_code<-read.csv("wvs_ethnicity_code.csv", header=T, stringsAsFactors = F)

wvs_ethnicity<-as.data.frame(table(wvs$X051, wvs$country_name))
wvs_ethnicity<-wvs_ethnicity[wvs_ethnicity$Freq!=0,]
colnames(wvs_ethnicity)<-c("Code", "Country", "Freq")

wvs_ethnicity2<-merge(wvs_ethnicity, wvs_ethnicity_code, by="Code", all.x=T)
#write.csv(wvs_ethnicity2, file="wvs_ethnicity2.csv", row.names=F)

wvs_ethnicity_list<-as.data.frame(t(data.frame(as.list(val_labels(wvs$X051)))))
wvs_ethnicity_list$name<-row.names(wvs_ethnicity_list)


#Subset to appropriate years
wvs2<-wvs

wvs2$exclude_country<-ifelse(wvs2$COWCode==344, 1, 0)
wvs2$exclude_country<-ifelse(wvs2$COWCode==352, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==42, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==651, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==92, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==366, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==375, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==260, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==255, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==350, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==90, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==325, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==690, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==660, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==620, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==368, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==432, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==70, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==341, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==210, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==385, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==840, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==290, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==694, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==732, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==517, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==670, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==317, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==349, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==230, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==510, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==52, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==616, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==500, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==369, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==200, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==816, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==678, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==679, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==551, 1, wvs2$exclude_country)
wvs2$exclude_country<-ifelse(wvs2$COWCode==552, 1, wvs2$exclude_country)




#Exclude certain years (need to exclude years where not asked)
wvs2$exclude_year<-ifelse(wvs2$COWCode==771 & wvs2$year==2002, 1, 0)
wvs2$exclude_year<-ifelse(wvs2$COWCode==771 & wvs2$year==2018, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==20 & wvs2$year==1990, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==20 & wvs2$year==2000, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==20 & wvs2$year==2006, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==710 & wvs2$year==1995, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==710 & wvs2$year==2007, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==710 & wvs2$year==2013, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==710 & wvs2$year==2018, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==475 & wvs2$year==1990, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==475 & wvs2$year==1995, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==475 & wvs2$year==2000, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==360 & wvs2$year==2011, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==345 & wvs2$year==2001, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==345 & wvs2$year==2017, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==800 & wvs2$year==2007, 1, wvs2$exclude_year)
wvs2$exclude_year<-ifelse(wvs2$COWCode==369 & wvs2$year==2006, 1, wvs2$exclude_year)

wvs3<-wvs2[wvs2$exclude_country==0,]
wvs3<-wvs3[wvs3$exclude_year==0,]
#Total respondents to ethnicity question
sum(table(wvs3$X051))


#Import EPR correspondence
epr_wvs<-read.csv("EPR_WVS_Correspondence.csv", header=T, stringsAsFactors = F)
epr_wvs<-epr_wvs[,c(1,3,6:9)]

#There will be duplicates here because some EPR groups go to multiple WVS codings
epr2<-merge(epr, epr_wvs, by=c("gwid", "group"), all.x=T, all.y=F)
epr2<-unique(epr2)

#Restrict to only politically relevant ethnic groups
epr2<-epr2[epr2$status!="IRRELEVANT",]

#Create a year variable. For each row, expand the dataset from the from to the to year
#Rbind each year to each other.
epr2$year<-epr2$from
epr3<-data.frame(matrix(nrow=0, ncol=0))
for(i in 1:nrow(epr2)){
temp<-epr2[i,] %>% 
  complete(year = full_seq(from:to, 1)) %>% 
  fill(names(epr2[i,]))
epr3<-rbind(epr3, temp)
}
epr3<-as.data.frame(epr3)

#Exclude country and year
#Exclude because different coding system
epr3$exclude_country<-ifelse(epr3$COWCode==344, 1, 0)
epr3$exclude_country<-ifelse(epr3$COWCode==352, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==42, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==651, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==92, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==366, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==375, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==260, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==255, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==350, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==90, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==325, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==690, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==660, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==620, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==368, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==432, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==70, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==341, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==210, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==385, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==840, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==290, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==694, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==732, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==517, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==670, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==317, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==349, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==230, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==510, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==52, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==616, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==500, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==369, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==200, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==816, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==678, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==679, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==551, 1, epr3$exclude_country)
epr3$exclude_country<-ifelse(epr3$COWCode==552, 1, epr3$exclude_country)


#Exclude certain years (need to exclude years where not asked)
epr3$exclude_year<-ifelse(epr3$COWCode==771 & epr3$year==2002, 1, 0)
epr3$exclude_year<-ifelse(epr3$COWCode==771 & epr3$year==2018, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==20 & epr3$year==1990, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==20 & epr3$year==2000, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==20 & epr3$year==2006, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==710 & epr3$year==1995, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==710 & epr3$year==2007, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==710 & epr3$year==2013, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==710 & epr3$year==2018, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==475 & epr3$year==1990, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==475 & epr3$year==1995, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==475 & epr3$year==2000, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==360 & epr3$year==2011, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==345 & epr3$year==2001, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==345 & epr3$year==2017, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==800 & epr3$year==2007, 1, epr3$exclude_year)
epr3$exclude_year<-ifelse(epr3$COWCode==369 & epr3$year==2006, 1, epr3$exclude_year)

#Zero out EPR for excluded countries and years
epr3$status<-ifelse(epr3$exclude_country==1,NA,epr3$status)
epr3$status<-ifelse(epr3$exclude_year==1,NA,epr3$status)
epr3$wvs_ethnicity<-ifelse(epr3$exclude_country==1,NA,epr3$wvs_ethnicity)
epr3$wvs_ethnicity<-ifelse(epr3$exclude_year==1,NA,epr3$wvs_ethnicity)


#Create dummies for different power levels
epr3$ethnic_discriminated<-ifelse(epr3$status=="DISCRIMINATED",1,0)
epr3$ethnic_dominant<-ifelse(epr3$status=="DOMINANT",1,0)
epr3$ethnic_junior<-ifelse(epr3$status=="JUNIOR PARTNER",1,0)
epr3$ethnic_monopoly<-ifelse(epr3$status=="MONOPOLY",1,0)
epr3$ethnic_powerless<-ifelse(epr3$status=="POWERLESS",1,0)
epr3$ethnic_selfexclude<-ifelse(epr3$status=="SELF-EXCLUSION",1,0)
epr3$ethnic_senior<-ifelse(epr3$status=="SENIOR PARTNER",1,0)
epr3$ethnic_incabinet<-epr3$ethnic_dominant+epr3$ethnic_junior+
  epr3$ethnic_monopoly+epr3$ethnic_senior
epr3$ethnic_notincabinet<-ifelse(epr3$ethnic_incabinet==0,1,0)

#save(epr3, file="epr3.RData")
#Ready to merge with WVS


###Calculate ethnic group variables from EPR
#Get rid of duplicate rows from WVS merging that are in EPR3
epr4<-epr3[,-c(14:15)]
epr4<-unique(epr4)
epr4<-epr4[epr4$exclude_country==0,]
epr4<-epr4[epr4$exclude_year==0,]


#Create max ethnic group size variable to code minority and majority groups
epr4.1<-as.data.frame(dplyr::select(epr4, c("COWCode", "year", "size"))%>%
                        group_by(COWCode, year)%>%
                        summarise_all(max, na.rm=T))
epr4.1$ethnic_max_size<-epr4.1$size

#Count number of ethnic groups in cabinet
epr4$counter_ethnicgroup<-1
epr4.2<-as.data.frame(dplyr::select(epr4, c("COWCode", "year", "ethnic_monopoly",
                                            "ethnic_dominant", "ethnic_senior",
                                            "ethnic_junior", "ethnic_incabinet",
                                            "counter_ethnicgroup"))%>%
                        group_by(COWCode, year)%>%
                        summarise_all(sum, na.rm=T))
#Several cases are not possible (zero ethnic groups in the cabinet)
epr4.2<-epr4.2[epr4.2$ethnic_incabinet!=0,]

epr4.2$pct_ethnicity_rep<-epr4.2$ethnic_incabinet/epr4.2$counter_ethnicgroup
epr4.2$ethnic_monopoly_dominant<-epr4.2$ethnic_dominant+epr4.2$ethnic_monopoly
epr4.2$pct_e_monopoly_dominant<-epr4.2$ethnic_monopoly_dominant/epr4.2$counter_ethnicgroup
epr4.2$pct_e_senior<-epr4.2$ethnic_senior/epr4.2$counter_ethnicgroup
epr4.2$pct_e_junior<-epr4.2$ethnic_junior/epr4.2$counter_ethnicgroup
epr4.2$pct_e_incabinet<-epr4.2$ethnic_incabinet/epr4.2$counter_ethnicgroup
epr4.2$ethnic_ps<-(3*epr4.2$pct_e_senior+2*epr4.2$pct_e_junior+epr4.2$pct_e_monopoly_dominant)*
  epr4.2$pct_e_incabinet

epr4.3<-merge(epr4.1, epr4.2, by=c("COWCode", "year"), all.x=T, all.y=T)
epr4.3<-dplyr::select(epr4.3, c("COWCode", "year", "ethnic_max_size",
                                "ethnic_monopoly", "ethnic_dominant",
                                "ethnic_senior", "ethnic_junior", "ethnic_incabinet",
                                "counter_ethnicgroup", "pct_ethnicity_rep",
                                "ethnic_ps"))
names(epr4.3)<-c("COWCode", "year", "ethnic_max_size", "ethnic_num_monopoly",
                 "ethnic_num_dominant", "ethnic_num_senior", "ethnic_num_junior",
                 "ethnic_num_incabinet", "counter_ethnicgroup", "pct_ethnicity_rep",
                 "ethnic_ps")


#save(epr4.3, file="epr4.3.RData")


###Get majority and minority group by country-year over all WVS dataset
#load("wvs2.RData")
library(stringr)
library(stringi)

wvs_all2<-wvs2[!is.na(wvs2$ethnicity),]
#Need to break down unique country-year pairs
wvs_ccode_year<-as.data.frame(cbind(wvs_all2$COWCode, wvs_all2$year))
colnames(wvs_ccode_year)<-c("COWCode", "year")
wvs_ccode_year<-unique(wvs_ccode_year)

wvs_ethnic_maj<-as.data.frame(matrix(nrow=211,ncol=3))

#Pull majority ethnic groups in each country
#tryCatch as there are two coding errors in the dataset
for(i in 1:211){
  tryCatch({
    print(i)
    #Country
    j<-wvs_ccode_year[i,1]
    #Year
    k<-wvs_ccode_year[i,2]
    temp<-as.data.frame(table(wvs_all2[(wvs_all2$COWCode==j) & (wvs_all2$year==k),]$ethnicity))
    wvs_ethnic_maj[i,3]<-as.numeric(as.character(temp[which.max(temp$Freq),1]))
    wvs_ethnic_maj[i,1]<-j
    wvs_ethnic_maj[i,2]<-k
  }, error=function(e){})
}

colnames(wvs_ethnic_maj)<-c('COWCode','year', 'ethnicity')
wvs_ethnic_maj$ethnic_maj<-1
wvs_ethnic_maj$country_year_included<-1

#save(wvs_ethnic_maj, file="wvs_ethnic_maj.RData")







###Merge with WVS
#load("wvs2.RData")
#load("cabinet3.1.6.RData")
cabinet3.1.6<-pdata.frame(cabinet3.1.6,index=c("COWCode","year"))  
cabinet3.1.6$counter_l<-lag(cabinet3.1.6$counter, k=1)
cabinet3.1.6$pct_female_l<-lag(cabinet3.1.6$pct_female, k=1)
cabinet3.1.6$pct_male_l<-lag(cabinet3.1.6$pct_male, k=1)
cabinet3.1.6$avg_age_l<-lag(cabinet3.1.6$avg_age, k=1)
cabinet3.1.6$gender_ps_l<-lag(cabinet3.1.6$gender_ps, k=1)
cabinet3.1.6$counter_party_l<-lag(cabinet3.1.6$counter_party, k=1)
cabinet3.1.6$counter_gender_l<-lag(cabinet3.1.6$counter_gender, k=1)
cabinet3.1.6$counter_age_l<-lag(cabinet3.1.6$counter_age, k=1)


#load("cabinet3.1.4.RData")


#load("cabinet3.2.RData")
cabinet3.2<-pdata.frame(cabinet3.2,index=c("COWCode","year"))  
cabinet3.2$l_female_l<-lag(cabinet3.2$l_female, k=1)
cabinet3.2$l_male_l<-lag(cabinet3.2$l_male, k=1)
cabinet3.2$l_party_l<-lag(cabinet3.2$l_party, k=1)
cabinet3.2$l_age_l<-lag(cabinet3.2$l_age, k=1)



#load("cabinet_year2.RData")
cabinet_year2<-pdata.frame(cabinet_year2,index=c("COWCode","year"))  
cabinet_year2$party_counter_l<-lag(cabinet_year2$party_counter, k=1)
cabinet_year2$party_hh_l<-lag(cabinet_year2$party_hh, k=1)
cabinet_year2$ethnicity_hh_l<-lag(cabinet_year2$ethnicity_hh, k=1)
cabinet_year2$ethnicity_max_l<-lag(cabinet_year2$ethnicity_max, k=1)



#load("epr3.RData")


#load("epr4.3.RData")
epr4.3<-pdata.frame(epr4.3,index=c("COWCode","year"))  
epr4.3$ethnic_max_size_l<-lag(epr4.3$ethnic_max_size, k=1)
epr4.3$ethnic_num_monopoly_l<-lag(epr4.3$ethnic_num_monopoly, k=1)
epr4.3$ethnic_num_dominant_l<-lag(epr4.3$ethnic_num_dominant, k=1)
epr4.3$ethnic_num_senior_l<-lag(epr4.3$ethnic_num_senior, k=1)
epr4.3$ethnic_num_junior_l<-lag(epr4.3$ethnic_num_junior, k=1)
epr4.3$ethnic_num_incabinet_l<-lag(epr4.3$ethnic_num_incabinet, k=1)
epr4.3$counter_ethnicgroup_l<-lag(epr4.3$counter_ethnicgroup, k=1)
epr4.3$pct_ethnicity_rep_l<-lag(epr4.3$pct_ethnicity_rep, k=1)
epr4.3$ethnic_ps_l<-lag(epr4.3$ethnic_ps, k=1)


#load("wvs_ethnic_maj.RData")


#Merge Party with WVS
wvs2_cabinet3.1.4<-merge(wvs2, cabinet3.1.4, by.x=c("COWCode", "year", "party_vote"),
                         by.y=c("COWCode", "year", "party_code"),all.x=T, all.y=F)

#Put in lag
cabinet3.1.4.1<-cabinet3.1.4[,-c(3:340)]
colnames(cabinet3.1.4.1)<-c("COWCode", "year", "party_pct_l", "party_code")
cabinet3.1.4.1$year<-cabinet3.1.4.1$year-1

wvs2_cabinet3.1.4.1<-merge(wvs2_cabinet3.1.4, cabinet3.1.4.1, by.x=c("COWCode", "year", "party_vote"),
                         by.y=c("COWCode", "year", "party_code"),all.x=T, all.y=F)



#Create gender and leader dataset
cabinet3.1.6_cabinet3.2<-merge(cabinet3.1.6, cabinet3.2, by=c("COWCode", "year"), all.x=T, all.y=T)

#Merge with WVS/Party
wvs2_cabinet_combined<-merge(wvs2_cabinet3.1.4.1, cabinet3.1.6_cabinet3.2, by=c("COWCode", "year"), all.x=T, all.y=F)

#Merge with party and ethnicity HH
wvs2_cabinet_year<-merge(wvs2_cabinet_combined, cabinet_year2, by=c("COWCode", "year"), all.x=T, all.y=F)

#Merge to get majority ethnicity designation
wvs2_majority<-merge(wvs2_cabinet_year, wvs_ethnic_maj[,c(1:4)], by=c("COWCode", "year", "ethnicity"), all.x=T, all.y=F)

#Lag
wvs_ethnic_maj$year<-wvs_ethnic_maj$year-1
colnames(wvs_ethnic_maj)<-c("COWCode", "year", "ethnicity", "ethnic_maj_l", "country_year_included_l")
wvs2_majority2<-merge(wvs2_majority, wvs_ethnic_maj[,c(1:4)], by=c("COWCode", "year", "ethnicity"), all.x=T, all.y=F)


#Merge to get country-years where majority group was calculated
#load("wvs_ethnic_maj.RData")
wvs2_ethnicity_country<-merge(wvs2_majority, wvs_ethnic_maj[,c(1,2,5)], by=c("COWCode", "year"), all.x=T, all.y=F)

#Lag
wvs_ethnic_maj$year<-wvs_ethnic_maj$year-1
colnames(wvs_ethnic_maj)<-c("COWCode", "year", "ethnicity", "ethnic_maj_l", "country_year_included_l")
wvs2_ethnicity_country2<-merge(wvs2_ethnicity_country, wvs_ethnic_maj[,c(1,2,5)], by=c("COWCode", "year"), all.x=T, all.y=F)


wvs2_epr<-merge(wvs2_ethnicity_country2, epr4.3, by=c("COWCode", "year"), all.x=T, all.y=F)


#Merge EPR and WVS
epr3<-unique(epr3)

#Select unique COW, year, and ethnicity combinations
wvs_cowcode<-as.data.frame(unique(dplyr::select(wvs, c("COWCode", "year", "ethnicity"))))
wvs_cowcode$wvs_in<-1
colnames(wvs_cowcode)<-c("COWCode", "year", "wvs_ethnicity", "wvs_in")

epr3.1<-merge(epr3, wvs_cowcode, by=c("COWCode", "year", "wvs_ethnicity"), all.x=T, all.y=F)
epr3.1$wvs_in<-ifelse(is.na(epr3.1$wvs_in),0,1)
epr3.2<-epr3.1[epr3.1$wvs_in==1,]
#Get rid of NA ethnicities
epr3.3<-epr3.2[!is.na(epr3.2$wvs_ethnicity),]

wvs2_epr3<-merge(wvs2_epr, epr3.3, by.x=c("COWCode", "year", "ethnicity"),
                 by.y=c("COWCode", "year", "wvs_ethnicity"), all.x=T, all.y=F)

#May need to restart R or clear environment                         
wvs2_epr3<-unique(wvs2_epr3)


#Merge with lag
epr3.3$year<-epr3.3$year-1
epr3.3<-epr3.3[,c(1:3,12,16:27)]
colnames(epr3.3)<-c("COWCode", "year", "wvs_ethnicity", "size_l", "exclude_country_l",
                    "exclude_year_l", "ethnic_discriminated_l", "ethnic_dominant_l",
                    "ethnic_junior_l", "ethnic_monopoly_l", "ethnic_powerless_l",
                    "ethnic_selfexclude_l", "ethnic_senior_l", "ethnic_incabinet_l",
                    "ethnic_notincabinet_l", "wvs_in_l")
wvs2_epr3.1<-merge(wvs2_epr3, epr3.3, by.x=c("COWCode", "year", "ethnicity"),
                 by.y=c("COWCode", "year", "wvs_ethnicity"), all.x=T, all.y=F)

wvs3<-unique(wvs2_epr3.1)

#save(wvs3, file="wvs3.RData")

#load("wvs3.RData")
#Add in 0s for parties not represented
wvs3$counter_party01<-ifelse(wvs3$counter_party>0,1,0)
wvs3$counter_party01_l<-ifelse(wvs3$counter_party_l>0,1,0)


#There are no NA party names
wvs3$party_name<-str_split_fixed(wvs3$party_name, "_", n=3)[,3]
#There are NA party percentages
wvs3$party_pct<-ifelse(is.na(wvs3$party_pct),wvs3$counter_party01,wvs3$party_pct)
wvs3$party_pct_l<-ifelse(is.na(wvs3$party_pct_l),wvs3$counter_party01_l,wvs3$party_pct_l)


#Add in 0s for ethnicities not represented (but not in excluded countries)
epr_exclude<-dplyr::select(epr3, c("COWCode", "year", "exclude_country", "exclude_year"))
epr_exclude<-unique(epr_exclude)

epr_exclude2<-dplyr::select(epr3.3, c("COWCode", "year", "exclude_country_l", "exclude_year_l"))
epr_exclude2<-unique(epr_exclude2)

wvs3<-subset(wvs3, select=-c(exclude_country, exclude_year, exclude_country_l, exclude_year_l))
wvs3.1<-merge(wvs3, epr_exclude, by=c("COWCode", "year"), all.x=T, all.y=F)
wvs3.1<-merge(wvs3.1, epr_exclude2, by=c("COWCode", "year"), all.x=T, all.y=F)




#Code new vars
wvs3.1$exclude_country_year<-wvs3.1$exclude_country+wvs3.1$exclude_year
wvs3.1$exclude_country_year<-ifelse(wvs3.1$exclude_country_year>0,1,wvs3.1$exclude_country_year)
wvs3.1$include_country_year<-ifelse(wvs3.1$exclude_country_year==1,NA,wvs3.1$exclude_country_year)

wvs3.1$exclude_country_year_l<-wvs3.1$exclude_country_l+wvs3.1$exclude_year_l
wvs3.1$exclude_country_year_l<-ifelse(wvs3.1$exclude_country_year_l>0,1,wvs3.1$exclude_country_year_l)
wvs3.1$include_country_year_l<-ifelse(wvs3.1$exclude_country_year_l==1,NA,wvs3.1$exclude_country_year_l)



wvs3.1$ethnic_discriminated<-ifelse(is.na(wvs3.1$ethnic_discriminated),
                                  wvs3.1$include_country_year,wvs3.1$ethnic_discriminated)
wvs3.1$ethnic_dominant<-ifelse(is.na(wvs3.1$ethnic_dominant),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_dominant)
wvs3.1$ethnic_junior<-ifelse(is.na(wvs3.1$ethnic_junior),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_junior)
wvs3.1$ethnic_monopoly<-ifelse(is.na(wvs3.1$ethnic_monopoly),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_monopoly)
wvs3.1$ethnic_powerless<-ifelse(is.na(wvs3.1$ethnic_powerless),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_powerless)
wvs3.1$ethnic_selfexclude<-ifelse(is.na(wvs3.1$ethnic_selfexclude),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_selfexclude)
wvs3.1$ethnic_senior<-ifelse(is.na(wvs3.1$ethnic_senior),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_senior)
wvs3.1$ethnic_incabinet<-ifelse(is.na(wvs3.1$ethnic_incabinet),
                                    wvs3.1$include_country_year,wvs3.1$ethnic_incabinet)
wvs3.1$ethnic_notincabinet<-ifelse(wvs3.1$ethnic_incabinet==0,1,0)


wvs3.1$ethnic_discriminated_l<-ifelse(is.na(wvs3.1$ethnic_discriminated_l),
                                    wvs3.1$include_country_year_l,wvs3.1$ethnic_discriminated_l)
wvs3.1$ethnic_dominant_l<-ifelse(is.na(wvs3.1$ethnic_dominant_l),
                               wvs3.1$include_country_year_l,wvs3.1$ethnic_dominant_l)
wvs3.1$ethnic_junior_l<-ifelse(is.na(wvs3.1$ethnic_junior_l),
                             wvs3.1$include_country_year_l,wvs3.1$ethnic_junior_l)
wvs3.1$ethnic_monopoly_l<-ifelse(is.na(wvs3.1$ethnic_monopoly_l),
                               wvs3.1$include_country_year_l,wvs3.1$ethnic_monopoly_l)
wvs3.1$ethnic_powerless_l<-ifelse(is.na(wvs3.1$ethnic_powerless_l),
                                wvs3.1$include_country_year_l,wvs3.1$ethnic_powerless_l)
wvs3.1$ethnic_selfexclude_l<-ifelse(is.na(wvs3.1$ethnic_selfexclude_l),
                                  wvs3.1$include_country_year_l,wvs3.1$ethnic_selfexclude_l)
wvs3.1$ethnic_senior_l<-ifelse(is.na(wvs3.1$ethnic_senior_l),
                             wvs3.1$include_country_year_l,wvs3.1$ethnic_senior_l)
wvs3.1$ethnic_incabinet_l<-ifelse(is.na(wvs3.1$ethnic_incabinet_l),
                                wvs3.1$include_country_year_l,wvs3.1$ethnic_incabinet_l)
wvs3.1$ethnic_notincabinet_l<-ifelse(wvs3.1$ethnic_incabinet_l==0,1,0)







#Match on percentage gender in the cabinet
wvs3.1$pct_gender<-ifelse(wvs3.1$female==1, wvs3.1$pct_female, wvs3.1$pct_male)
wvs3.1$pct_gender_l<-ifelse(wvs3.1$female==1, wvs3.1$pct_female_l, wvs3.1$pct_male_l)


#Create age brackets for respondents
wvs3.1$ageto35<-ifelse(wvs3.1$age<35,1,0)
wvs3.1$age35_49<-ifelse(wvs3.1$age>=35 & wvs3.1$age<50,1,0)
wvs3.1$age50_64<-ifelse(wvs3.1$age>=50 & wvs3.1$age<65,1,0)
wvs3.1$age65over<-ifelse(wvs3.1$age>=65,1,0)

#Measure age distance between respondent and average cabinet/leader
wvs3.1$age_cabinet_35_49<-ifelse(wvs3.1$avg_age>=35 & wvs3.1$avg_age<50,1,0)
wvs3.1$age_cabinet_50_64<-ifelse(wvs3.1$avg_age>=50 & wvs3.1$avg_age<65,1,0)
wvs3.1$age_cabinet_65over<-ifelse(wvs3.1$avg_age>=65,1,0)

wvs3.1$age_c_35_49<-ifelse(wvs3.1$age35_49==1 & wvs3.1$age_cabinet_35_49==1,1,0)
wvs3.1$age_c_50_64<-ifelse(wvs3.1$age50_64==1 & wvs3.1$age_cabinet_50_64==1,1,0)
wvs3.1$age_c_65over<-ifelse(wvs3.1$age65over==1 & wvs3.1$age_cabinet_65over==1,1,0)

wvs3.1$age_cabinet_match<-ifelse(wvs3.1$age_c_35_49==1|
                                   wvs3.1$age_c_50_64==1|wvs3.1$age_c_65over==1,1,0)
wvs3.1$age_cabinet_match<-ifelse(is.na(wvs3.1$age),NA,wvs3.1$age_cabinet_match)
wvs3.1$age_cabinet_match<-ifelse(is.na(wvs3.1$avg_age),NA,wvs3.1$age_cabinet_match)

#Lag
wvs3.1$age_cabinet_35_49_l<-ifelse(wvs3.1$avg_age_l>=35 & wvs3.1$avg_age_l<50,1,0)
wvs3.1$age_cabinet_50_64_l<-ifelse(wvs3.1$avg_age_l>=50 & wvs3.1$avg_age_l<65,1,0)
wvs3.1$age_cabinet_65over_l<-ifelse(wvs3.1$avg_age_l>=65,1,0)

wvs3.1$age_c_35_49_l<-ifelse(wvs3.1$age35_49==1 & wvs3.1$age_cabinet_35_49_l==1,1,0)
wvs3.1$age_c_50_64_l<-ifelse(wvs3.1$age50_64==1 & wvs3.1$age_cabinet_50_64_l==1,1,0)
wvs3.1$age_c_65over_l<-ifelse(wvs3.1$age65over==1 & wvs3.1$age_cabinet_65over_l==1,1,0)

wvs3.1$age_cabinet_match_l<-ifelse(wvs3.1$age_c_35_49_l==1|
                                   wvs3.1$age_c_50_64_l==1|wvs3.1$age_c_65over_l==1,1,0)
wvs3.1$age_cabinet_match_l<-ifelse(is.na(wvs3.1$age),NA,wvs3.1$age_cabinet_match_l)
wvs3.1$age_cabinet_match_l<-ifelse(is.na(wvs3.1$avg_age),NA,wvs3.1$age_cabinet_match_l)

#Match leader age
wvs3.1$age_leader_to35<-ifelse(wvs3.1$l_age<35,1,0)
wvs3.1$age_leader_35_49<-ifelse(wvs3.1$l_age>=35 & wvs3.1$l_age<50,1,0)
wvs3.1$age_leader_50_64<-ifelse(wvs3.1$l_age>=50 & wvs3.1$l_age<65,1,0)
wvs3.1$age_leader_65over<-ifelse(wvs3.1$l_age>=65,1,0)

wvs3.1$age_l_to35<-ifelse(wvs3.1$ageto35==1 & wvs3.1$age_leader_to35==1,1,0)
wvs3.1$age_l_35_49<-ifelse(wvs3.1$age35_49==1 & wvs3.1$age_leader_35_49==1,1,0)
wvs3.1$age_l_50_64<-ifelse(wvs3.1$age50_64==1 & wvs3.1$age_leader_50_64==1,1,0)
wvs3.1$age_l_65over<-ifelse(wvs3.1$age65over==1 & wvs3.1$age_leader_65over==1,1,0)

wvs3.1$age_l_match<-ifelse(wvs3.1$age_l_to35==1|wvs3.1$age_l_35_49==1|
                                   wvs3.1$age_l_50_64==1|wvs3.1$age_l_65over==1,1,0)
wvs3.1$age_l_match<-ifelse(is.na(wvs3.1$age),NA,wvs3.1$age_l_match)
wvs3.1$age_l_match<-ifelse(is.na(wvs3.1$l_age),NA,wvs3.1$age_l_match)

#Lag
wvs3.1$age_leader_to35_l<-ifelse(wvs3.1$l_age_l<35,1,0)
wvs3.1$age_leader_35_49_l<-ifelse(wvs3.1$l_age_l>=35 & wvs3.1$l_age_l<50,1,0)
wvs3.1$age_leader_50_64_l<-ifelse(wvs3.1$l_age_l>=50 & wvs3.1$l_age_l<65,1,0)
wvs3.1$age_leader_65over_l<-ifelse(wvs3.1$l_age_l>=65,1,0)

wvs3.1$age_l_to35_l<-ifelse(wvs3.1$ageto35==1 & wvs3.1$age_leader_to35_l==1,1,0)
wvs3.1$age_l_35_49_l<-ifelse(wvs3.1$age35_49==1 & wvs3.1$age_leader_35_49_l==1,1,0)
wvs3.1$age_l_50_64_l<-ifelse(wvs3.1$age50_64==1 & wvs3.1$age_leader_50_64_l==1,1,0)
wvs3.1$age_l_65over_l<-ifelse(wvs3.1$age65over==1 & wvs3.1$age_leader_65over_l==1,1,0)

wvs3.1$age_l_match_l<-ifelse(wvs3.1$age_l_to35_l==1|wvs3.1$age_l_35_49_l==1|
                             wvs3.1$age_l_50_64_l==1|wvs3.1$age_l_65over_l==1,1,0)
wvs3.1$age_l_match_l<-ifelse(is.na(wvs3.1$age),NA,wvs3.1$age_l_match_l)
wvs3.1$age_l_match_l<-ifelse(is.na(wvs3.1$l_age),NA,wvs3.1$age_l_match_l)






#Match on leader's characteristics
wvs3.1$l_party_match<-ifelse(wvs3.1$l_party==wvs3.1$party_name, 1, 0)
wvs3.1$l_gender_match<-ifelse(wvs3.1$l_female==wvs3.1$female, 1, 0)

wvs3.1$l_party_match_l<-ifelse(wvs3.1$l_party_l==wvs3.1$party_name, 1, 0)
wvs3.1$l_gender_match_l<-ifelse(wvs3.1$l_female_l==wvs3.1$female, 1, 0)

#See if respondent is in majority ethnic group from EPR
wvs3.1$ethnic_majority_epr<-ifelse(wvs3.1$size==wvs3.1$ethnic_max_size,1,0)
wvs3.1$ethnic_minority_epr<-ifelse(wvs3.1$size!=wvs3.1$ethnic_max_size,1,0)

wvs3.1$ethnic_majority_epr_l<-ifelse(wvs3.1$size_l==wvs3.1$ethnic_max_size_l,1,0)
wvs3.1$ethnic_minority_epr_l<-ifelse(wvs3.1$size_l!=wvs3.1$ethnic_max_size_l,1,0)

#See if respondent is in majority ethnic group as calculated by WVS group size
wvs3.1$ethnic_majority_wvs<-ifelse(is.na(wvs3.1$ethnic_maj),0,wvs3.1$ethnic_maj)
wvs3.1$ethnic_minority_wvs<-1-wvs3.1$ethnic_majority_wvs

#Clear out not included country-years
wvs3.1$ethnic_majority_wvs<-ifelse(wvs3.1$country_year_included==1,
                                   wvs3.1$ethnic_majority_wvs,NA)
wvs3.1$ethnic_minority_wvs<-ifelse(wvs3.1$country_year_included==1,
                                   wvs3.1$ethnic_minority_wvs,NA)

wvs3.1$ethnic_majority_wvs_l<-ifelse(wvs3.1$country_year_included_l==1,
                                   wvs3.1$ethnic_majority_wvs,NA)
wvs3.1$ethnic_minority_wvs_l<-ifelse(wvs3.1$country_year_included_l==1,
                                   wvs3.1$ethnic_minority_wvs,NA)


wvs3.1$COWCode_f<-as.factor(wvs3.1$COWCode)
wvs3.1$year_f<-as.factor(wvs3.1$year)
wvs3.1$ideology_left<-ifelse(wvs3.1$ideology<6,1,0)



#save(wvs3.1, file="wvs3.1.RData")



###Country level data
library(countrycode)
library(haven)
library(plyr)
library(dplyr)
library(plm)

#Get country-year ethnicity measures
#Obtain on your own (see Read_Me)
load("HIEF_data.RData")
x$COWCode<-countrycode(x$Country, "country.name", "cown")
x$COWCode<-ifelse(x$Country=="Serbia", 345, x$COWCode)
x$COWCode<-ifelse(x$Country=="Republic of Vietnam", 816, x$COWCode)
x<-dplyr::select(x, c("COWCode", "Year", "EFindex"))

epr<-read_dta("EPR_countryyear_v1.1.dta")
epr<-dplyr::select(epr, c("cowcode", 'year', "elf"))

ethnicity<-merge(x, epr, by.x=c("COWCode", "Year"), by.y=c("cowcode", "year"), all.x=T, all.y=T)
colnames(ethnicity)<-c("COWCode", "year", "elf_hief", "elf_epr")

cor(ethnicity$elf_hief, ethnicity$elf_epr, use='complete.obs')
plot(ethnicity$elf_hief, ethnicity$elf_epr)

#Get Vdem data
#Obtain on your own (see Read_Me)
load("vdem.RData")
#v2lgfemleg: pct females in lower chamber
#e_polity2: Polity 2
#e_migdppcln: GDP per capita
vdem<-pdata.frame(vdem,index=c("COWcode","year")) 
vdem$pct_wm_leg<-vdem$v2lgfemleg
vdem$gdppc_ln<-vdem$e_migdppcln
vdem$polity2<-vdem$e_polity2

vdem$pct_wm_leg_l<-dplyr::lag(vdem$pct_wm_leg, k=1)
vdem$gdppc_ln_l<-dplyr::lag(vdem$gdppc_ln, k=1)
vdem$polity2_l<-dplyr::lag(vdem$polity2, k=1)

vdem<-dplyr::select(vdem, c("COWcode", "year", "pct_wm_leg", "gdppc_ln", "polity2",
                            "pct_wm_leg_l", "gdppc_ln_l", "polity2_l"))


ethnicity_vdem<-merge(ethnicity, vdem, by.x=c("COWCode", "year"), by.y=c("COWcode", "year"), all.x=T, all.y=T)

#load("wvs3.1.RData")
wvs3.2<-merge(wvs3.1, ethnicity_vdem, by=c("COWCode", "year"), all.x=T, all.y=F)

#save(wvs3.2, file="wvs3.2.RData")









