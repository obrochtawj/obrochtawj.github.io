###############################################################
### Ethnic Cabinet Diversity, Co-Ethnic Representation, and ###
### Attitudes Toward Government                             ###
### World Values Survey Analysis                            ###
### William O'Brochta, Texas Lutheran University            ###
################################################################ 

library(lme4)
library(stargazer)

load("wvs3.2.RData")

#Check WVS ethnic minority dominance
country_year<-dplyr::select(wvs3.2, c("country_name", "year_f"))
country_year<-unique(country_year)
country_year$majority<-NA
country_year$minority<-NA

for(i in 1:291){
  country_name<-country_year[i,1]
  year<-country_year[i,2]
  temp<-wvs3.2[wvs3.2$country_name==country_name & wvs3.2$year_f==year,]
  temp2<-table(temp$ethnic_minority_wvs)
  country_year[i,3]<-temp2[1]
  country_year[i,4]<-temp2[2]
}

country_year$majority_only<-ifelse(!is.na(country_year$majority)&is.na(country_year$minority),1,0)

#Good descriptive statistic: percent minority per country-year
country_year$total_sample<-country_year$majority+country_year$minority
country_year$pct_majority<-country_year$majority/country_year$total_sample
country_year$pct_minority<-1-country_year$pct_majority
country_year<-country_year[!is.na(country_year$majority),]

country_year2<-country_year[country_year$majority_only==0,]
summary(country_year2$pct_minority)
hist(country_year2$pct_minority)



wvs3.2<-merge(wvs3.2, country_year, by=c("country_name", "year_f"), all.x=T)
wvs3.2<-wvs3.2[wvs3.2$majority_only==0,]
wvs3.2$ethnic_incabinet_l<-lag(wvs3.2$ethnic_incabinet, k=1)
wvs3.2$ethnic_notincabinet_l<-lag(wvs3.2$ethnic_notincabinet, k=1)


#Descriptive statistic tables
attach(wvs3.2)
data_summary<-as.data.frame(cbind(conf_government,
                                  ethnic_incabinet_l,
                                  ethnic_minority_wvs,
                                  female, married, unemployed, income,
                                  ed_belowsecondary, ed_somesecondary, ed_secondary,
                                  ed_ba, ageto35,
                                  age35_49, age50_64, age65over, pol_interest, ideology_left))

detach(wvs3.2)
data_summary2<-as.data.frame(matrix(nrow=17, ncol=6))
for(i in 1:17){
  data_summary2[i,1]<-names(data_summary)[i]
  data_summary2[i,2]<-min(data_summary[,i], na.rm=T)
  data_summary2[i,3]<-max(data_summary[,i], na.rm=T)
  data_summary2[i,4]<-sqrt(var(data_summary[,i], na.rm=T))
  data_summary2[i,5]<-mean(data_summary[,i], na.rm=T)
  data_summary2[i,6]<-median(data_summary[,i], na.rm=T)
}
colnames(data_summary2)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")

library(xtable)
#Table SI.1.1
print(xtable(data_summary2, type='latex', digits=2), file='data_summary_individual.tex', include.rownames=FALSE)


afb_country<-dplyr::select(wvs3.2, c("country_name", "year", "pct_ethnicity_rep_l",
                                   "elf_hief", "polity2_l", "gdppc_ln_l",
                                   "pct_female_l", "pct_wm_leg_l"))
afb_country<-unique(afb_country)
data_summary<-afb_country[,-1]

data_summary2<-as.data.frame(matrix(nrow=7, ncol=6))
for(i in 1:7){
  data_summary2[i,1]<-names(data_summary)[i]
  data_summary2[i,2]<-min(data_summary[,i], na.rm=T)
  data_summary2[i,3]<-max(data_summary[,i], na.rm=T)
  data_summary2[i,4]<-sqrt(var(data_summary[,i], na.rm=T))
  data_summary2[i,5]<-mean(data_summary[,i], na.rm=T)
  data_summary2[i,6]<-median(data_summary[,i], na.rm=T)
}
colnames(data_summary2)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")

#Table SI.1.2
print(xtable(data_summary2, type='latex', digits=2), file='data_summary_country.tex', include.rownames=FALSE)





######Ethnicity Models
#ethnicity_hh (ethnic diversity, NamePrism)
#ethnic_ps (ethnic power score, EPR)
#pct_ethnicity_rep (percent of ethnic groups in cabinet, EPR)

#elf_epr
#elf_hief: way more cases

#Differences between EPR and WVS minority classifications
#Prefer WVS because it's a representative sample done at the survey time,
#not a census from EPR
cor(wvs3.2$ethnic_minority_epr, wvs3.2$ethnic_minority_wvs, use="complete.obs")
table(wvs3.2$ethnic_minority_epr, wvs3.2$ethnic_minority_wvs)/121503


model_mlm.0<-lme4::lmer(conf_government~female*pct_female_l+married+unemployed+income
                        +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                        +pol_interest+ideology_left+polity2_l+gdppc_ln_l+pct_wm_leg_l
                        +ethnic_incabinet_l+pct_ethnicity_rep_l+elf_hief+ethnic_minority_wvs
                        +(1|country_name)+(1|year_f), wvs3.2)
summary(model_mlm.0)


model_mlm<-lme4::lmer(conf_government~female*pct_female_l+married+unemployed+income
                +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                +pol_interest+ideology_left+polity2_l+gdppc_ln_l+pct_wm_leg_l
                +ethnic_incabinet_l*pct_ethnicity_rep_l+elf_hief+ethnic_minority_wvs
                +(1|country_name)+(1|year_f), wvs3.2)
summary(model_mlm)


#Add continent dummy variables
library(countrycode)
wvs3.2$continent<-countrycode(sourcevar=wvs3.2[,"COWCode"],
                              origin="cown",
                              destination="continent")
wvs3.2$continent<-ifelse(wvs3.2$COWCode=="345", "Europe", wvs3.2$continent)


model_mlm1<-lme4::lmer(conf_government~female*pct_female_l+married+unemployed+income
                      +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                      +pol_interest+ideology_left+polity2_l+gdppc_ln_l+pct_wm_leg_l
                      +ethnic_incabinet_l+pct_ethnicity_rep_l+elf_hief+ethnic_minority_wvs
                      +continent+(1|country_name)+(1|year_f), wvs3.2)
summary(model_mlm1)

model_mlm2<-lme4::lmer(conf_government~female*pct_female_l+married+unemployed+income
                       +ed_somesecondary+ed_secondary+ed_ba+age35_49+age50_64+age65over
                       +pol_interest+ideology_left+polity2_l+gdppc_ln_l+pct_wm_leg_l
                       +ethnic_incabinet_l*pct_ethnicity_rep_l+elf_hief+ethnic_minority_wvs
                       +continent+(1|country_name)+(1|year_f), wvs3.2)
summary(model_mlm2)


#What country years are included? About 60 country-years
included<-table(model_mlm@frame$country_name, model_mlm@frame$year_f)
colSums(included != 0)
rowSums(included != 0)


#Table SI.3.1
stargazer(model_mlm.0, model_mlm, model_mlm1, model_mlm2, out="models_conf_government.tex")





