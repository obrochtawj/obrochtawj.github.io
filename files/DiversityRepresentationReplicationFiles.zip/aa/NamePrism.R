
library(plyr)
library(dplyr)
library(tidyr)
library(countrycode)
library(nomine)
library(profvis)

cabinet<-read.csv("WhoGov_within_V1.1.csv", header=T, stringsAsFactors = F)
cabinet$name_lower<-tolower(cabinet$name)
cabinet$name_lower<-gsub("[[:punct:][:blank:]]+", " ", cabinet$name_lower)

#Check and fix unambiguous matching
cabinet$COWCode<-countrycode(cabinet$country_isocode, "iso3c", "cown")
cabinet$COWCode<-ifelse(cabinet$country_isocode=="DDR", 265, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="DVN", 816, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="RVN", 817, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="YPR", 680, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="SUN", 365, cabinet$COWCode)

#Yugoslavia continues until 1997 and then transitions to Serbia's ministers after.
cabinet$COWCode<-ifelse(cabinet$country_isocode=="YUG" & cabinet$year<1997, 345, cabinet$COWCode)
cabinet$COWCode<-ifelse(cabinet$country_isocode=="SRB", 345, cabinet$COWCode)

#Import existing NamePrism
old_nameprism<-read.csv("cabinet_with_nationality.csv", header=T, stringsAsFactors = F)

#Select unique names already coded
old_nameprism<-old_nameprism[,c(1,8:48)]
old_nameprism<-unique(old_nameprism)

#Select unique names
cabinet2<-merge(cabinet, old_nameprism, by.x="name_lower", by.y="Name", all.x=T, all.y=F)

#Subset to not coded names
cabinet3<-cabinet2[is.na(cabinet2$encoded_name),]
cabinet4<-dplyr::select(cabinet3,"name_lower")
missing<-unique(cabinet4)
#write.csv(missing, file="missing.csv", row.names=F)


###Use NamePrism
#Find unique names
names<-as.data.frame(unique(missing[,1]))

#Script to run unique names through NamePrism and return results.
#Warning: only runs if connected to NamePrism API with special permission
#from NamePrism authors and with API key
names_nationality<-as.data.frame(matrix(nrow=nrow(names),ncol=42))
#for(i in 1:nrow(names)){
#  if(i%%1000==0){
#    names_nationality[i,]<-get_nationalities(names[i,1], t="API KEY HERE")
#    write.csv(names_nationality,paste0('names_nationality',i,'.csv'))
#    pause(1)
#  }
#  else{
#  names_nationality[i,]<-get_nationalities(names[i,1], t="API KEY HERE")
#  pause(1)
#  }
#}

#write.csv(names_nationality, file="names_nationality.csv", row.names=F)

names_final<-as.data.frame(cbind(names, names_nationality))
colnames(names_final)<-c('Name', 'input', 'encoded_name', 'url',
                         'European-SouthSlavs', 'Muslim-Pakistanis-Bangladesh',
                         'European-Italian-Italy', 'European-Baltics', 'African-SouthAfrican',
                         'European-Italian-Romania', 'Muslim-Nubian', 'European-French',
                         'EastAsian-Indochina-Thailand', 'EastAsian-Indochina-Vietnam',
                         'Jewish', 'Muslim-Turkic-CentralAsian', 'EastAsian-Indochina-Cambodia',
                         'Nordic-Scandinavian-Denmark', 'EastAsian-Indochina-Myanmar',
                         'Nordic-Finland', 'Muslim-Persian', 'Nordic-Scandinavian-Sweden',
                         'Muslim-Maghreb', 'Greek', 'Muslim-Pakistanis-Pakistan',
                         'Hispanic-Portuguese', 'European-Russian', 'Muslim-ArabianPeninsula',
                         'African-WestAfrican', 'EastAsian-Japan', 'European-German',
                         'EastAsian-Chinese', 'SouthAsian', 'Hispanic-Spanish',
                         'Nordic-Scandinavian-Norway', 'Muslim-Turkic-Turkey',
                         'Hispanic-Philippines', 'CelticEnglish', 'EastAsian-Malay-Malaysia',
                         'EastAsian-South Korea', 'African-EastAfrican', 'European-EastEuropean',
                         'EastAsian-Malay-Indonesia')

names_final$Name<-as.character(names_final$Name)
names_final[,5:43] <- sapply(names_final[,5:43],as.numeric)

#write.csv(names_final, file="names_final.csv", row.names=F)

names_final<-read.csv("names_final.csv", header=T)

new_nameprism<-rbind(old_nameprism, names_final[,-2])
#Remove NA rows
new_namesprism<-new_nameprism[-c(1,1055),]

#Eliminate NA names
cabinet5<-cabinet[!is.na(cabinet$name_lower),]

#Merge for final dataset
cabinet6<-merge(cabinet5, new_nameprism, by.x="name_lower", by.y="Name", all.x=T, all.y=F)
sum(table(cabinet6$European.Italian.Italy))


#Calculate HH index
#Count number of members in cabinet
cabinet6$Size<-1
cabinet7<-cabinet6[,c(3,32,35:74)]

names_aggregate<-aggregate(x=cabinet7[,-c(1:2)], by=cabinet7[c('COWCode', 'year')], FUN='sum', na.rm=TRUE)

#Get the largest percentage assigned to a Name Community for each name
for(i in 1:nrow(names_aggregate)){
  names_aggregate$Max[i]<-max(names_aggregate[i,c(3:41)])/names_aggregate$Size[i]}

#Calculate the ELF for each name
for(i in 1:nrow(names_aggregate)){
  names_aggregate$elf[i]<-1-(sum((names_aggregate[i,c(3:41)]/names_aggregate$Size[i])^2))}

#Export country-year HH index
cabinet_nameprism<-names_aggregate
#write.csv(cabinet_nameprism, file="cabinet_nameprism.csv", row.names=F)









