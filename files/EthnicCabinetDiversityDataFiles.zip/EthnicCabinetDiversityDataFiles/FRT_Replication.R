#######################################################
### Ethnic Diversity in Central Government Cabinets ###
### Francois, Rainer, and Trebbi Replication        ###
### William O'Brochta                               ###
### Washington University in St. Louis              ###
#######################################################


library(foreign)
library(plyr)
library(dplyr)
library(car)
library(DataCombine)
library(plm)
library(sandwich)
library(lmtest)
library(stargazer)

#Create ELF variable
frt<-read.dta('tmp3_FRT.dta')
frt$govshare2<-(frt$govshare)^2
frt2<-frt[,c(1,3,29)]
frt_cntry<-frt %>%
  group_by(country, year_gov) %>%
  summarise(sum(govshare2))
frt_cntry$elf<-1-frt_cntry$`sum(govshare2)`

#Match country codes
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Benin', 434, NA)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Cameroon', 471, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='CongoKinshasa', 490, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=="Cote d'Ivoire", 437, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Gabon', 481, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Ghana', 452, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Guinea', 438, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Kenya', 501, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Liberia', 450, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Nigeria', 475, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Republic of Congo', 484, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Sierra Leone', 451, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Tanzania', 510, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Togo', 461, frt_cntry$COWcode)
frt_cntry$COWcode<-ifelse(frt_cntry$country=='Uganda', 500, frt_cntry$COWcode)
colnames(frt_cntry)<-c('country', 'YEAR', 'sum2', 'frt_elf', 'COWCode')

#Merge datasets
cabinet_prevalent<-read.csv('cabinet_prevalent_reduced2.csv', header=T, stringsAsFactors = F)

frt_cabinet<-merge(frt_cntry, cabinet_prevalent, by=c('COWCode', 'YEAR'), all.x=T, all.y=F)
frt_cabinet2<-frt_cabinet[,c(1:3,5,9,10)]
frt_cabinet3<-frt_cabinet2[complete.cases(frt_cabinet2),]

#Identify outlier problem
frt_cabinet4<-frt_cabinet3[frt_cabinet3$YEAR>1970 & frt_cabinet3$YEAR<2005,]
rownames(frt_cabinet4) <- NULL
plot(frt_cabinet4$frt_elf, frt_cabinet4$cabinet_elf)

#Cut out FRT outliers
frt_cabinet5<-frt_cabinet4[frt_cabinet4$frt_elf>0.67,]

#Figure SI.12.1
model1<-lm(frt_cabinet5$cabinet_elf~frt_cabinet5$frt_elf)
plot(frt_cabinet5$frt_elf, frt_cabinet5$cabinet_elf, xlab="FRT ELF", ylab="Cabinet Diversity", 
     main="Correlation Between Cabinet Diversity and FRT ELF", cex=1.25, cex.lab=1.25, cex.axis=1.25, cex.main=1.25)
abline(model1, lwd=2)

cor(frt_cabinet5$frt_elf, frt_cabinet5$cabinet_elf)
summary(lm(frt_cabinet5$frt_elf~frt_cabinet5$cabinet_elf))

#Run analysis with FRT data
load('cabinet_merge3.RData')

cabinet_merge3 <- slide(cabinet_merge3, Var = "v2x_execorr", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_v2x_execorr")

cabinet_merge4<-merge(frt_cntry, cabinet_merge3, by=c('COWCode', 'YEAR'), all.x=T, all.y=F)

cabinet_merge4 <- slide(cabinet_merge4, Var = "frt_elf", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_frt_elf")

model1<-plm(frt_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge4, index=c('COWCode', 'YEAR'),
                model='within', effect='individual')


coef1<-coeftest(model1, type='HC0', cluster='group', adjust=T)

#Table SI.12.2
stargazer(model1, se=list(coef1[,2]))

source("interaction_plots.R")

#Figure SI.12.3 Panels A and B
interaction_plot_continuous(model1, effect="L_v2x_execorr", moderator="L_school04_log", interaction="L_v2x_execorr:L_school04_log", 
                            mean=T, conf=0.9, xlab='Log School', ylab='Marginal Effect of Non-Programmatic Distribution on Cabinet Diversity',
                            title='Marginal Effects Plot')

interaction_plot_continuous(model1, effect="L_school04_log", moderator="L_v2x_execorr", interaction="L_v2x_execorr:L_school04_log", 
                            mean=T, conf=0.9, xlab='Non-Programmatic Distribution', ylab='Marginal Effect of School on Cabinet Diversity',
                            title='Marginal Effects Plot')




