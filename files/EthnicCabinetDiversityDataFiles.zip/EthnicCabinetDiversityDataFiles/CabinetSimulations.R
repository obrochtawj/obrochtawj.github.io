#######################################################
### Ethnic Diversity in Central Government Cabinets ###
### Substantive Effects Interpretation              ###
### William O'Brochta                               ###
### Washington University in St. Louis              ###
#######################################################


#Mean cabinet size is 28, use 10 total ethnic groups.
elf_function<-function(s=28,x1=0,x2=0,x3=0,x4=0,x5=0,x6=0,x7=0,x8=0,x9=0,x10=0){1-((x1/s)^2+(x2/s)^2+(x3/s)^2+(x4/s)^2+(x5/s)^2+(x6/s)^2+(x7/s)^2+(x8/s)^2+(x9/s)^2+(x10/s)^2)}
elf_function(s=28,x1=2,x2=3,x3=3,x4=3,x5=3,x6=3,x7=3,x8=3,x9=3,x10=3)

elf_data<-as.data.frame(matrix(nrow=100000,ncol=12))
colnames(elf_data)<-c('sample', 'x1', 'x2', 'x3', 'x4', 'x5', 
                      'x6','x7','x8','x9','x10','elf')

#Takes a long time to run
#Set-up a loop to sample a random cabinet with 28 total members from 10 groups
for(i in 1:100000){
x1<-sample(0:28, size=1)
x2<-ifelse(x1!=28, sample(0:(28-x1), size=1), 0)
x3<-ifelse((x1+x2)<29, sample(0:(28-x1-x2), size=1), 0)
x4<-ifelse((x1+x2+x3)<29, sample(0:(28-x1-x2-x3), size=1), 0)
x5<-ifelse((x1+x2+x3+x4)<29, sample(0:(28-x1-x2-x3-x4), size=1), 0)
x6<-ifelse((x1+x2+x3+x4+x5)<29, sample(0:(28-x1-x2-x3-x4-x5), size=1), 0)
x7<-ifelse((x1+x2+x3+x4+x5+x6)<29, sample(0:(28-x1-x2-x3-x4-x5-x6), size=1), 0)
x8<-ifelse((x1+x2+x3+x4+x5+x6+x7)<29, sample(0:(28-x1-x2-x3-x4-x5-x6-x7), size=1), 0)
x9<-ifelse((x1+x2+x3+x4+x5+x6+x7+x8)<29, sample(0:(28-x1-x2-x3-x4-x5-x6-x7-x8), size=1), 0)
x10<-ifelse((x1+x2+x3+x4+x5+x6+x7+x8+x9)<29, sample(0:(28-x1-x2-x3-x4-x5-x6-x7-x8-x9), size=1), 0)
elf_sample<-elf_function(s=28,x1,x2,x3,x4,x5,x6,x7,x8,x9,x10)
elf_data[i,1]<-i
elf_data[i,2]<-x1
elf_data[i,3]<-x2
elf_data[i,4]<-x3
elf_data[i,5]<-x4
elf_data[i,6]<-x5
elf_data[i,7]<-x6
elf_data[i,8]<-x7
elf_data[i,9]<-x8
elf_data[i,10]<-x9
elf_data[i,11]<-x10
elf_data[i,12]<-elf_sample
}


elf_counts<-as.data.frame(matrix(nrow=33,ncol=10))
for(i in 1:33){
low<-seq(0, 0.96, by=0.03)
high<-seq(0.03, 1, by=0.03)
elf_temp<-elf_data[elf_data$elf<high[i] & elf_data$elf>low[i],]
elf_counts[i,1]<-mean(elf_temp$x1)
elf_counts[i,2]<-mean(elf_temp$x2)
elf_counts[i,3]<-mean(elf_temp$x3)
elf_counts[i,4]<-mean(elf_temp$x4)
elf_counts[i,5]<-mean(elf_temp$x5)
elf_counts[i,6]<-mean(elf_temp$x6)
elf_counts[i,7]<-mean(elf_temp$x7)
elf_counts[i,8]<-mean(elf_temp$x8)
elf_counts[i,9]<-mean(elf_temp$x9)
elf_counts[i,10]<-mean(elf_temp$x10)
}

elf_counts2<-elf_counts[c(-1,-2, -4, -6, -8, -31, -32, -33),]
#write.csv(elf_counts2, 'elf_counts3.csv', row.names = F)

###Reading in and plotting
elf_counts2<-read.csv('elf_counts3.csv', header=T, stringsAsFactors = F)
low2<-low[c(-1,-2, -4, -6, -8, -31, -32, -33)]

loess1<-loess(elf_counts2$V1~low2, span=0.5)
smoothed1<-predict(loess1)
loess2<-loess(elf_counts2$V2~low2, span=0.5)
smoothed2<-predict(loess2)
loess3<-loess(elf_counts2$V3~low2, span=0.5)
smoothed3<-predict(loess3)
loess4<-loess(elf_counts2$V4~low2, span=0.5)
smoothed4<-predict(loess4)
loess5<-loess(elf_counts2$V5~low2, span=0.5)
smoothed5<-predict(loess5)
loess6<-loess(elf_counts2$V6~low2, span=0.5)
smoothed6<-predict(loess6)
loess7<-loess(elf_counts2$V7~low2, span=0.5)
smoothed7<-predict(loess7)
loess8<-loess(elf_counts2$V8~low2, span=0.5)
smoothed8<-predict(loess8)
loess9<-loess(elf_counts2$V9~low2, span=0.5)
smoothed9<-predict(loess9)
loess10<-loess(elf_counts2$V10~low2, span=0.5)
smoothed10<-predict(loess10)

#Figure SI.6.1
plot(elf_counts2$V1~low2, ylim=c(0,26), xlim=c(0.06, 0.87), type='n', xlab='Cabinet Diversity', ylab='Number of Cabinet Appointments', 
     main='Cabinet Diversity and Cabinet Appointments', cex.lab=1.3, cex.axis=1.15, cex.main=1.3)
lines(smoothed1, x=low2, col="black", lwd=2)
par(new=T)
plot(elf_counts2$V2~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed2, x=low2, lwd=2, col='grey50')
par(new=T)
plot(elf_counts2$V3~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed3, x=low2, lwd=2, col='grey25')
par(new=T)
plot(elf_counts2$V4~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed4, x=low2, lwd=2, col='grey75')
par(new=T)
plot(elf_counts2$V5~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed5, x=low2, lwd=2)
par(new=T)
plot(elf_counts2$V6~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed6, x=low2, lwd=2, col='grey50')
par(new=T)
plot(elf_counts2$V7~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed7, x=low2, lwd=2, col='grey25')
par(new=T)
plot(elf_counts2$V8~low2, ylim=c(0,26),  xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed8, x=low2, lwd=2, col='grey75')
par(new=T)
plot(elf_counts2$V9~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed9, x=low2, lwd=2)
par(new=T)
plot(elf_counts2$V10~low2, ylim=c(0,26), xlim=c(0.06, 0.87), xlab='', ylab='', axes=F, type='n')
lines(smoothed10, x=low2, lwd=2, col='grey50')
#legend(.65,28.5, c('1', '2', '3', '4', '5'), 
#       col=c('black', 'red', 'blue', 'darkgreen', 'darkorange3'),
#       lty=c(1,2,3,4,5), title='Group', bty='n', lwd=2)


#Illustrate Different Changes
elf_counts3<-cbind(elf_counts2, low2)

#+0.06
colMax <- function(data) sapply(data, max, na.rm = TRUE)
colMin <- function(data) sapply(data, min, na.rm = TRUE)

inc_0.06<-rbind(elf_counts3[2,]-elf_counts3[1,],
elf_counts3[3,]-elf_counts3[2,],
elf_counts3[4,]-elf_counts3[3,],
elf_counts3[6,]-elf_counts3[4,],
elf_counts3[7,]-elf_counts3[5,],
elf_counts3[8,]-elf_counts3[6,],
elf_counts3[9,]-elf_counts3[7,],
elf_counts3[10,]-elf_counts3[8,],
elf_counts3[11,]-elf_counts3[9,],
elf_counts3[12,]-elf_counts3[10,],
elf_counts3[13,]-elf_counts3[11,],
elf_counts3[14,]-elf_counts3[12,],
elf_counts3[15,]-elf_counts3[13,],
elf_counts3[16,]-elf_counts3[14,],
elf_counts3[17,]-elf_counts3[15,],
elf_counts3[18,]-elf_counts3[16,],
elf_counts3[19,]-elf_counts3[17,],
elf_counts3[20,]-elf_counts3[18,],
elf_counts3[21,]-elf_counts3[19,],
elf_counts3[22,]-elf_counts3[20,],
elf_counts3[23,]-elf_counts3[21,],
elf_counts3[24,]-elf_counts3[22,],
elf_counts3[25,]-elf_counts3[23,])

diff<-low2[c(-1,-5)]
inc_0.06<-cbind(inc_0.06, diff)
colMeans(inc_0.06)
colMax(inc_0.06)
colMin(inc_0.06)

loess1.1<-loess(inc_0.06$V1~diff, span=0.5)
smoothed1.1<-predict(loess1.1)
loess2.1<-loess(inc_0.06$V2~diff, span=0.5)
smoothed2.1<-predict(loess2.1)
loess3.1<-loess(inc_0.06$V3~diff, span=0.5)
smoothed3.1<-predict(loess3.1)
loess4.1<-loess(inc_0.06$V4~diff, span=0.5)
smoothed4.1<-predict(loess4.1)
loess5.1<-loess(inc_0.06$V5~diff, span=0.5)
smoothed5.1<-predict(loess5.1)


#Figure SI.13.1 Panel A
plot(inc_0.06$V1~diff, ylim=c(-2,2), type='n', main='Cabinet Diversity Increase 0.06', xlab='Cabinet Diversity', ylab='Seat Change', cex.lab=1.3, cex.axis=1.15, cex.main=1.3)
lines(smoothed1.1, x=diff, lwd=2)
lines(smoothed2.1, x=diff, lwd=2, lty=2, col='red')
lines(smoothed3.1, x=diff, lwd=2, lty=3, col='blue')
lines(smoothed4.1, x=diff, lwd=2, lty=4, col='darkgreen')
lines(smoothed5.1, x=diff, lwd=2, lty=6, col='purple')
legend(0.1,2.4, c('1', '4', '2', '5', '3'), 
       col=c('black', 'darkgreen', 'red', 'purple', 'blue'),
       lty=c(1,2,3,4,5), bty='n', lwd=2, ncol=3)


#Figure SI.13.1 Panel B

inc_0.21<-rbind(elf_counts3[5,]-elf_counts3[1,],
elf_counts3[7,]-elf_counts3[2,],
elf_counts3[9,]-elf_counts3[3,],
elf_counts3[11,]-elf_counts3[4,],
elf_counts3[12,]-elf_counts3[5,],
elf_counts3[13,]-elf_counts3[6,],
elf_counts3[14,]-elf_counts3[7,],
elf_counts3[15,]-elf_counts3[8,],
elf_counts3[16,]-elf_counts3[9,],
elf_counts3[17,]-elf_counts3[10,],
elf_counts3[18,]-elf_counts3[11,],
elf_counts3[19,]-elf_counts3[12,],
elf_counts3[20,]-elf_counts3[13,],
elf_counts3[21,]-elf_counts3[14,],
elf_counts3[22,]-elf_counts3[15,],
elf_counts3[23,]-elf_counts3[16,],
elf_counts3[24,]-elf_counts3[17,],
elf_counts3[25,]-elf_counts3[18,])
colMeans(inc_0.21)
colMax(inc_0.21)
colMin(inc_0.21)

 
diff2<-low2[c(-1,-2,-3,-4,-6,-8,-10)]
inc_0.21<-cbind(inc_0.21, diff2)

loess1.2<-loess(inc_0.21$V1~diff2, span=0.5)
smoothed1.2<-predict(loess1.2)
loess2.2<-loess(inc_0.21$V2~diff2, span=0.5)
smoothed2.2<-predict(loess2.2)
loess3.2<-loess(inc_0.21$V3~diff2, span=0.5)
smoothed3.2<-predict(loess3.2)
loess4.2<-loess(inc_0.21$V4~diff2, span=0.5)
smoothed4.2<-predict(loess4.2)
loess5.2<-loess(inc_0.21$V5~diff2, span=0.5)
smoothed5.2<-predict(loess5.2)



plot(inc_0.21$V1~diff2, ylim=c(-7,6), type='n', main='Cabinet Diversity Increase 0.21', xlab='Cabinet Diversity', ylab='Seat Change', cex.lab=1.3, cex.axis=1.15, cex.main=1.3)
lines(smoothed1.2, x=diff2, lwd=2)
lines(smoothed2.2, x=diff2, lwd=2, lty=2, col='red')
lines(smoothed3.2, x=diff2, lwd=2, lty=3, col='blue')
lines(smoothed4.2, x=diff2, lwd=2, lty=4, col='darkgreen')
lines(smoothed5.2, x=diff2, lwd=2, lty=6, col='purple')


