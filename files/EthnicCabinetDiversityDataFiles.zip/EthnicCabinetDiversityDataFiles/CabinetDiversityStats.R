#######################################################
### Ethnic Diversity in Central Government Cabinets ###
### Cabinet Diversity Dataset Construction          ###
### William O'Brochta                               ###
### Washington University in St. Louis              ###
#######################################################



cabinet_all<-read.csv('cabinet_prevalent_panel.csv', header=T, stringsAsFactors = F)

#Main text Figure 1 panel B
plot(density(cabinet_all[cabinet_all$YEAR==1967,]$cabinet_elf), xlim=c(0,1), ylim=c(0,1.75), xlab='Cabinet Diversity', main='Cabinet Diversity Density Over Time', 
     cex.lab=1.5, cex.axis=1.5, cex.main=1.5, lwd=3)
abline(v=mean(cabinet_all[cabinet_all$YEAR==1967,]$cabinet_elf), lwd=3)
par(new=T)
plot(density(cabinet_all[cabinet_all$YEAR==2017,]$cabinet_elf), xlim=c(0,1), ylim=c(0,1.75), axes=F, xlab='', ylab='', col='red', lty=2, main='', lwd=3)
abline(v=mean(cabinet_all[cabinet_all$YEAR==2017,]$cabinet_elf), col='red', lty=2, lwd=3)
legend(-.05,1.93,c('1967', '2017'), col=c('black', 'red'), lty=c(1,2), bty='n', cex=1.5, lwd=3)



#Figure SI.7.3
#num_states: UN recognized number of countries by year
num_states<-c(123, 126, 127, 132, 135, 138, 144, 147, 149, 
  151, 152, 154, 157, 157, 158, 159,
  159,159,159,159,159,159,166,179,184,185,185,
  185,185,185,188,189,189,191,191,191,191,192,
  192,192,192,192,193,193,193,193,193,193,193)
cabinet_year<-as.data.frame(cbind(cabinet_year, num_states))
cabinet_year$size_state<-cabinet_year$Size/cabinet_year$num_states

loess1<-loess(size_state~YEAR, cabinet_year, span=0.15)
smoothed1<-predict(loess1)
plot(size_state~YEAR, cabinet_year, xlab='Year', ylab='Cabinet Size', main='Cabinet Size Over Time', cex.lab=1.5, cex.axis=1.5, cex.main=1.5, lwd=3)
lines(smoothed1, x=cabinet_year$YEAR, col="red", lwd=3)


#Overall highest ethnicities
ethnicity_means<-as.data.frame(colMeans(cabinet_year))
ethnicity_time<-as.data.frame(t(cabinet_year[49,]-cabinet_year[1,]))
ethnicity_change<-as.data.frame(cbind(ethnicity_means, ethnicity_time, t(cabinet_year[1,]), t(cabinet_year[49,])))
colnames(ethnicity_change)<-c('Avg', 'Time _Change', 'In1967', 'In2017')
ethnicity_change<-ethnicity_change[c(2:40),]
ethnicity_change<-cbind(rownames(ethnicity_change),ethnicity_change)
ethnicity_change<-ethnicity_change[order(ethnicity_change$`rownames(ethnicity_change)`),]


library(countrycode)
prevalent<-read.csv('prevalent.csv', header = T, stringsAsFactors = F)
wb<-read.csv('wb.csv', header = T, stringsAsFactors = F)
wb2<-as.data.frame(cbind(wb, countrycode(wb$Country.Code, "wb", 'cown')))
colnames(wb2)<-c('cntry', 'X1967', 'X2016', 'CCode')
wb3<-merge(prevalent,wb2, by.x='CCode', by.y='CCode')
wb4<-aggregate(wb3[,4:5], by=list(wb3$Prevalent_Ethnicity), sum, na.rm=T)

ethnicity_change2<-as.data.frame(cbind(ethnicity_change,wb4))
ethnicity_change2$pct1967<-ethnicity_change2$X1967/sum(ethnicity_change2$X1967)
ethnicity_change2$pct2016<-ethnicity_change2$X2016/sum(ethnicity_change2$X2016)

cor(ethnicity_change2$In1967,ethnicity_change2$pct1967)
plot(ethnicity_change2$In1967~ethnicity_change2$pct1967, xlim=c(0,0.25), ylim=c(0,0.25))
abline(0,1)
summary(lm(ethnicity_change2$In1967~ethnicity_change2$pct1967))

cor(ethnicity_change2$In2017,ethnicity_change2$pct2016)
par(new=T)
plot(ethnicity_change2$In2017~ethnicity_change2$pct2016, col='red', pch=18, xlim=c(0,0.25), ylim=c(0,0.25))
summary(lm(ethnicity_change2$In2017~ethnicity_change2$pct2016))


#Summing over Stem nationalities
ethnicity_change3<-ethnicity_change2[,c(2,3,4,5,7,8,9,10)]


stem_nationalities<-rbind(colSums(ethnicity_change3[c(1:3),]),
                           colSums(ethnicity_change3[c(4),]),
                           colSums(ethnicity_change3[c(5:13),]),
                           colSums(ethnicity_change3[c(14:21),]),
                           colSums(ethnicity_change3[c(22),]),
                           colSums(ethnicity_change3[c(23:25),]),
                           colSums(ethnicity_change3[c(26),]),
                           colSums(ethnicity_change3[c(27:34),]),
                           colSums(ethnicity_change3[c(35:38),]),
                           colSums(ethnicity_change3[c(39),]))

stem_names<-c('African','CelticEnglish','EastAsian','European','Greek','Hispanic',
              'Jewish','Muslim','Nordic','SouthAsian')

stem_nationalities<-as.data.frame(cbind(stem_names,stem_nationalities))
stem_nationalities$Avg<-as.numeric(as.character(stem_nationalities$Avg))
stem_nationalities$`Time _Change`<-as.numeric(as.character(stem_nationalities$`Time _Change`))
stem_nationalities$In1967<-as.numeric(as.character(stem_nationalities$In1967))
stem_nationalities$In2017<-as.numeric(as.character(stem_nationalities$In2017))
stem_nationalities$X1967<-as.numeric(as.character(stem_nationalities$X1967))
stem_nationalities$X2016<-as.numeric(as.character(stem_nationalities$X2016))
stem_nationalities$pct1967<-as.numeric(as.character(stem_nationalities$pct1967))
stem_nationalities$pct2016<-as.numeric(as.character(stem_nationalities$pct2016))

cor(stem_nationalities$In1967,stem_nationalities$pct1967)
summary(lm(stem_nationalities$In1967~stem_nationalities$pct1967))

cor(stem_nationalities$In2017,stem_nationalities$pct2016)
summary(lm(stem_nationalities$In2017~stem_nationalities$pct2016))

#Figure SI.7.4
plot(stem_nationalities$In1967~stem_nationalities$pct1967, xlim=c(0,.4), ylim=c(0,.4),
     xlab='Pct. of World Population', ylab='Pct. of World Cabinets', main='Cabinet Composition and Population', cex.lab=1.3, cex.axis=1.15, cex.main=1.3)
abline(coef=c(0,1))
with(stem_nationalities, 
     text(In1967~pct1967, 
          labels = c('Afr', 'Eng', 'EAsian', 'Eur', 'Grk', 'His', 'Jewish', 'Mus', 'Nordic', 'SAsian'), 
          pos = 4, cex=.9))
par(new=T)
plot(stem_nationalities$In2017~stem_nationalities$pct2016, 
     xlim=c(0,.4), ylim=c(0,.4), col='red', pch=18, xlab='', ylab='', main='', axes=F)
#abline(coef=c(0,1))
with(stem_nationalities, 
     text(In2017~pct2016,
          labels = c('Afr', 'Eng', 'EAsian', 'Eur', 'Grk', 'His', 'Jewish', 'Mus', 'Nordic', 'SAsian'), 
          pos = 4, cex=.9))
legend(.27,.415, c('1967', '2017'), col=c('black', 'red'), pch=c(1,18), box.lwd = 0,box.col = "white",bg = "white", cex=1)



#Main text Figure 1 panel A
cabinet_all$counter<-1
cabinet_all3<-cabinet_all[,c('YEAR','cabinet_elf', 'counter')]
cabinet_year2<-aggregate(cabinet_all3, by=list(cabinet_all3$YEAR), FUN=sum)
cabinet_year2<-cabinet_year2[,c(1, 3:4)]
colnames(cabinet_year2)[colnames(cabinet_year2) == "Group.1"] <- "YEAR"
cabinet_year2$elf_year<-cabinet_year2$cabinet_elf/cabinet_year2$counter

loess2<-loess(elf_year~YEAR, cabinet_year2, span=0.15)
smoothed2<-predict(loess2)
plot(elf_year~YEAR, cabinet_year2, ylim=c(0.5,0.65), xlab='Year', ylab='Cabinet Diversity', main='Cabinet Diversity Over Time', cex.lab=1.5, cex.axis=1.5, cex.main=1.5, lwd=3)
lines(smoothed2, x=cabinet_year2$YEAR, col="red", lwd=3)

