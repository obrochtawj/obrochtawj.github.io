##################################################################
### Ethnic Diversity in Central Government Cabinets            ###
### Correlation Between Secondary School and Baldwin and Huber ###
### William O'Brochta                                          ###
### Washington University in St. Louis                         ###
##################################################################



library(profvis)
library(nomine)
library(sandwich)
library(lmtest)
library(MASS)
library(car)
library(prais)
library(panelAR)
library(orcutt)
library(countrycode)
library(plm)
library(plyr)
library(dplyr)
library(interplot)
library(lfe)
library(betareg)
library(Hmisc)
library(margins)
library(DataCombine)
library(dynsim)
library(clusterSEs)
library(multiwayvcov)
library(dynpanel)
library(lmerTest)
library(stargazer)
library(xtable)
library(foreign)

load('cabinet_merge3.RData')

cabinet_merge3 <- slide(cabinet_merge3, Var = "v2x_execorr", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_v2x_execorr")

#WDI averaged across 1996-2006
wdi<-read.dta("baldwinHuber.dta")
wdi<-wdi[1:46,]
wdi$COWCode<-c(900, 771, 211, 434, 571, 140, 355, 20, 100, 316, 42, 
               366, 375, 220, 372, 255, 310, 750, 850, 205, 501, 
               367, 368, 343, 580, 553, 432, 70, 359, 541, 565, 210, 
               920, 475, 360, 365, 433, 349, 560, 230, 225, 2, 369, 165, 101, 551)
wdi2<-wdi[,c(3,44)]


cabinet_merge4<-merge(cabinet_merge3, wdi2, by=c('COWCode'))
cabinet_merge5<-cabinet_merge4[cabinet_merge4$YEAR==1997,]
plot(cabinet_merge5$L_school04_log~cabinet_merge5$pg)

cabinet_merge6<-as.data.frame(cbind(cabinet_merge5$L_school04_log, cabinet_merge5$pg))
cabinet_merge6<-cabinet_merge6[complete.cases(cabinet_merge6),]
colnames(cabinet_merge6)<-c("L_school04_log", "pg")
cor(cabinet_merge6$L_school04_log, cabinet_merge6$pg)

#Average of seconardy school values from 1997 to 2007
cabinet_merge7<-cabinet_merge4[cabinet_merge4$YEAR>1996,]
cabinet_merge7<-cabinet_merge7[cabinet_merge7$YEAR<2008,]
cabinet_merge8<-as.data.frame(cbind(cabinet_merge7$COWCode, cabinet_merge7$L_school04_log))
colnames(cabinet_merge8)<-c('COWCode', 'L_school04_log')
cabinet_merge9<-as.data.frame(cabinet_merge8 %>%
  group_by(COWCode) %>%
  summarise_all(mean))
cabinet_merge10<-merge(cabinet_merge9, wdi2, by=c('COWCode'))
cabinet_merge10<-cabinet_merge10[-14,]
cor(cabinet_merge10$L_school04_log, cabinet_merge10$pg)
plot(cabinet_merge10$L_school04_log~cabinet_merge10$pg)


