#######################################################
### Ethnic Diversity in Central Government Cabinets ###
### Main Models                                     ###
### William O'Brochta                               ###
### Washington University in St. Louis              ###
#######################################################

library(profvis)
library(nomine)
library(sandwich)
library(lmtest)
library(MASS)
library(car)
library(prais)
library(panelAR)
library(orcutt)
library(countrycode)
library(plm)
library(plyr)
library(dplyr)
library(interplot)
library(lfe)
library(betareg)
library(Hmisc)
library(margins)
library(DataCombine)
library(dynsim)
library(clusterSEs)
library(multiwayvcov)
library(dynpanel)
library(lmerTest)
library(stargazer)
library(xtable)


#Additional Data Prep
cabinet_prevalent<-read.csv('cabinet_prevalent_reduced2.csv', header=T, stringsAsFactors = F)
cabinet_prevalent$L_domestic9l<-ifelse(cabinet_prevalent$L_domestic9==0,0,log(cabinet_prevalent$L_domestic9))
cabinet_prevalent$L_military1l<-ifelse(cabinet_prevalent$L_military1==0,0,log(cabinet_prevalent$L_military1))
cabinet_prevalent$L_military1pop<-ifelse(cabinet_prevalent$L_military1==0,0,cabinet_prevalent$L_military1l/cabinet_prevalent$lpopl)


cabinet_prevalent <- slide(cabinet_prevalent, Var = "cabinet_elf", GroupVar = "COWCode",
                           TimeVar = "YEAR", NewVar = "L_cabinet_elf")
cabinet_merge<-merge(cabinet_prevalent, vdem, by.x=c('COWCode', 'YEAR'), by.y=c('COWcode', 'year'), all.x=T)

cnts<-read.csv('2016 Edition CNTSDATA.csv', header=T, stringsAsFactors = F)
cnts$cow_code<-countrycode(cnts$Wbcode, 'wb', 'cown')
cabinet_merge2<-merge(cabinet_merge, cnts, by.x=c('COWCode', 'YEAR'), by.y=c('cow_code', 'year'), all.x=T)

gtd<-read.csv('globalterrorismdb_0616dist.csv', header=T, stringsAsFactors = F)
gtd$count<-1
gtd_year<-gtd %>%
  group_by(iyear, country) %>%
  summarise(count=sum(count))
cow_gtd<-read.csv('cow_gtd.csv', header=T, stringsAsFactors = F)
gtd_merge<-merge(gtd_year, cow_gtd, by.x='country', by.y='gtd_code', all.x=T)

cabinet_merge3<-merge(cabinet_merge2, gtd_merge, by.x=c('COWCode', 'YEAR'), by.y=c('CCode', 'iyear'), all.x=T)
cabinet_merge3$count<-ifelse(cabinet_merge3$YEAR>1970 & is.na(cabinet_merge3$count), 0, cabinet_merge3$count)
cabinet_merge3<-subset(cabinet_merge3, select=-c(country.x))

cabinet_merge3 <- slide(cabinet_merge3, Var = "count", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_count")
cabinet_merge3$L_count01<-ifelse(cabinet_merge3$L_count>0, 1, 0)


cabinet_merge3$coalition<-ifelse(cabinet_merge3$legis05==0 | cabinet_merge3$legis05==3 | cabinet_merge3$legis05==1, 0, 1)
cabinet_merge3 <- slide(cabinet_merge3, Var = "coalition", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_coalition")

cabinet_merge3 <- slide(cabinet_merge3, Var = "e_migdppcln", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_e_migdppcln")

cabinet_merge3 <- slide(cabinet_merge3, Var = "v2fsuffrage", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_v2fsuffrage")

cabinet_merge3 <- slide(cabinet_merge3, Var = "legis07", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_legis07")

cabinet_merge3 <- slide(cabinet_merge3, Var = "polit03", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_polit03")

cabinet_merge3 <- slide(cabinet_merge3, Var = "v2x_pubcorr", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_v2x_pubcorr")

cabinet_merge3$factional<-ifelse(cabinet_merge3$e_parcomp==3, 1, 0)

cabinet_merge3 <- slide(cabinet_merge3, Var = "factional", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_factional")

cabinet_merge3 <- slide(cabinet_merge3, Var = "school04", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_school04")

cabinet_merge3$war01<-ifelse(cabinet_merge3$npeaceyears!=0, 1, 0)

cabinet_merge3 <- slide(cabinet_merge3, Var = "war01", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_war01")

cabinet_merge3$L_count_log<-log(cabinet_merge3$L_count+1)
cabinet_merge3$npeaceyears_log<-log(cabinet_merge3$npeaceyears+1)
cabinet_merge3$L_school04_log<-log(cabinet_merge3$L_school04)
cabinet_merge3$L_legis07_log<-log(cabinet_merge3$L_legis07+1)
#save(cabinet_merge3, file='cabinet_merge3.RData')


### Analysis
load('cabinet_merge3.RData')

cabinet_merge3 <- slide(cabinet_merge3, Var = "v2x_execorr", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_v2x_execorr")

#Table 1 in main text; full model in Table SI.10.2
model1.6.1<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                model='within', effect='individual')

summary(model1.6.1)
coeftest(model1.6.1, type='HC0', cluster='group', adjust=T)


#Figure 2 in main text
source("interaction_plots.R")
par(mar=c(5.1, 4.3, 4.1, 2.1))
interaction_plot_continuous(model1.6.1, effect="L_v2x_execorr", moderator="L_school04_log", interaction="L_v2x_execorr:L_school04_log", 
                            mean=T, conf=0.95, xlab='Log School', ylab='Marginal Effect of Non-Programmatic Distribution',
                            title='Marginal Effects Plot')

#Figure SI.10.1
interaction_plot_continuous(model1.6.1, effect="L_school04_log", moderator="L_v2x_execorr", interaction="L_v2x_execorr:L_school04_log", 
                            mean=T, conf=0.9, xlab='Non-Programmatic Distribution', ylab='Marginal Effect of School on Cabinet Diversity',
                            title='Marginal Effects Plot')

#Robustness Checks
model1.6<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size, 
              data=cabinet_merge3, index=c('COWCode', 'YEAR'),
              model='pooling')


model1.region<-lm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                    L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                    L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                    L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+un_region_name, 
                  data=cabinet_merge3)
model1.orcutt<-cochrane.orcutt(model1.region)
summary(model1.orcutt)

model1.6.3<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size, 
                data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                model='within', effect='twoways')

model1.6.1l<-plm(cabinet_elf~L_cabinet_elf+L_elf+L_v2x_execorr+L_school04_log+
                   L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                   L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                   L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                 , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                 model='within', effect='individual')

model1.6.3l<-plm(cabinet_elf~L_cabinet_elf+L_elf+L_v2x_execorr+L_school04_log+
                   L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                   L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                   L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size, 
                 data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                 model='within', effect='twoways')

model1.6.4<-plm(cabinet_elf~+L_cabinet_elf+L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                model='pooling')

model1.6.5<-lmerTest::lmer(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                              L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                              L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                              L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+L_Year+(1|COWCode),
                            data=cabinet_merge3)
summary(model1.6.5)
#Authors say to use confint
confint(model1.6.5, method='Wald')

coef1<-coeftest(model1.6, type='HC0', cluster='group', adjust=T)
coef2<-coeftest(model1.6.1, type='HC0', cluster='group', adjust=T)
coef2l<-coeftest(model1.6.1l, type='HC0', cluster='group', adjust=T)
coef3<-coeftest(model1.6.3, type='HC0', cluster='group', adjust=T)
coef3l<-coeftest(model1.6.3l, type='HC0', cluster='group', adjust=T)
coef4<-coeftest(model1.6.4, type='HC0', cluster='group', adjust=T)
coef5<-as.data.frame(summary(model1.6.5)$coefficients)[,2]


#Table 1 in main text
stargazer(model1.6.1, se=list(coef2[,2]))

#Table SI.10.3
class(model1.6.5) <- "lmerMod"
stargazer(model1.6, model1.orcutt, model1.6.3, model1.6.1l, model1.6.3l, model1.6.4, model1.6.5,
          se=list(coef1[,2], model1.orcutt$std.error, coef3[,2], coef2l[,2], coef3l[,2], coef4[,2], coef5))

###Robustness to Different Measures
#With cabinet_diverse (penalty can range up to 2 and not change results)
model1.5<-lm(cabinet_diverse~L_elf+L_v2x_execorr+L_school04_log+
               L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
               L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
               L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+un_region_name, 
             data=cabinet_merge3)
model1.5.1<-cochrane.orcutt(model1.5)
summary(model1.5.1)

cabinet_merge3 <- slide(cabinet_merge3, Var = "cabinet_diverse", GroupVar = "COWCode",
                           TimeVar = "YEAR", NewVar = "L_cabinet_diverse")

model1.5.2<-plm(cabinet_diverse~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                model='within', effect='individual')
coef5.2<-coeftest(model1.5.2, type='HC0', cluster='group', adjust=T)

model1.5.2l<-plm(cabinet_diverse~L_cabinet_diverse+L_elf+L_v2x_execorr+L_school04_log+
                   L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                   L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                   L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                 , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                 model='within', effect='individual')
coef5.2l<-coeftest(model1.5.2l, type='HC0', cluster='group', adjust=T)

#Table SI.11.1
stargazer(model1.5.1, model1.5.2, model1.5.2l, 
          se=list(model1.5.1$std.error, coef5.2[,2], coef5.2l[,2]))



### Verify with Alesina and Annett measures

Alesina<-read.csv('2003_fractionalization.csv', header=T, stringsAsFactors = F)
cabinet_merge4<-merge(cabinet_merge3, Alesina, by.x=c('YEAR', 'COWCode'), by.y=c('Year', 'COWCode'), all.x=T, all.y=F)
cabinet_merge4 <- ddply(cabinet_merge4, .(country.x), transform, L_Alesina =
                              c(NA, Alesina[-length(Alesina)]
                              ))
plot(L_Alesina~L_elf, data=cabinet_merge4)

#High correlation of 0.71
Alesina2<-cbind(cabinet_merge4$L_Alesina,cabinet_merge4$L_elf)
Alesina2<-as.data.frame(Alesina2[complete.cases(Alesina2),])
cor(Alesina2$V1, Alesina2$V2)

model1.8<-lm(cabinet_elf~L_Alesina+L_v2x_execorr+L_school04_log+
               L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
               L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
               L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+un_region_name, 
             data=cabinet_merge4)
coef8<-coeftest(model1.8, type='HC0', cluster='group', adjust=T)


model1.8.1<-lm(cabinet_elf~L_Alesina+L_v2x_execorr+L_school04_log+
                 L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                 L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                 L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
               +un_region_name, data=cabinet_merge4)
model1.8.1.orcutt<-cochrane.orcutt(model1.8.1)
summary(model1.8.1.orcutt)


Annett<-read.csv('Annett.csv', header=T, stringsAsFactors = F)
cabinet_merge5<-merge(cabinet_merge4, Annett, by.x=c('YEAR', 'COWCode'), by.y=c('YEAR', 'COWCode'), all.x=T, all.y=F)
cabinet_merge5 <- ddply(cabinet_merge5, .(country.x), transform, L_Annett =
                              c(NA, Annett[-length(Annett)]
                              ))

model1.9<-lm(cabinet_elf~L_Annett+L_v2x_execorr+L_school04_log+
               L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
               L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
               L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+un_region_name, 
             data=cabinet_merge5)
coef9<-coeftest(model1.9, type='HC0', cluster='group', adjust=T)

#Correlation of 0.74
Annett2<-cbind(cabinet_merge5$L_Annett,cabinet_merge5$L_elf)
Annett2<-as.data.frame(Annett2[complete.cases(Annett2),])
cor(Annett2$V1, Annett2$V2)
plot(L_Annett~L_elf, data=cabinet_merge5)

#Table SI.11.2
stargazer(model1.8.1.orcutt, model1.8, model1.9, 
          se=list(model1.8.1.orcutt$std.error, coef8[,2], coef9[,2]))


### Verify Francois, Rainer, and Trebbi
attach(cabinet_merge3)
cabinet_merge3$FRT<-ifelse(COWCode=='434' | COWCode=='471' | COWCode=='490' | COWCode=='437' |
                                COWCode=='481' | COWCode=='452' | COWCode=='438' | COWCode=='501' |
                                COWCode=='450' | COWCode=='475' | COWCode=='484' | COWCode=='451' |
                                COWCode=='510' | COWCode=='461' | COWCode=='500', 1, 0)
detach(cabinet_merge3)
cabinet_prevalent_FRT<-cabinet_merge3[cabinet_merge3$FRT==1,]

model1.7<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size, 
              data=cabinet_prevalent_FRT, index=c('COWCode', 'YEAR'),
              model='pooling')

model1.7.1<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_prevalent_FRT, index=c('COWCode', 'YEAR'),
                model='within', effect='individual')

model1.7.1l<-plm(cabinet_elf~L_cabinet_elf+L_elf+L_v2x_execorr+L_school04_log+
                   L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                   L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                   L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                 , data=cabinet_prevalent_FRT, index=c('COWCode', 'YEAR'),
                 model='within', effect='individual')

coef7.1<-coeftest(model1.7.1, type='HC0', cluster='group', adjust=T)
coef7.1l<-coeftest(model1.7.1l, type='HC0', cluster='group', adjust=T)

#Table SI.12.1
stargazer(model1.7.1, model1.7.1l, se=list(coef7.1[,2], coef7.1l[,2]))

#Figure SI.12.2 panels A and B
interaction_plot_continuous(model1.7.1, effect="L_v2x_execorr", moderator="L_school04_log", interaction="L_v2x_execorr:L_school04_log", 
                            mean=T, conf=0.9, xlab='Log School', ylab='Marginal Effect of Non-Programmatic Distribution on Cabinet Diversity',
                            title='Marginal Effects Plot')

interaction_plot_continuous(model1.7.1, effect="L_school04_log", moderator="L_v2x_execorr", interaction="L_v2x_execorr:L_school04_log", 
                            mean=T, conf=0.9, xlab='Non-Programmatic Distribution', ylab='Marginal Effect of School on Cabinet Diversity',
                            title='Marginal Effects Plot')

#Histogram showing range of changes over time
country_var<-as.data.frame(cbind(cabinet_merge3$COWCode, cabinet_merge3$cabinet_elf))
colnames(country_var)<-c('COWCode', 'cabinet_elf')
country_var2<-country_var %>%
  group_by(COWCode) %>%
  summarise(diff=min(cabinet_elf))
country_var3<-country_var %>%
  group_by(COWCode) %>%
  summarise(diff=max(cabinet_elf))
country_var4<-as.data.frame(cbind(country_var2$COWCode, country_var2$diff, country_var3$diff))
colnames(country_var4)<-c('COWCode', 'min', 'max')
country_var4$range<-country_var4$max-country_var4$min
country_var4$name<-countrycode(country_var4$COWCode, 'cown', 'country.name')

#Figure SI.7.1
hist(country_var4$range, main='Range of Cabinet Diversity By Country', xlab='Max-Min Cabinet Diversity',
     ylab='Number of Countries', cex.lab=1.3, cex.axis=1.15, cex.main=1.3)


country_var<-cabinet_merge3[cabinet_merge3$YEAR=='1967',]
country_var2<-as.data.frame(cbind(country_var$COWCode, country_var$cabinet_elf))
country_var3<-cabinet_merge3[cabinet_merge3$YEAR=='2017',]
country_var4<-as.data.frame(cbind(country_var3$COWCode, country_var3$cabinet_elf))
country_var5<-merge(country_var2, country_var4, by="V1")
country_var5$increase<-country_var5[,3]-country_var5[,2]

#Figure SI.7.2
hist(country_var5$increase, main='Change in Cabinet Diversity By Country', xlab='2017-1967 Cabinet Diversity',
     ylab='Number of Countries', cex.lab=1.3, cex.axis=1.15, cex.main=1.3)



#Load QOG data from 2014, merge with cabinet data from 2015 with lagged corruption.
#Correlations between corruption measures in main text
library(foreign)
qog<-read.dta('qog_std_cs_jan18.dta')
cabinet_merge6<-cabinet_merge3[cabinet_merge3$YEAR=='2015',]
cabinet_merge7<-merge(cabinet_merge6,qog, by.x=c('COWCode'), by.y=c('ccodecow'))

cor(cabinet_merge7$vdem_exbribe, cabinet_merge7$L_v2x_execorr, use='pairwise.complete.obs')
cor(cabinet_merge7$vdem_excrptps, cabinet_merge7$L_v2x_execorr, use='pairwise.complete.obs')
cor(cabinet_merge7$vdem_exembez, cabinet_merge7$L_v2x_execorr, use='pairwise.complete.obs')
cor(cabinet_merge7$ti_cpi, cabinet_merge7$L_v2x_execorr, use='pairwise.complete.obs')
cor(cabinet_merge7$wjp_exec_br, cabinet_merge7$L_v2x_execorr, use='pairwise.complete.obs')

#Table SI.10.1
#Descriptive statistics of main model
model1.6.1<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                model='within', effect='individual')

attach(cabinet_merge3)
data_summary<-as.data.frame(cbind(cabinet_elf, L_elf, L_v2x_execorr, L_school04_log,
                      lpopl,npeaceyears_log, L_count_log,
                      L_legis02l, L_polit03, L_gpro, coalition,
                      L_factional, L_legis07_log, 
                      L_e_migdppcln, L_polity, L_Size))
detach(cabinet_merge3)
data_summary2<-as.data.frame(matrix(nrow=16, ncol=5))
for(i in 1:16){
data_summary2[i,1]<-min(data_summary[,i], na.rm=T)
data_summary2[i,2]<-max(data_summary[,i], na.rm=T)
data_summary2[i,3]<-sqrt(var(data_summary[,i], na.rm=T))
data_summary2[i,4]<-mean(data_summary[,i], na.rm=T)
data_summary2[i,5]<-median(data_summary[,i], na.rm=T)
}
print(xtable(data_summary2, type='latex'), file='summary.tex')


#Correlation between programmatic distribution and school
#Basic correlation
prog_school<-as.data.frame(cbind(cabinet_merge3$L_v2x_execorr, cabinet_merge3$L_school04_log))
prog_school<-prog_school[complete.cases(prog_school),]
cor(prog_school$V1,prog_school$V2)

#Correlation with lower school enrollment
prog_school2<-prog_school
prog_school2<-prog_school[prog_school$V2<5,]
cor(prog_school2$V1,prog_school2$V2)
plot(prog_school2$V2~prog_school2$V1)
prog_school_mod<-lm(prog_school2$V2~prog_school2$V1)
summary(prog_school_mod)

#Overall significant positive relationship when accounting for fixed effects 
#(non-programmatic distribution means more school)
plot(cabinet_merge3$L_v2x_execorr, cabinet_merge3$L_school04_log)
prog_school_mod2<-plm(L_school04_log~L_v2x_execorr
                      , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                      model='within', effect='individual')
summary(prog_school_mod2)

#Identify countries with low corruption and low school
prog_school3<-as.data.frame(cbind(cabinet_merge3$country.x, cabinet_merge3$YEAR, cabinet_merge3$L_v2x_execorr, cabinet_merge3$L_school04_log))
colnames(prog_school3)<-c('country.x', 'YEAR', 'L_v2x_execorr', 'L_school04_log')
prog_school3$L_v2x_execorr<-as.numeric(as.character(prog_school3$L_v2x_execorr))
prog_school3$L_school04_log<-as.numeric(as.character(prog_school3$L_school04_log))

prog_school4<-prog_school3[prog_school3$L_v2x_execorr<0.5,]
prog_school5<-prog_school4[prog_school4$L_school04_log<6.3,]
prog_school5<-prog_school5[rowSums(is.na(prog_school5)) == 0,]
table(prog_school5$YEAR)
#Less of a problem since data in main model drops after 2003

#Countries with high corruption and high school
prog_school6<-prog_school3[prog_school3$L_v2x_execorr>0.5,]
prog_school7<-prog_school6[prog_school6$L_school04_log>6.3,]
prog_school7<-prog_school7[rowSums(is.na(prog_school7)) == 0,]
table(prog_school7$YEAR)
#these countries emerge as time goes on

#Span of included data only runs until 2003 due to variables dropping out
prog_school_mod3<-lm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                       L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                       L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                       L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+YEAR
                     , data=cabinet_merge3)
prog_school_mod4<-prog_school_mod3$model
table(prog_school_mod4$YEAR)



####Additional robustness checks

#Adding in politiczation of ethnicity variables
#New variables: v2pepwrsoc: power distributed equally among social groups 0 monopolized by one group, 
#4 no social divisions of power

cabinet_merge3 <- slide(cabinet_merge3, Var = "v2pepwrsoc_ord", GroupVar = "COWCode",
                        TimeVar = "YEAR", NewVar = "L_v2pepwrsoc")

boxplot(elf~v2pepwrsoc_ord, data=cabinet_merge3)
table(cabinet_merge3$v2pepwrsoc_ord)
cabinet_merge3$L_v2pepwrsoc01<-ifelse(cabinet_merge3$L_v2pepwrsoc==4,1,0)


model3<-plm(cabinet_elf~L_elf*L_factional+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
                model='within', effect='individual')

summary(model3)
coef3<-coeftest(model3, type='HC0', cluster='group', adjust=T)

model3.1<-plm(cabinet_elf~L_elf*L_v2pepwrsoc+L_v2x_execorr+L_school04_log+
              L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
              L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
              L_legis07_log+L_e_migdppcln+L_polity+L_Size
            , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
            model='within', effect='individual')

summary(model3.1)
coef3.1<-coeftest(model3.1, type='HC0', cluster='group', adjust=T)

model3.2<-plm(cabinet_elf~L_elf*L_v2pepwrsoc01+L_v2x_execorr+L_school04_log+
              L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
              L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
              L_legis07_log+L_e_migdppcln+L_polity+L_Size
            , data=cabinet_merge3, index=c('COWCode', 'YEAR'),
            model='within', effect='individual')

summary(model3.2)
coef3.2<-coeftest(model3.2, type='HC0', cluster='group', adjust=T)

#Table SI.11.3
stargazer(model3, model3.1, model3.2, se=list(coef3[,2], coef3.1[,2], coef3.2[,2]))


#Split the sample by country/region
#Splitting sample by country
countryfe<-as.data.frame(summary(fixef(model1.6.1)))
countryfe$COWCode<-row.names(countryfe)
countryfe$country.name<-countrycode(countryfe$COWCode, 'cown', 'country.name')
countryfe2<-countryfe[countryfe$`Pr(>|t|)`<0.1,]


#Get rid of influential observations
model_fe<-lm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size+as.factor(COWCode)
                , data=cabinet_merge3)


influencePlot(model_fe)
cabinet_merge3[7412,]$COWCode
cabinet_merge11<-subset(cabinet_merge3, !(COWCode==70| COWCode==439|
                                            COWCode==540)|COWCode==703|COWCode==816)

model3.3<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                 L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                 L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                 L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size, data=cabinet_merge11,
              index=c('COWCode', 'YEAR'),
              model='within', effect='individual')
summary(model3.3)
coef3.3<-coeftest(model3.3, type='HC0', cluster='group', adjust=T)

#Subset to countries with some ethnic party stuff going on
model3.4<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3[cabinet_merge3$L_v2pepwrsoc01==0,],
                index=c('COWCode', 'YEAR'),
                model='within', effect='individual')

summary(model3.4)
coef3.4<-coeftest(model3.4, type='HC0', cluster='group', adjust=T)
               
cabinet_merge3$Africa<-ifelse(cabinet_merge3$un_region_name=="Eastern Africa"|
                                cabinet_merge3$un_region_name=="Western Africa"|
                                cabinet_merge3$un_region_name=="Northern Africa"|
                                cabinet_merge3$un_region_name=="Middle Africa"|
                                cabinet_merge3$un_region_name=="Southern Africa",1,0)

cabinet_merge3$Europe<-ifelse(cabinet_merge3$un_region_name=="Eastern Europe"|
                                cabinet_merge3$un_region_name=="Northern Europe"|
                                cabinet_merge3$un_region_name=="Western Europe"|
                                cabinet_merge3$un_region_name=="Southern Europe"
                                ,1,0)

cabinet_merge3$America<-ifelse(cabinet_merge3$un_region_name=="Central America"|
                                cabinet_merge3$un_region_name=="Northern America"|
                                cabinet_merge3$un_region_name=="South America"|
                                cabinet_merge3$un_region_name=="Caribbean"
                              ,1,0)

cabinet_merge3$Asia<-ifelse(cabinet_merge3$un_region_name=="Australia and New Zealand"|
                              cabinet_merge3$un_region_name=="Central Asia"|
                              cabinet_merge3$un_region_name=="Eastern Asia"|
                              cabinet_merge3$un_region_name=="Melanesia"|
                              cabinet_merge3$un_region_name=="Polynesia"|
                              cabinet_merge3$un_region_name=="South-Eastern Asia"|
                              cabinet_merge3$un_region_name=="Southern Asia"|
                              cabinet_merge3$un_region_name=="Western Asia"
                               ,1,0)

cabinet_merge3$West<-ifelse(cabinet_merge3$un_region_name=="Northern Europe"|
                              cabinet_merge3$un_region_name=="Western Europe"|
                              cabinet_merge3$un_region_name=="Australia and New Zealand"|
                              cabinet_merge3$un_region_name=="Northern America"
                              ,1,0)


model3.5<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                  L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                  L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                  L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
                , data=cabinet_merge3[cabinet_merge3$Africa==1,],
                index=c('COWCode', 'YEAR'),
                model='within', effect='individual')

summary(model3.5)
coef3.5<-coeftest(model3.5, type='HC0', cluster='group', adjust=T)


model3.6<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
              , data=cabinet_merge3[cabinet_merge3$Europe==1,],
              index=c('COWCode', 'YEAR'),
              model='within', effect='individual')

summary(model3.6)
coef3.6<-coeftest(model3.6, type='HC0', cluster='group', adjust=T)


model3.7<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
              , data=cabinet_merge3[cabinet_merge3$America==1,],
              index=c('COWCode', 'YEAR'),
              model='within', effect='individual')

summary(model3.7)
coef3.7<-coeftest(model3.7, type='HC0', cluster='group', adjust=T)


model3.8<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
              , data=cabinet_merge3[cabinet_merge3$Asia==1,],
              index=c('COWCode', 'YEAR'),
              model='within', effect='individual')

summary(model3.8)
coef3.8<-coeftest(model3.8, type='HC0', cluster='group', adjust=T)


model3.9<-plm(cabinet_elf~L_elf+L_v2x_execorr+L_school04_log+
                L_v2x_execorr:L_school04_log+lpopl+npeaceyears_log+
                L_count_log+L_legis02l+L_polit03+L_gpro+coalition+
                L_factional+L_legis07_log+L_e_migdppcln+L_polity+L_Size
              , data=cabinet_merge3[cabinet_merge3$West==1,],
              index=c('COWCode', 'YEAR'),
              model='within', effect='individual')

summary(model3.9)
coef3.9<-coeftest(model3.9, type='HC0', cluster='group', adjust=T)

#Table SI.12.3
stargazer(model3.3, model3.4, model3.5, model3.6, model3.7, model3.8, model3.9,
          se=list(coef3.3[,2], coef3.4[,2], coef3.5[,2], coef3.6[,2], coef3.7[,2], coef3.8[,2], coef3.9[,2]))


