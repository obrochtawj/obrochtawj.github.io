#######################################################
### Ethnic Diversity in Central Government Cabinets ###
### Cabinet Diversity Dataset Construction          ###
### William O'Brochta                               ###
### Washington University in St. Louis              ###
#######################################################

library(profvis)
library(nomine)
library(sandwich)
library(lmtest)
library(MASS)
library(car)
library(prais)
library(panelAR)
library(orcutt)
library(countrycode)
library(plm)
library(plyr)
library(dplyr)

#Read in list of all cabinet members by country-year
#Warning: file is extremely large
#cabinet<-read.csv('CabinetMinisterList.csv', header=T, stringsAsFactors = F)
cabinet<-cabinet[,c(1:4)]

#Read in key to translate country names into COW codes
cow<-read.csv('COW Legend.csv', header=T, stringsAsFactors = F)
cabinet2<-merge(cabinet,cow, by='COUNTRY')

#Find unique names
names<-as.data.frame(unique(cabinet[,4]))

#Script to run unique names through NamePrism and return results.
#Warning: only runs if connected to NamePrism API with special permission
#from NamePrism authors

#names_nationality<-as.data.frame(matrix(nrow=nrow(names),ncol=42))
#for(i in 1046:nrow(names)){
#  if(i%%1000==0){
#    names_nationality[i,]<-get_nationalities(names[i,1])
#    write.csv(names_nationality,paste0('names_nationality',i,'.csv'))
#    pause(1)
#  }
#  else{
#  names_nationality[i,]<-get_nationalities(names[i,1])
#  pause(1)
#  }
#}


#Name columns and clean output
names_nationality<-names_nationality[1:67795,]
names_final<-as.data.frame(cbind(names, names_nationality))
colnames(names_final)<-c('Name', 'input', 'encoded_name', 'url',
                         'European-SouthSlavs', 'Muslim-Pakistanis-Bangladesh',
                         'European-Italian-Italy', 'European-Baltics', 'African-SouthAfrican',
                         'European-Italian-Romania', 'Muslim-Nubian', 'European-French',
                         'EastAsian-Indochina-Thailand', 'EastAsian-Indochina-Vietnam',
                         'Jewish', 'Muslim-Turkic-CentralAsian', 'EastAsian-Indochina-Cambodia',
                         'Nordic-Scandinavian-Denmark', 'EastAsian-Indochina-Myanmar',
                         'Nordic-Finland', 'Muslim-Persian', 'Nordic-Scandinavian-Sweden',
                         'Muslim-Maghreb', 'Greek', 'Muslim-Pakistanis-Pakistan',
                         'Hispanic-Portuguese', 'European-Russian', 'Muslim-ArabianPeninsula',
                         'African-WestAfrican', 'EastAsian-Japan', 'European-German',
                         'EastAsian-Chinese', 'SouthAsian', 'Hispanic-Spanish',
                         'Nordic-Scandinavian-Norway', 'Muslim-Turkic-Turkey',
                         'Hispanic-Philippines', 'CelticEnglish', 'EastAsian-Malay-Malaysia',
                         'EastAsian-South Korea', 'African-EastAfrican', 'European-EastEuropean',
                         'EastAsian-Malay-Indonesia')

names_final$Name<-as.character(names_final$Name)
names_final[,5:43] <- sapply(names_final[,5:43],as.numeric)

#Send final names output to CSV
cabinet3<-merge(cabinet2,names_final, by='Name', all.x=TRUE)
#write.csv(cabinet3,'cabinet_with_nationality.csv')

#Read in names CSV
cabinet3<-read.csv('cabinet_with_nationality.csv', header=T, stringsAsFactors = F)
cabinet4<-cabinet3[,c(4,5,10:48)]

#Count number of members in cabinet
cabinet4$Size<-1
names_aggregate<-aggregate(x=cabinet4[,-c(1:2)], by=cabinet4[c('COWCode', 'YEAR')], FUN='sum', na.rm=TRUE)

#Get the largest percentage assigned to a Name Community for each name
for(i in 1:nrow(names_aggregate)){
  names_aggregate$Max[i]<-max(names_aggregate[i,c(3:41)])/names_aggregate$Size[i]}

#Calculate the ELF for each name
for(i in 1:nrow(names_aggregate)){
  names_aggregate$elf[i]<-1-(sum((names_aggregate[i,c(3:41)]/names_aggregate$Size[i])^2))}


#Read in old EPR data; v1.1 used because of the country-level ELF measure
library(foreign)
EPR<-read.dta('EPR_countryyear_v1.1.dta')
cabinet_EPR<-merge(names_aggregate,EPR, by.x=c('COWCode', 'YEAR'), by.y=c('cowcode', 'year'), all.x=T, all.y=F)

#Read in DD and FH data
DD<-read.csv('ddrevisited_data_v1.csv', header=T, stringsAsFactors = F)
FH<-read.csv('fh1972_20162.csv', header=T, stringsAsFactors = F)

cabinet_DD<-merge(cabinet_EPR, DD, by.x=c('COWCode', 'YEAR'), by.y=c('cowcode', 'year'), all.x=TRUE)
cabinet_FH<-merge(cabinet_DD, FH, by.x=c('COWCode', 'YEAR'), by.y=c('ccode', 'year'), all.x=TRUE)
cabinet_FH$status<-as.factor(cabinet_FH$status)

#Read in new EPR data; used because it has a longer time series for key variables
EPR_New<-read.dta('EPR3CountryNewReduced.dta')

cabinet_EPR2<-merge(cabinet_FH,EPR_New, by.x=c('COWCode', 'YEAR'), by.y=c('cowcode', 'year'), all.x=TRUE)

#Sort and compute lags for key variables
cabinet_EPR2<-arrange(cabinet_EPR2,desc(country.x))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Max =
                       c(NA, Max[-length(Max)]
                       ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Max2 =
                        c(NA, L_Max[-length(L_Max)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Max3 =
                        c(NA, L_Max2[-length(L_Max2)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Max4 =
                        c(NA, L_Max3[-length(L_Max3)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Max5 =
                        c(NA, L_Max4[-length(L_Max4)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_elf =
                       c(NA, elf[-length(elf)]
                       ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_elf2 =
                        c(NA, L_elf[-length(L_elf)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_elf3 =
                        c(NA, L_elf2[-length(L_elf2)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_elf4 =
                        c(NA, L_elf3[-length(L_elf3)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_elf5 =
                        c(NA, L_elf4[-length(L_elf4)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Size =
                        c(NA, Size[-length(Size)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_Year =
                        c(NA, YEAR[-length(YEAR)]
                        ))

#Calculate cabinet elf and lags
for(i in 1:nrow(cabinet_EPR2)){
  cabinet_EPR2$cabinet_elf[i]<-1-(sum((cabinet_EPR2[i,c(3:41)]/cabinet_EPR2$Size[i])^2))}
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_cabinet_elf =
                        c(NA, cabinet_elf[-length(cabinet_elf)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_cabinet_elf2 =
                        c(NA, L_cabinet_elf[-length(L_cabinet_elf)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_cabinet_elf3 =
                        c(NA, L_cabinet_elf2[-length(L_cabinet_elf2)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_cabinet_elf4 =
                        c(NA, L_cabinet_elf3[-length(L_cabinet_elf3)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_cabinet_elf5 =
                        c(NA, L_cabinet_elf4[-length(L_cabinet_elf4)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_sum =
                        c(NA, sum[-length(sum)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_polity =
                        c(NA, polity[-length(polity)]
                        ))
cabinet_EPR2 <- ddply(cabinet_EPR2, .(country.x), transform, L_groups =
                        c(NA, groups.x[-length(groups.x)]
                        ))


#Read in HOS data
HOS<-read.csv('EthHeadofState.Fearon07.Data.csv', header=T, stringsAsFactors = F)
HOS_long <- do.call(rbind, lapply(sequence(nrow(HOS)), function(x) {
  data.frame(ccode = HOS$ccode[x],
             cabbr = HOS$cabbr[x],
             year = seq(HOS$start_year[x], HOS$end_year[x], by = 1),
             gpro = HOS$gpro[x],
             leadid_arch04 = HOS$leadid_arch04[x],
             leader_arch04 = HOS$leader_arch04[x])
}))

#Code when a government transition takes place
HOS_long$transition_test<-HOS_long$leadid_arch04 != lag(HOS_long$leadid_arch04)
HOS_long$transition<-ifelse(HOS_long$transition==TRUE,1,0)

cabinet_HOS<-merge(cabinet_EPR2,HOS_long, by.x=c('COWCode', 'YEAR'), by.y=c('ccode', 'year'), all.x=TRUE)
cabinet_HOS <- ddply(cabinet_HOS, .(country.x), transform, L_gpro =
                        c(NA, gpro[-length(gpro)]
                        ))
cabinet_HOS <- ddply(cabinet_HOS, .(country.x), transform, L_transition =
                        c(NA, transition[-length(transition)]
                        ))


#Read in CNTS; need access to CNTS proprietary dataset to add these variables
CNTS<-read.csv('2016 Edition CNTSDATA.csv', header=T, stringsAsFactors = F)
CNTS$cow_code<-countrycode(CNTS$Wbcode, 'wb', 'cown')
CNTS<-CNTS[,-3]

cabinet_CNTS<-merge(cabinet_HOS, CNTS, by.x=c('COWCode', 'YEAR'), by.y=c('cow_code', 'year'), all.x=TRUE)
cabinet_CNTS <- ddply(cabinet_CNTS, .(country.x), transform, L_legis02 =
                        c(NA, legis02[-length(legis02)]
                        ))
cabinet_CNTS$L_legis02l<-ifelse(cabinet_CNTS$L_legis02==0,0,log(cabinet_CNTS$L_legis02))


#Read in prevailing ethnicity in each country (i.e., the dominant name community in each country)
Prevalent<-read.csv('Prevalent Ethnicity.csv', header=T, stringsAsFactors = F)
cabinet_prevalent<-merge(cabinet_CNTS, Prevalent, by.x='COWCode', by.y='CCode', all.x=T)

prevalent_subset<-as.data.frame(cbind(cabinet_prevalent[,c(1:41)], cabinet_prevalent$Size, cabinet_prevalent$Prevalent_Ethnicity))
prevalent_subset<-prevalent_subset[complete.cases(prevalent_subset),]

#Calculate cabinet diversity penalty term based on dominant ethnicity in a given country
for(i in 1:nrow(prevalent_subset)){
All<-as.list(c(3:41))
Match<-which(colnames(prevalent_subset[i,c(3:41)])==prevalent_subset$`cabinet_prevalent$Prevalent_Ethnicity`[i])
All[Match]<-NULL
Match<-which(colnames(prevalent_subset[i,c(3:41)])==prevalent_subset$`cabinet_prevalent$Prevalent_Ethnicity`[i])+2
All<-as.integer(All)
prevalent_subset$cabinet_diverse[i]<-1-(sum((prevalent_subset[i,c(All)]/prevalent_subset$`cabinet_prevalent$Size`[i])^2))-(3*(prevalent_subset[i,c(Match)]/prevalent_subset$`cabinet_prevalent$Size`[i]))}


cabinet_prevalent<-merge(cabinet_CNTS, prevalent_subset, by=c('COWCode', 'YEAR'), all.x=TRUE)

#Run models with new variable (any less strong penalty will also be significant)
cabinet_prevalent <- ddply(cabinet_prevalent, .(country.x), transform, L_cabinet_diverse =
                       c(NA, cabinet_diverse[-length(cabinet_diverse)]
                       ))
cabinet_prevalent <- ddply(cabinet_prevalent, .(country.x), transform, L_cabinet_diverse2 =
                             c(NA, L_cabinet_diverse[-length(L_cabinet_diverse)]
                             ))


#Pull only unique country-year cases
cabinet_subset4<-as.data.frame(cbind(cabinet_prevalent$COWCode, cabinet_prevalent$YEAR))
cabinet_prevalent2<-cabinet_prevalent[!duplicated(cabinet_subset4),]

cabinet_prevalent2 <- ddply(cabinet_prevalent2, .(country.x), transform, L_tenure08 =
                             c(NA, tenure08[-length(tenure08)]
                             ))
cabinet_prevalent2 <- ddply(cabinet_prevalent2, .(country.x), transform, L_npeaceyears =
                              c(NA, npeaceyears[-length(npeaceyears)]
                              ))
cabinet_prevalent2 <- ddply(cabinet_prevalent2, .(country.x), transform, L_domestic9 =
                              c(NA, domestic9[-length(domestic9)]
                              ))
cabinet_prevalent2 <- ddply(cabinet_prevalent2, .(country.x), transform, L_military1 =
                              c(NA, military1[-length(military1)]
                              ))
cabinet_prevalent2 <- ddply(cabinet_prevalent2, .(country.x), transform, L_polit10 =
                              c(NA, polit10[-length(polit10)]
                              ))
cabinet_prevalent2 <- ddply(cabinet_prevalent2, .(country.x), transform, L_polit11 =
                              c(NA, polit11[-length(polit11)]
                              ))

cabinet_prevalent2$L_domestic9l<-ifelse(cabinet_prevalent2$L_domestic9==0,0,log(cabinet_prevalent2$L_domestic9))

#write.csv(cabinet_prevalent2, 'cabinet_prevalent_panel.csv')

attach(cabinet_prevalent2)
cabinet_prevalent3<-as.data.frame(cbind(COWCode, YEAR, country.x, cabinet_elf,
                                        cabinet_diverse, Max, elf, Size, 
                                        polity, sum, gpro, transition,
                                        legis02, western, un_region_name,
                                        L_elf, L_Year, L_Size, L_polity, L_sum,
                                        L_gpro, L_transition, L_legis02,
                                        L_legis02l, lpopl, gdpcapl, L_cabinet_elf,
                                        L_cabinet_elf2, tenure08, oilpcl, warlfl,
                                        npeaceyears, military1, domestic9, polit10,
                                        polit11, L_tenure08, L_npeaceyears,
                                        L_military1, L_domestic9, L_polit10,
                                        L_polit11, groups, L_groups, L_groupsl))
detach(cabinet_prevalent2)

#write.csv(cabinet_prevalent3, 'cabinet_prevalent_reduced2.csv')



