########################################################################################
### Perceptions of Partisanship in Local Television News: San Francisco Analysis     ###
### William O'Brochta, Louisiana Tech University                                     ###
########################################################################################


library(textreadr)
library(tm)
library(stringr)
library(plyr)
library(dplyr)
library(topicmodels)
library(ldatuning)
library(xtable)


#Read in 7 day 6-7PM Pacific time coverage for 6-15 to 6-26 2020
#Days 6-15, 6-16, and 6-18 are excluded because transcripts have missing data
#CBS excluded because newscast is only 6-6:30PM
FOX<-read_rtf("FOX.rtf")
ABC<-read_rtf("ABC.rtf")
NBC<-read_rtf("NBC.rtf")



#Prepare FOX
docs<-FOX
docs[docs==""] <- NA
which(is.na(docs))
docs<-docs[complete.cases(docs)]
docs<-Corpus(VectorSource(docs))
#Prepare corpus
#Make lowercase, remove punctuation, remove stopwords
docs<-tm_map(docs, content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, '', x))})
docs<-tm_map(docs, toSpace, '-')
docs<-tm_map(docs, toSpace, "'")
docs<-tm_map(docs, removePunctuation)
docs<-tm_map(docs, removeNumbers)
docs<-tm_map(docs, removeWords, stopwords('english'))
docs<-tm_map(docs, stripWhitespace)
docs<-tm_map(docs, stemDocument)
myStopwords<-c('live', 'thanks', 'thank you', 'reporter', "now", "today",
               "tomorrow", "new", "breaking news", "news", "story", "report")
docs<-tm_map(docs, removeWords, myStopwords)
dtm<-DocumentTermMatrix(docs)
freq<-colSums(as.matrix(dtm))
length(freq)
ord<-order(freq, decreasing=T)

freqFOX<-as.data.frame(freq)
freqFOX$word<-row.names(freqFOX)
colnames(freqFOX)<-c("FOX", "word")


#Prepare ABC
docs<-ABC
docs[docs==""] <- NA
which(is.na(docs))
docs<-docs[complete.cases(docs)]
docs<-Corpus(VectorSource(docs))
#Prepare corpus
#Make lowercase, remove punctuation, remove stopwords
docs<-tm_map(docs, content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, '', x))})
docs<-tm_map(docs, toSpace, '-')
docs<-tm_map(docs, toSpace, "'")
docs<-tm_map(docs, removePunctuation)
docs<-tm_map(docs, removeNumbers)
docs<-tm_map(docs, removeWords, stopwords('english'))
docs<-tm_map(docs, stripWhitespace)
docs<-tm_map(docs, stemDocument)
myStopwords<-c('live', 'thanks', 'thank you', 'reporter', "now", "today",
               "tomorrow", "new", "breaking news", "news", "story", "report")
docs<-tm_map(docs, removeWords, myStopwords)
dtm<-DocumentTermMatrix(docs)
freq<-colSums(as.matrix(dtm))
length(freq)
ord<-order(freq, decreasing=T)

freqABC<-as.data.frame(freq)
freqABC$word<-row.names(freqABC)
colnames(freqABC)<-c("ABC", "word")


#Prepare NBC
docs<-NBC
docs[docs==""] <- NA
which(is.na(docs))
docs<-docs[complete.cases(docs)]
docs<-Corpus(VectorSource(docs))
#Prepare corpus
#Make lowercase, remove punctuation, remove stopwords
docs<-tm_map(docs, content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, '', x))})
docs<-tm_map(docs, toSpace, '-')
docs<-tm_map(docs, toSpace, "'")
docs<-tm_map(docs, removePunctuation)
docs<-tm_map(docs, removeNumbers)
docs<-tm_map(docs, removeWords, stopwords('english'))
docs<-tm_map(docs, stripWhitespace)
docs<-tm_map(docs, stemDocument)
myStopwords<-c('live', 'thanks', 'thank you', 'reporter', "now", "today",
               "tomorrow", "new", "breaking news", "news", "story", "report")
docs<-tm_map(docs, removeWords, myStopwords)
dtm<-DocumentTermMatrix(docs)
freq<-colSums(as.matrix(dtm))
length(freq)
ord<-order(freq, decreasing=T)

freqNBC<-as.data.frame(freq)
freqNBC$word<-row.names(freqNBC)
colnames(freqNBC)<-c("NBC", "word")


#Merge word frequencies
freqtotal<-merge(freqFOX, freqABC, by="word", all.x=T, all.y=T)
freqtotal2<-merge(freqtotal, freqNBC, by="word", all.x=T, all.y=T)
freqtotal2$total<-rowSums(freqtotal2[,2:4], na.rm=T)
freqtotal2$FOX_pct<-(freqtotal2$FOX/sum(freqtotal2$FOX, na.rm=T))*100
freqtotal2$ABC_pct<-(freqtotal2$ABC/sum(freqtotal2$ABC, na.rm=T))*100
freqtotal2$NBC_pct<-(freqtotal2$NBC/sum(freqtotal2$NBC, na.rm=T))*100
freqtotal2$total_pct<-(freqtotal2$total/sum(freqtotal2$total, na.rm=T))*100

write.csv(freqtotal2, file="frequtotal.csv", row.names=F)







