######################################################################################
### Perceptions of Partisanship in Local Television News: Analysis File            ###
### William O'Brochta, Louisiana Tech University                                   ###
######################################################################################


library(plyr)
library(dplyr)
library(lme4)
library(brms)
library(lmerTest)
library(lmtest)
library(MASS)
library(sandwich)
library(ordinal)
library(multiwayvcov)
library(texreg)
library(psych)
library(stargazer)
library(ggplot2)
library(xtable)
library(ttutils)


load("data3.RData")

###Results just for people watching local news
data4.2<-data3[data3$watch_local==1,]
data4.2<-data4.2[!is.na(data4.2$fips),]

data4.2$national_FOX<-ifelse(data4.2$media_national=="FOX", 1, 0)
data4.2$national_ABC<-ifelse(data4.2$media_national=="ABC", 1, 0)
data4.2$national_NBC<-ifelse(data4.2$media_national=="NBC", 1, 0)
data4.2$national_CBS<-ifelse(data4.2$media_national=="CBS", 1, 0)
data4.2$national_MSNBC<-ifelse(data4.2$media_national=="MSNBC", 1, 0)
data4.2$national_CNN<-ifelse(data4.2$media_national=="CNN", 1, 0)
data4.2$national_PBS<-ifelse(data4.2$media_national=="PBS", 1, 0)
data4.2$national_OANN<-ifelse(data4.2$media_national=="One America News Network", 1, 0)




####Station Affiliation
#Plot I actually use
marginal3<-data.frame()

#Reference categories: local Fox, national none, owner other, age1834
model11.0<-lm(pers_infected_D~media_local_ABC+media_local_NBC+media_local_CBS+
                national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.0<-coeftest(model11.0, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.0, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.0, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"pers_infected"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)


model11.1<-glmer(pers_infected_D~media_local_ABC+media_local_NBC+media_local_CBS+
                   national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                   national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                   read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                   some_college_or_assdegr+ba_or_more+suburban+urban+
                   Republican+Independent+income_lowmid+income_upmid+
                   income_high+unemployed+nonwhite+polknowledge_high+
                   coronaknowledge_high+(1|FIPS_State), 
                 data4.2, family="binomial", control=glmerControl(optimizer = "bobyqa"))
summary(model11.1)


model11.2<-lm(know_infected_D~media_local_ABC+media_local_NBC+media_local_CBS+
                national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.2<-coeftest(model11.2, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.2, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.2, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"know_infected"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.3<-glmer(know_infected_D~media_local_ABC+media_local_NBC+media_local_CBS+
                   national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                   national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                   read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                   some_college_or_assdegr+ba_or_more+suburban+urban+
                   Republican+Independent+income_lowmid+income_upmid+
                   income_high+unemployed+nonwhite+polknowledge_high+
                   coronaknowledge_high+(1|FIPS_State), 
                 data4.2, family="binomial", control=glmerControl(optimizer = "bobyqa"))
summary(model11.3)


model11.4<-lm(risk_inf_pers_n~media_local_ABC+media_local_NBC+media_local_CBS+
                national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.4<-coeftest(model11.4, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.4, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.4, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"risk_inf_pers"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.5<-lme4::lmer(risk_inf_pers_n~media_local_ABC+media_local_NBC+media_local_CBS+
                        national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                        national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                        read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+
                        hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                        Republican+Independent+income_lowmid+income_upmid+
                        income_high+unemployed+nonwhite+polknowledge_high+
                        coronaknowledge_high+(1|FIPS_State), data4.2)
summary(model11.5)


model11.6<-lm(risk_inf_fam_friends_n~media_local_ABC+media_local_NBC+media_local_CBS+
                national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.6<-coeftest(model11.6, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.6, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.6, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"risk_inf_fam_friends"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.7<-lme4::lmer(risk_inf_fam_friends_n~media_local_ABC+media_local_NBC+media_local_CBS+
                        national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                        national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                        read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+
                        hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                        Republican+Independent+income_lowmid+income_upmid+
                        income_high+unemployed+nonwhite+polknowledge_high+
                        coronaknowledge_high+(1|FIPS_State), data4.2)
summary(model11.7)


model11.8<-lm(harm_pers_n~media_local_ABC+media_local_NBC+media_local_CBS+
                national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.8<-coeftest(model11.8, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.8, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.8, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"harm_pers"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.9<-ordinal::clmm(harm_pers_f~media_local_ABC+media_local_NBC+media_local_CBS+
                           national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                           national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                           read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+
                           hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                           Republican+Independent+income_lowmid+income_upmid+
                           income_high+unemployed+nonwhite+polknowledge_high+
                           coronaknowledge_high+(1|FIPS_State), data4.2)
summary(model11.9)


model11.10<-lm(harm_family_n~media_local_ABC+media_local_NBC+media_local_CBS+
                 national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                 national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                 read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                 Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                 polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.10<-coeftest(model11.10, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.10, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.10, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"harm_family"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.11<-ordinal::clmm(harm_family_f~media_local_ABC+media_local_NBC+media_local_CBS+
                            national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                            national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                            read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+
                            hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                            Republican+Independent+income_lowmid+income_upmid+
                            income_high+unemployed+nonwhite+polknowledge_high+
                            coronaknowledge_high+(1|FIPS_State), data4.2)
summary(model11.11)


model11.12<-lm(harm_owncom_n~media_local_ABC+media_local_NBC+media_local_CBS+
                 national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                 national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                 read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                 Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                 polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.12<-coeftest(model11.12, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.12, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.12, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"harm_owncom"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.13<-ordinal::clmm(harm_owncom_f~media_local_ABC+media_local_NBC+media_local_CBS+
                            national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                            national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                            read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+
                            hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                            Republican+Independent+income_lowmid+income_upmid+
                            income_high+unemployed+nonwhite+polknowledge_high+
                            coronaknowledge_high+(1|FIPS_State), data4.2)
summary(model11.13)

model11.14<-lm(harm_ppl_US_n~media_local_ABC+media_local_NBC+media_local_CBS+
                 national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                 national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                 read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                 Republican+Independent+income_lowmid+income_upmid+income_high+unemployed+nonwhite+
                 polknowledge_high+coronaknowledge_high+FIPS_State, data4.2)
(coef11.14<-coeftest(model11.14, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
marginal3_temp<-as.data.frame(summary(margins::margins(model11.14, 
                                                       variables=c("media_local_ABC", "media_local_NBC", "media_local_CBS",
                                                                   "national_FOX", "national_ABC", "national_NBC", "national_CBS",
                                                                   "national_MSNBC", "national_CNN", "national_PBS", "national_OANN"), 
                                                       vcov=vcovCL(model11.14, cluster=data4.2$FIPS_State))))
marginal3_temp$dv<-"harm_ppl_US"
marginal3_temp$level<-"affiliate"
marginal3<-rbind(marginal3, marginal3_temp)

model11.15<-ordinal::clmm(harm_ppl_US_f~media_local_ABC+media_local_NBC+media_local_CBS+
                            national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                            national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                            read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+
                            hs+some_college_or_assdegr+ba_or_more+suburban+urban+
                            Republican+Independent+income_lowmid+income_upmid+
                            income_high+unemployed+nonwhite+polknowledge_high+
                            coronaknowledge_high+(1|FIPS_State), data4.2)
summary(model11.15)


marginal3.2<-marginal3
#save(marginal3.2, file="marginal3.2.RData")

#Table C.2
stargazer(model11.4, model11.6, model11.8, model11.10, model11.12, model11.14,
          se=list(coef11.4[,2], coef11.6[,2], coef11.8[,2], coef11.10[,2],
                  coef11.12[,2], coef11.14[,2]), no.space=T, type = "html", out="risklm.doc", digits=2,
          star.cutoffs=c(0.05, 0.01, 0.001))

#Table C.3
htmlreg(list(model11.5, model11.7, model11.9, 
            model11.11, model11.13, model11.15), file="riskglm.doc")



#Figure 1
load("marginal3.2.RData")

marginal_local<-marginal3.2
marginal_local<-marginal_local[marginal_local$dv!="pers_infected",]
marginal_local<-marginal_local[marginal_local$dv!="know_infected",]
marginal_local<-marginal_local[marginal_local$factor!="national_ABC",]
marginal_local<-marginal_local[marginal_local$factor!="national_NBC",]
marginal_local<-marginal_local[marginal_local$factor!="national_CBS",]
marginal_local<-marginal_local[marginal_local$factor!="national_PBS",]
marginal_local<-marginal_local[marginal_local$factor!="national_OANN",]


marginal_local$factor <- factor(marginal_local$factor, levels = c("national_CNN", "national_MSNBC", "national_FOX",
                                                                  "media_local_ABC", "media_local_NBC", "media_local_CBS"),
                                labels = c("CNN", "MSNBC", "Fox News", "Local ABC", "Local NBC", "Local CBS"))
marginal_local$dv<-factor(marginal_local$dv,levels = c("harm_ppl_US", "harm_owncom",
                                                       "harm_family", "harm_pers",
                                                       "risk_inf_fam_friends", "risk_inf_pers"),
                          labels=c("Harm US", "Harm Community", "Harm Family", "Harm Personal",
                                   "Risk Family", "Risk Personal"))


marginal_local1 <- ggplot(data=marginal_local, aes(dv, AME, color = factor,
                                                   group = factor, shape = factor)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()

marginal_local2 <- marginal_local1 + geom_linerange(data=marginal_local, 
                                                    aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="") + 
  coord_flip(ylim = c(-0.18, 0.18)) +  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=11)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 12))+
  labs(color  = "", linetype = "", shape = "")+
  scale_linetype_manual( values= c("solid", "solid", "solid", "solid", "solid", "solid"))+
  scale_colour_manual(values = c("gray75", "gray45", "black", "orange", "darkorange", "orange3"))+
  scale_shape_manual( values = c(16, 16, 16, 17, 17, 17))
marginal_local2



#Table 1: Watching National and Local News

table(data4.2[data4.2$media_local_FOX==1,]$media_national)/sum(table(data4.2[data4.2$media_local_FOX==1,]$media_national))
#Mainstream not network loyal
0.07570978+0.04942166+0.04837014+0.01682440


table(data4.2[data4.2$media_local_ABC==1,]$media_national)/sum(table(data4.2[data4.2$media_local_ABC==1,]$media_national))
#Mainstream not network loyal
0.041189931+0.052631579+0.016781083

table(data4.2[data4.2$media_local_NBC==1,]$media_national)/sum(table(data4.2[data4.2$media_local_NBC==1,]$media_national))
#Mainstream not network loyal
0.07948094+0.04703974+0.03244120

table(data4.2[data4.2$media_local_CBS==1,]$media_national)/sum(table(data4.2[data4.2$media_local_CBS==1,]$media_national))
#Mainstream not network loyal
0.075824176+0.084615385+0.040659341

table(data4.2[data4.2$media_local_FOX==1,]$Republican)/sum(table(data4.2[data4.2$media_local_FOX==1,]$Republican))
table(data4.2[data4.2$media_local_ABC==1,]$Republican)/sum(table(data4.2[data4.2$media_local_ABC==1,]$Republican))
table(data4.2[data4.2$media_local_NBC==1,]$Republican)/sum(table(data4.2[data4.2$media_local_NBC==1,]$Republican))
table(data4.2[data4.2$media_local_CBS==1,]$Republican)/sum(table(data4.2[data4.2$media_local_CBS==1,]$Republican))

table(data4.2[data4.2$media_local_FOX==1,]$Democrat)/sum(table(data4.2[data4.2$media_local_FOX==1,]$Democrat))
table(data4.2[data4.2$media_local_ABC==1,]$Democrat)/sum(table(data4.2[data4.2$media_local_ABC==1,]$Democrat))
table(data4.2[data4.2$media_local_NBC==1,]$Democrat)/sum(table(data4.2[data4.2$media_local_NBC==1,]$Democrat))
table(data4.2[data4.2$media_local_CBS==1,]$Democrat)/sum(table(data4.2[data4.2$media_local_CBS==1,]$Democrat))

table(data4.2[data4.2$media_local_FOX==1,]$Independent)/sum(table(data4.2[data4.2$media_local_FOX==1,]$Independent))
table(data4.2[data4.2$media_local_ABC==1,]$Independent)/sum(table(data4.2[data4.2$media_local_ABC==1,]$Independent))
table(data4.2[data4.2$media_local_NBC==1,]$Independent)/sum(table(data4.2[data4.2$media_local_NBC==1,]$Independent))
table(data4.2[data4.2$media_local_CBS==1,]$Independent)/sum(table(data4.2[data4.2$media_local_CBS==1,]$Independent))





#Examine who watches local FOX among those who watch local
model12.16<-glmer(media_local_FOX~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                    national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                    read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                    some_college_or_assdegr+ba_or_more+suburban+urban+
                    Republican+Independent+income_lowmid+income_upmid+
                    income_high+unemployed+nonwhite+polknowledge_high+
                    coronaknowledge_high+(1|FIPS_State), 
                  data4.2, family="binomial", control=glmerControl(optimizer = "bobyqa"))
summary(model12.16)

model12.16.1<-lm(media_local_FOX~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                   national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                   read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                   some_college_or_assdegr+ba_or_more+suburban+urban+
                   Republican+Independent+income_lowmid+income_upmid+
                   income_high+unemployed+nonwhite+polknowledge_high+
                   coronaknowledge_high+FIPS_State, 
                 data4.2)
(coef12.16.1<-coeftest(model12.16.1, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
summary(model12.16.1)


model12.16.2<-glmer(media_local_ABC~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                      national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                      read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                      some_college_or_assdegr+ba_or_more+suburban+urban+
                      Republican+Independent+income_lowmid+income_upmid+
                      income_high+unemployed+nonwhite+polknowledge_high+
                      coronaknowledge_high+(1|FIPS_State), 
                    data4.2, family="binomial", control=glmerControl(optimizer = "bobyqa"))
summary(model12.16.2)

model12.16.3<-lm(media_local_ABC~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                   national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                   read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                   some_college_or_assdegr+ba_or_more+suburban+urban+
                   Republican+Independent+income_lowmid+income_upmid+
                   income_high+unemployed+nonwhite+polknowledge_high+
                   coronaknowledge_high+FIPS_State, 
                 data4.2)
(coef12.16.3<-coeftest(model12.16.3, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
summary(model12.16.3)


model12.16.4<-glmer(media_local_NBC~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                      national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                      read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                      some_college_or_assdegr+ba_or_more+suburban+urban+
                      Republican+Independent+income_lowmid+income_upmid+
                      income_high+unemployed+nonwhite+polknowledge_high+
                      coronaknowledge_high+(1|FIPS_State), 
                    data4.2, family="binomial", control=glmerControl(optimizer = "bobyqa"))
summary(model12.16.4)

model12.16.5<-lm(media_local_NBC~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                   national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                   read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                   some_college_or_assdegr+ba_or_more+suburban+urban+
                   Republican+Independent+income_lowmid+income_upmid+
                   income_high+unemployed+nonwhite+polknowledge_high+
                   coronaknowledge_high+FIPS_State, 
                 data4.2)
(coef12.16.5<-coeftest(model12.16.5, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
summary(model12.16.5)


model12.16.6<-glmer(media_local_CBS~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                      national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                      read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                      some_college_or_assdegr+ba_or_more+suburban+urban+
                      Republican+Independent+income_lowmid+income_upmid+
                      income_high+unemployed+nonwhite+polknowledge_high+
                      coronaknowledge_high+(1|FIPS_State), 
                    data4.2, family="binomial", control=glmerControl(optimizer = "bobyqa"))
summary(model12.16.6)

model12.16.7<-lm(media_local_CBS~national_FOX+national_ABC+national_NBC+national_CBS+national_MSNBC+
                   national_CNN+national_PBS+national_OANN+watch_Sinclair+watch_Nexstar+watch_Gray+
                   read_newspaper+jhu_cnty_cases_log+age3549+age5064+age65above+female+hs+
                   some_college_or_assdegr+ba_or_more+suburban+urban+
                   Republican+Independent+income_lowmid+income_upmid+
                   income_high+unemployed+nonwhite+polknowledge_high+
                   coronaknowledge_high+FIPS_State, 
                 data4.2)
(coef12.16.7<-coeftest(model12.16.7, vcov=function(x) cluster.vcov(x, data4.2$FIPS_State)))
summary(model12.16.7)

#Table C.1
htmlreg(list(model12.16, model12.16.2, model12.16.4, model12.16.6), file="predictglm.doc")


