######################################################################################
### Perceptions of Partisanship in Local Television News: Preparation File         ###
### William O'Brochta, Louisiana Tech University                                   ###
######################################################################################

library(plyr)
library(dplyr)
library(fastDummies)
library(ttutils)
library(xtable)

#Merge DMA data with Sinclair Stations, Keep only FIPS Codes with Sinclair Stations
dma<-read.csv("DMA_FIPS.csv", header=T, stringsAsFactors = F)
sinclair<-read.csv("Sinclair_DMA.csv", header=T, stringsAsFactors = F)
sinclair<-sinclair[,c(1,2,4,6:9)]

#Nexstar
nexstar<-read.csv("Nexstar_DMA.csv", header=T, stringsAsFactors = F)
nexstar<-nexstar[,-2]

#Gray
gray<-read.csv("Gray_DMA.csv", header=T, stringsAsFactors = F)
gray<-gray[,-2]

#Combine
dma_owners1<-merge(sinclair, nexstar, by="DMA_CODE", all.x=T, all.y=T)
dma_owners2<-merge(dma_owners1, gray, by="DMA_CODE", all.x=T, all.y=T)
dma_owners<-merge(dma, dma_owners2[,-2], by="DMA_CODE", all.x=T, all.y=T)



#Read survey data
load("data_wcases.RData")
data2<-data_wcases[data_wcases$fips!=36061,]

#Eliminate decimal entries in case knowledge
data2$covid_county_knowl<-ifelse(data2$covid_county_knowl==1.5, NA, data2$covid_county_knowl)
data2$covid_county_knowl<-ifelse(data2$covid_county_knowl==1.711, NA, data2$covid_county_knowl)
data2$covid_county_knowl<-ifelse(isInteger(data2$covid_county_knowl)==FALSE, NA, data2$covid_county_knowl)

data2$covid_US_knowl<-ifelse(isInteger(data2$covid_US_knowl)==FALSE, NA, data2$covid_US_knowl)

data2$covid_county_knowl_log<-log(data2$covid_county_knowl+0.001)
data2$covid_US_knowl_log<-log(data2$covid_US_knowl+0.001)

#Normalize all DVs
#Social Norms
data2$claim_benefits_n<-(data2$claim_benefits-1)/4
data2$avoidpaying_n<-(data2$avoidpaying-1)/4
data2$useviolence_n<-(data2$useviolence-1)/4
data2$withholdsuppls_n<-(data2$withholdsuppls-1)/4
data2$withdraw_agrmnts_n<-(data2$withdraw_agrmnts-1)/4
data2$help_ppl_n<-(data2$help_ppl-1)/4
data2$givetocharity_n<-(data2$givetocharity-1)/4
data2$volunteer_n<-(data2$volunteer-1)/4

#Nationalism
data2$natidentity_n<-(data2$natidentity-1)/4

#Gender Relations
data2$fathers_chcare_n<-(data2$fathers_chcare-1)/4
data2$menrighttojobs_n<-(data2$menrighttojobs-1)/4
data2$menbetterldrs_n<-(data2$menbetterldrs-1)/4
data2$womenex_viol_n<-(data2$womenex_viol-1)/4

#Protests
data2$approve_protests_n<-(data2$approve_protests-1)/9
data2$approve_demonst_n<-(data2$approve_demonst-1)/9
data2$approve_disobedience_n<-(data2$approve_disobedience-1)/9

#Trust
data2$trust_sa_n<-(data2$trust_sa-1)/9


#Risk
data2$risk_inf_pers_n<-(data2$risk_inf_pers)/100
data2$risk_inf_fam_friends_n<-(data2$risk_inf_fam_friends)/100
data2$harm_pers_n<-(data2$harm_pers-1)/3
data2$harm_family_n<-(data2$harm_family-1)/3
data2$harm_owncom_n<-(data2$harm_owncom-1)/3
data2$harm_ppl_US_n<-(data2$harm_ppl_US-1)/3
data2$harm_ppl_otherC_n<-(data2$harm_ppl_otherC-1)/3

data2$covid_county_knowl_log_n<-(data2$covid_county_knowl_log+6.90775527898214)/(6.90775527898214+43.7491167668869)
data2$covid_US_knowl_log_n<-(data2$covid_US_knowl_log+6.90775527898214)/(6.90775527898214+39.1439465808988)


#Factor all DVs
#Social Norms
data2$claim_benefits_f<-as.factor(data2$claim_benefits)
data2$avoidpaying_f<-as.factor(data2$avoidpaying)
data2$useviolence_f<-as.factor(data2$useviolence)
data2$withholdsuppls_f<-as.factor(data2$withholdsuppls)
data2$withdraw_agrmnts_f<-as.factor(data2$withdraw_agrmnts)
data2$help_ppl_f<-as.factor(data2$help_ppl)
data2$givetocharity_f<-as.factor(data2$givetocharity)
data2$volunteer_f<-as.factor(data2$volunteer)

#Nationalism
data2$natidentity_f<-as.factor(data2$natidentity)

#Gender Relations
data2$fathers_chcare_f<-as.factor(data2$fathers_chcare)
data2$menrighttojobs_f<-as.factor(data2$menrighttojobs)
data2$menbetterldrs_f<-as.factor(data2$menbetterldrs)
data2$womenex_viol_f<-as.factor(data2$womenex_viol)

#Protests
data2$approve_protests_f<-as.factor(data2$approve_protests)
data2$approve_demonst_f<-as.factor(data2$approve_demonst)
data2$approve_disobedience_f<-as.factor(data2$approve_disobedience)

#Trust
data2$trust_sa_f<-as.factor(data2$trust_sa)

#Risk
data2$harm_pers_f<-as.factor(data2$harm_pers)
data2$harm_family_f<-as.factor(data2$harm_family)
data2$harm_owncom_f<-as.factor(data2$harm_owncom)
data2$harm_ppl_US_f<-as.factor(data2$harm_ppl_US)
data2$harm_ppl_otherC_f<-as.factor(data2$harm_ppl_otherC)



#Media Right Wing
data2$media_rw<-ifelse(data2$media_national=="FOX" | 
                         data2$media_national=="One America News Network",1,0)


#Log county cases
data2$jhu_cnty_cases_log<-log(data2$jhu_cnty_cases+0.001)
data2$jhu_cnty_cases_l1_log<-log(data2$jhu_cnty_cases_l1+0.001)
data2$jhu_cnty_cases_l2_log<-log(data2$jhu_cnty_cases_l2+0.001)
data2$jhu_cnty_cases_l3_log<-log(data2$jhu_cnty_cases_l3+0.001)
data2$jhu_cnty_cases_l4_log<-log(data2$jhu_cnty_cases_l4+0.001)
data2$jhu_cnty_cases_l5_log<-log(data2$jhu_cnty_cases_l5+0.001)
data2$jhu_cnty_cases_l6_log<-log(data2$jhu_cnty_cases_l6+0.001)
data2$jhu_cnty_cases_l7_log<-log(data2$jhu_cnty_cases_l7+0.001)
data2$jhu_cnty_cases_l8_log<-log(data2$jhu_cnty_cases_l8+0.001)
data2$jhu_cnty_cases_l9_log<-log(data2$jhu_cnty_cases_l9+0.001)
data2$jhu_cnty_cases_l10_log<-log(data2$jhu_cnty_cases_l10+0.001)
data2$jhu_cnty_cases_l11_log<-log(data2$jhu_cnty_cases_l11+0.001)
data2$jhu_cnty_cases_l12_log<-log(data2$jhu_cnty_cases_l12+0.001)
data2$jhu_cnty_cases_l13_log<-log(data2$jhu_cnty_cases_l13+0.001)
data2$jhu_cnty_cases_l14_log<-log(data2$jhu_cnty_cases_l14+0.001)

data2$jhu_state_cases_log<-log(data2$jhu_state_cases+0.001)
data2$jhu_state_cases_l1_log<-log(data2$jhu_state_cases_l1+0.001)
data2$jhu_state_cases_l2_log<-log(data2$jhu_state_cases_l2+0.001)
data2$jhu_state_cases_l3_log<-log(data2$jhu_state_cases_l3+0.001)
data2$jhu_state_cases_l4_log<-log(data2$jhu_state_cases_l4+0.001)
data2$jhu_state_cases_l5_log<-log(data2$jhu_state_cases_l5+0.001)
data2$jhu_state_cases_l6_log<-log(data2$jhu_state_cases_l6+0.001)
data2$jhu_state_cases_l7_log<-log(data2$jhu_state_cases_l7+0.001)
data2$jhu_state_cases_l8_log<-log(data2$jhu_state_cases_l8+0.001)
data2$jhu_state_cases_l9_log<-log(data2$jhu_state_cases_l9+0.001)
data2$jhu_state_cases_l10_log<-log(data2$jhu_state_cases_l10+0.001)
data2$jhu_state_cases_l11_log<-log(data2$jhu_state_cases_l11+0.001)
data2$jhu_state_cases_l12_log<-log(data2$jhu_state_cases_l12+0.001)
data2$jhu_state_cases_l13_log<-log(data2$jhu_state_cases_l13+0.001)
data2$jhu_state_cases_l14_log<-log(data2$jhu_state_cases_l14+0.001)

#Prepare local media measures
data2<-dummy_cols(data2, select_columns = c("media_local"))


#Merge
data3.1<-merge(data2, dma_owners, by.x="fips", by.y="FIPS", all.x=T, all.y=F)

#Create match variables by multiplying Sinclair stations by Viewership
data3.1$watch_ABC_Sinclair<-(data3.1$Sinclair_ABC*data3.1$media_local_ABC)
data3.1$watch_NBC_Sinclair<-(data3.1$Sinclair_NBC*data3.1$media_local_NBC)
data3.1$watch_CBS_Sinclair<-(data3.1$Sinclair_CBS*data3.1$media_local_CBS)
data3.1$watch_FOX_Sinclair<-(data3.1$Sinclair_FOX*data3.1$media_local_FOX)
data3.1$watch_Sinclair<-data3.1$watch_ABC_Sinclair+data3.1$watch_NBC_Sinclair+
                          data3.1$watch_CBS_Sinclair+data3.1$watch_FOX_Sinclair
data3.1$watch_local<-ifelse(data3.1$media_local!="I never watch local television news.", 1, 0)


#Create match variables by multiplying Nexstar stations by Viewership
data3.1$watch_ABC_Nexstar<-(data3.1$Nexstar_ABC*data3.1$media_local_ABC)
data3.1$watch_NBC_Nexstar<-(data3.1$Nexstar_NBC*data3.1$media_local_NBC)
data3.1$watch_CBS_Nexstar<-(data3.1$Nexstar_CBS*data3.1$media_local_CBS)
data3.1$watch_FOX_Nexstar<-(data3.1$Nexstar_FOX*data3.1$media_local_FOX)
data3.1$watch_Nexstar<-data3.1$watch_ABC_Nexstar+data3.1$watch_NBC_Nexstar+
  data3.1$watch_CBS_Nexstar+data3.1$watch_FOX_Nexstar



#Create match variables by multiplying Gray stations by Viewership
data3.1$watch_ABC_Gray<-(data3.1$Gray_ABC*data3.1$media_local_ABC)
data3.1$watch_NBC_Gray<-(data3.1$Gray_NBC*data3.1$media_local_NBC)
data3.1$watch_CBS_Gray<-(data3.1$Gray_CBS*data3.1$media_local_CBS)
data3.1$watch_FOX_Gray<-(data3.1$Gray_FOX*data3.1$media_local_FOX)
data3.1$watch_Gray<-data3.1$watch_ABC_Gray+data3.1$watch_NBC_Gray+
  data3.1$watch_CBS_Gray+data3.1$watch_FOX_Gray

data3<-data3.1
data3$watch_Sinclair<-ifelse(is.na(data3$watch_Sinclair),0,data3$watch_Sinclair)
data3$watch_notSinclair<-ifelse(data3$watch_local==1 & data3$watch_Sinclair==0, 1, 0)
data3$read_newspaper<-ifelse(data3$media_newspaper!="I never get my news from a newspaper", 1, 0)
data3$watch_national<-ifelse(data3$media_national!="I never watch national television news", 1, 0)
data3$watch_CNN<-ifelse(data3$media_national=="CNN", 1, 0)
data3$watch_lw<-ifelse(data3$media_national=="MSNBC", 1, data3$watch_CNN)
data3$watch_rw<-ifelse(data3$media_national=="FOX" | data3$media_national=="One America News Network", 1, 0)
data3$watch_other<-ifelse(data3$media_national=="ABC" | data3$media_national=="NBC" |
                            data3$media_national=="CBS" | data3$media_national=="PBS", 1, 0)
data3$read_NYT<-ifelse(data3$media_newspaper=="The New York Times", 1, 0)
data3$read_WSJ<-ifelse(data3$media_newspaper=="The Wall Street Journal", 1, 0)
data3$read_USA<-ifelse(data3$media_newspaper=="USA Today", 1, 0)

data3$read_local<-ifelse(data3$media_newspaper=="Local newspaper", 1, 0)
#save(data3, file="data3.RData")



#Descriptive Statistics

attach(data3)
data_summary<-as.data.frame(cbind(watch_national, watch_local, read_newspaper,
                                  read_NYT, read_WSJ, read_USA, read_local,
                                  watch_rw, watch_lw, watch_other, watch_Sinclair,
                                  watch_Nexstar, watch_Gray,risk_inf_pers_n,risk_inf_fam_friends_n,
                                  harm_pers_n, harm_family_n, harm_owncom_n, harm_ppl_US_n,
                                  jhu_cnty_cases_log, age1834, age3549, age5064, age65above, female, less_than_hs, hs,
                                  some_college_or_assdegr, ba_or_more, rural, suburban, urban,
                                  Republican, Democrat, Independent, income_low, income_lowmid, income_upmid, 
                                  income_high, unemployed, nonwhite, polknowledge_high, 
                                  coronaknowledge_high))

detach(data3)
data_summary2<-as.data.frame(matrix(nrow=43, ncol=6))
for(i in 1:43){
  data_summary2[i,1]<-names(data_summary)[i]
  data_summary2[i,2]<-min(data_summary[,i], na.rm=T)
  data_summary2[i,3]<-max(data_summary[,i], na.rm=T)
  data_summary2[i,4]<-sqrt(var(data_summary[,i], na.rm=T))
  data_summary2[i,5]<-mean(data_summary[,i], na.rm=T)
  data_summary2[i,6]<-median(data_summary[,i], na.rm=T)
}
colnames(data_summary2)<-c("Variable", "Min", "Max", "SD", "Mean", "Median")

#Table A.1
print(xtable(data_summary2, digits=2), type="html", file='data_summary2.doc', include.rownames=FALSE)










