library(diptest)
library(moments)


# This function is adapted from Beber and Scacco PA (2012)
get.digits <- function(v, pos = "last") {
  # Function to extract numerals from elements in a vector.
  # Args:
  #   v: Vector with elements from which numerals are to be extracted.
  #   pos: Position of the numeral to be extracted from each vector element.
  #     Set to "last" (the default) to get the last numeral, "penult" to
  #     extract the second-to-last digit, or a numeric value.
  # Returns:
  #   A vector containing the numerals to be retrieved.

  # Function modified by Patrick Cunha Silva to account for 2bl
  if(!pos %in% c("last", "penult", '2bl') & !is.numeric(pos)) stop("Invalid position")
  s <- strsplit(as.character(v), c())
  if(pos == "last") out <- sapply(s, function(y) y[length(y)])
  if(pos == "penult") out <- sapply(s, function(y) ifelse(length(y) < 2, NA, y[length(y) - 1]))
  if(pos == "2bl") out <- sapply(s, function(y) ifelse(length(y) < 2, NA, y[2]))
  if(is.numeric(pos)) out <- sapply(s, function(y) y[pos])
  return(as.numeric(out))
}


# Chi-Squared
chiSq <- function(digits, d.type){
    all.count <- table(digits)
    all.n <- sum(all.count)
  if(d.type == 'last'){
    nullDistr <- .1 * all.n
    all.chi <- sum((all.count - nullDistr)^2 / (.1 * all.n))
    all.pval <- 1 - pchisq(all.chi, 9)
  }else if(d.type == '2bl'){
    p.2bl <- c(.120, .114, .109, .104, .100, .097, .093, .090, .088, .085)
    nullDistr <- p.2bl * all.n
    all.chi <- sum((all.count - nullDistr)^2 / (.1 * all.n))
    all.pval <- 1 - pchisq(all.chi, 9)
  }

  return(list(chisq = all.chi, pval = all.pval))
}


# Generate Forensic Stats
forensic <- function(votes, valid, party, exD){

  votesN <- as.character(votes)
  # Remove All Single-Digit Votes
  votesN <- votesN[nchar(votesN) > exD]

  last <- get.digits(votesN, pos = 'last')
  v2bl <- get.digits(votesN, pos = '2bl')

  mLast <- t.test(last, mu = 4.5)$p.value
  m2bL <- t.test(v2bl, mu = 4.187)$p.value
  cLast <- chiSq(last, d.type = 'last')$pval
  c2bl <- chiSq(v2bl, d.type = '2bl')$pval

  # Remove precincts with less than 2 digists
  inVotes <- nchar(as.character(votes)) > exD
  votes <- votes[inVotes]
  valid <- valid[inVotes]
  dipT <- dip.test(votes/valid)$p.value
  skew <- agostino.test(votes/valid)$p.value
  kurt <- anscombe.test(votes/valid)$p.value
  
  out <- matrix(c(mLast, m2bL, cLast, c2bl
    , dipT
    , skew
    , kurt
    , sum(inVotes, na.rm = TRUE)))
  rownames(out) <- c('t-test (Last Digit)', 't-test (2bl)', 'chi-square (Last Digit)', 'chi-square (2bl)'
    , 'Dip Test'
    , 'Skewness'
    , 'Kurtosis'
    , 'N')
  colnames(out) <- party
  return(out)
}


