rm(list = ls())

# Read Data
load(file = '~/Box/Signaling Electoral Reform/ReplicationFiles/ukr_data.RData')

# Read functions used in the analysis
source('~/Box/Signaling Electoral Reform/ReplicationFiles/functions_analysis.R')
source('~/Box/Signaling Electoral Reform/ReplicationFiles/pi_delta.R')

#------------- Do the Analysis for Presidential Party ----------#

# 2002: For United Ukraine
r02 <- forensic(votes = ukr_data[['pr02']]$for_united, valid = ukr_data[['pr02']]$valid, party = 'For United Ukraine (2002)', exD = 1)
piD02 <- pi_delta(ukr_data[['pr02']]$for_united)

# 2006: Party of Regions
r06 <- forensic(votes = ukr_data[['pr06']]$pregions, valid = ukr_data[['pr06']]$valid, party = 'Party of Regions (2006)', exD = 1)
piD06 <- pi_delta(ukr_data[['pr06']]$pregions)

# 2007: Our Ukraine
r07 <- forensic(votes = ukr_data[['pr07']]$our_ukraine, valid = ukr_data[['pr07']]$valid, party = 'Our Ukraine (2007)', exD = 1)
piD07 <- pi_delta(ukr_data[['pr07']]$our_ukraine)

# 2012: Party of Region
r12smdp <- forensic(votes = ukr_data[['smdp12']]$pregions, valid = ukr_data[['smdp12']]$valid, party = 'Party of Regions, SMDP (2012)', exD = 1)
r12pr <- forensic(votes = ukr_data[['pr12']]$pregions, valid = ukr_data[['pr12']]$valid, party = 'Party of Regions, PR (2012)', exD = 1)
piD12smdp <- pi_delta(ukr_data[['smdp12']]$pregions)
piD12pr <- pi_delta(ukr_data[['pr12']]$pregions)

# 2014: Petro Poroshenko Bloc
r14smdp <- forensic(votes = ukr_data[['smdp14']]$petro, valid = ukr_data[['smdp14']]$valid, party = "Petro Poroshenko Bloc, SMDP (2014)", exD = 1)
r14pr <- forensic(votes = ukr_data[['pr14']]$petro, valid = ukr_data[['pr14']]$valid, party = "Petro Poroshenko Bloc, PR (2014)", exD = 1)
piD14smdp <- pi_delta(ukr_data[['smdp14']]$petro)
piD14pr <- pi_delta(ukr_data[['pr14']]$petro)

# 2019: Servant of the People
r19smdp <- forensic(votes = ukr_data[['smdp19']]$servant, valid = ukr_data[['smdp19']]$valid, party = 'Servant of the People, SMDP (2019)', exD = 1)
r19pr <- forensic(votes = ukr_data[['pr19']]$servant, valid = ukr_data[['pr19']]$valid, party = 'Servant of the People, PR (2019)', exD = 1)
piD19smdp <- pi_delta(ukr_data[['smdp19']]$servant)
piD19pr <- pi_delta(ukr_data[['pr19']]$servant)


# Combine results to get information for the table
all_p1 <- cbind(r02, r06, r07, r12smdp, r12pr)
all_p2 <- cbind(r14smdp, r14pr, r19smdp, r19pr)
colSums(all_p1[-8, ] < 0.05/7)
colSums(all_p2[-8, ] < 0.05/7)
round(all_p1, 3)
round(all_p2, 3)

#------------- Do the Analysis for the Winner ----------#

# 2002: For United Ukraine
r02_p <- forensic(votes = ukr_data[['pr02']]$for_united, valid = ukr_data[['pr02']]$valid, party = 'For United Ukraine (2002)', exD = 1)
piD02 <- pi_delta(ukr_data[['pr02']]$for_united)

# 2006: Party of Region
r06_p <- forensic(votes = ukr_data[['pr06']]$pregions, valid = ukr_data[['pr06']]$valid, party = 'Party of Regions (2006)', exD = 1)
piD06 <- pi_delta(ukr_data[['pr06']]$pregions)

# 2007: Party of Region
r07_p <- forensic(votes = ukr_data[['pr07']]$pregions, valid = ukr_data[['pr07']]$valid, party = 'Party of Regions (2007)', exD = 1)
piD07 <- pi_delta(ukr_data[['pr07']]$pregions)

# 2012: Party of Region
r12smdp_p <- forensic(votes = ukr_data[['smdp12']]$pregions, valid = ukr_data[['smdp12']]$valid, party = 'Party of Regions, SMDP (2012)', exD = 1)
r12pr_p <- forensic(votes = ukr_data[['pr12']]$pregions, valid = ukr_data[['pr12']]$valid, party = 'Party of Regions, PR (2012)', exD = 1)
piD12smdp <- pi_delta(ukr_data[['smdp12']]$pregions)
piD12pr <- pi_delta(ukr_data[['pr12']]$pregions)

# 2014: Petro Poroshenko Bloc
r14smdp_p <- forensic(votes = ukr_data[['smdp14']]$petro, valid = ukr_data[['smdp14']]$valid, party = "Petro Poroshenko Bloc, SMDP (2014)", exD = 1)
r14pr_p <- forensic(votes = ukr_data[['pr14']]$petro, valid = ukr_data[['pr14']]$valid, party = "Petro Poroshenko Bloc, PR (2014)", exD = 1)
piD14smdp <- pi_delta(ukr_data[['smdp14']]$petro)
piD14pr <- pi_delta(ukr_data[['pr14']]$petro)

# 2019: Servant of the People
r19smdp_p <- forensic(votes = ukr_data[['smdp19']]$servant, valid = ukr_data[['smdp19']]$valid, party = 'Servant of the People, SMDP (2019)', exD = 1)
r19pr_p <- forensic(votes = ukr_data[['pr19']]$servant, valid = ukr_data[['pr19']]$valid, party = 'Servant of the People, PR (2019)', exD = 1)
piD19smdp <- pi_delta(ukr_data[['smdp19']]$servant)
piD19pr <- pi_delta(ukr_data[['pr19']]$servant)

# Combine results to get information for the table
all_p1 <- cbind(r02_p, r06_p, r07_p, r12smdp_p, r12pr_p)
all_p2 <- cbind(r14smdp_p, r14pr_p, r19smdp_p, r19pr_p)
colSums(all_p1[-8, ] < 0.05/7)
colSums(all_p2[-8, ] < 0.05/7)
round(all_p1, 3)
round(all_p2, 3)


#------------- Do the Analysis for Runner-Up ----------#

# 2002: Our Ukraine
r02_s <- forensic(votes = ukr_data[['pr02']]$our_ukraine, valid = ukr_data[['pr02']]$valid, party = 'Our Ukraine (2002)', exD = 1)
piD02 <- pi_delta(ukr_data[['pr02']]$our_ukraine)

# 2006: Yulia Tymoshenko Bloc
r06_s <- forensic(votes = ukr_data[['pr06']]$yulia, valid = ukr_data[['pr06']]$valid, party = 'Yulia Tymoshenko Bloc (2006)', exD = 1)
piD06 <- pi_delta(ukr_data[['pr06']]$yulia)

# 2007: Yulia Tymoshenko Bloc
r07_s <- forensic(votes = ukr_data[['pr07']]$yulia, valid = ukr_data[['pr07']]$valid, party = 'Yulia Tymoshenko Bloc (2007)', exD = 1)
piD07 <- pi_delta(ukr_data[['pr07']]$yulia)

# 2012: Fatherland (including United Opposition)
r12smdp_s <- forensic(votes = ukr_data[['smdp12']]$fatherland, valid = ukr_data[['smdp12']]$valid, party = 'Fatherland, SMDP (2012)', exD = 1)
r12pr_s <- forensic(votes = ukr_data[['pr12']]$fatherland, valid = ukr_data[['pr12']]$valid, party = 'Fatherland, PR (2012)', exD = 1)
piD12smdp <- pi_delta(ukr_data[['smdp12']]$fatherland)
piD12pr <- pi_delta(ukr_data[['pr12']]$fatherland)

# 2014: People's Front
r14smdp_s <- forensic(votes = ukr_data[['smdp14']]$people_front, valid = ukr_data[['smdp14']]$valid, party = "People's Front, SMDP (2014)", exD = 1)
r14pr_s <- forensic(votes = ukr_data[['pr14']]$people_front, valid = ukr_data[['pr14']]$valid, party = "People's Front, SMDP (2014)", exD = 1)
piD14smdp <- pi_delta(ukr_data[['smdp14']]$people_front)
piD14pr <- pi_delta(ukr_data[['pr14']]$people_front)


# 2019: Opposition Platform — For Life
r19smdp_s <- forensic(votes = ukr_data[['smdp19']]$opposition, valid = ukr_data[['smdp19']]$valid, party = 'Opposition Platform — For Life, SMDP (2019)', exD = 1)
r19pr_s <- forensic(votes = ukr_data[['pr19']]$opposition, valid = ukr_data[['pr19']]$valid, party = 'Opposition Platform — For Life, PR (2019)', exD = 1)
piD19smdp <- pi_delta(ukr_data[['smdp19']]$opposition)
piD19pr <- pi_delta(ukr_data[['pr19']]$opposition)

# Combine results to get information for the table
all_p1 <- cbind(r02_s, r06_s, r07_s, r12smdp_s, r12pr_s)
all_p2 <- cbind(r14smdp_s, r14pr_s, r19smdp_s, r19pr_s)
colSums(all_p1[-8, ] < 0.05/7)
colSums(all_p2[-8, ] < 0.05/7)
round(all_p1, 3)
round(all_p2, 3)


#------------- Do the Analysis for Turnout ----------#
# We use valid = the number of registered voters 
# and votes = turnout, when analyzing turnout data.

# 2002: Turnout
r02_t <- forensic(votes = ukr_data[['pr02']]$turnout, valid = ukr_data[['pr02']]$nvoters, party = 'Turnout (2002)', exD = 1)
piD02tur <- pi_delta(ukr_data[['pr02']]$turnout)

# 2006: Turnout
r06_t <- forensic(votes = ukr_data[['pr06']]$turnout, valid = ukr_data[['pr06']]$nvoters, party = 'Turnout (2007)', exD = 1)
piD06tur <- pi_delta(ukr_data[['pr06']]$turnout)

# 2007: Turnout
r07_t <- forensic(votes = ukr_data[['pr07']]$turnout, valid = ukr_data[['pr07']]$nvoters, party = 'Turnout (2007)', exD = 1)
piD07tur <- pi_delta(ukr_data[['pr07']]$turnout)

# 2012: Turnout
r12smdp_t <- forensic(votes = ukr_data[['smdp12']]$turnout, valid = ukr_data[['smdp12']]$nvoters, party = 'Turnout (2012)', exD = 1)
piD12tur_smdp <- pi_delta(ukr_data[['smdp12']]$turnout)
r12pr_t <- forensic(votes = ukr_data[['pr12']]$turnout, valid = ukr_data[['pr12']]$nvoters, party = 'Turnout (2012), PR', exD = 1)
piD12tur_pr <- pi_delta(ukr_data[['pr12']]$turnout)

# 2014: Turnout
r14smdp_t <- forensic(votes = ukr_data[['smdp14']]$turnout, valid = ukr_data[['smdp14']]$nvoters, party = 'Turnout (2014)', exD = 1)
piD14tur_smdp <- pi_delta(ukr_data[['smdp14']]$turnout)
r14pr_t <- forensic(votes = ukr_data[['pr14']]$turnout, valid = ukr_data[['pr14']]$nvoters, party = 'Turnout (2014), PR', exD = 1)
piD14tur_pr <- pi_delta(ukr_data[['pr14']]$turnout)

# 2019: Turnout
r19smdp_t <- forensic(votes = ukr_data[['smdp19']]$turnout, valid = ukr_data[['smdp19']]$nvoters, party = 'Turnout (2019)', exD = 1)
piD19tur_smd <- pi_delta(ukr_data[['smdp19']]$turnout)
r19pr_t <- forensic(votes = ukr_data[['pr19']]$turnout, valid = ukr_data[['pr19']]$nvoters, party = 'Turnout (2019), PR', exD = 1)
piD19tur_pr <- pi_delta(ukr_data[['pr19']]$turnout)

# Combine Results to Generate a Table
all_p1 <- cbind(r02_t, r06_t, r07_t, r12smdp_t, r12pr_t)
all_p2 <- cbind(r14smdp_t, r14pr_t, r19smdp_t, r19pr_t)
colSums(all_p1[-8, ] < 0.05/7)
colSums(all_p2[-8, ] < 0.05/7)
round(all_p1, 3)
round(all_p2, 3)
