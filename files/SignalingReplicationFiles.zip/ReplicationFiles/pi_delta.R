# This code combines Medzihorsky PA (2017) replication code into one function

# Install pistar if needed.
# install.packages("remotes")
# remotes::install_github("jmedzihorsky/pistar")

pi_delta <- function(votes){

	votes <- as.character(votes)
	votes <- votes[nchar(votes)> 1]
	votes <- get.digits(votes, pos = 'last')
	data <- table(votes)

	library(pistar)

	univar.stats <- function(x, pvalsims=1e6){
	        n <- sum(x)
	        o <- x/n
	        e <- rep(1e-1, 1e1)
	        s_c <- n*sum( ((o-e)^2)/e ) 
	        s_p <- 1 - 1/max(e/o)
	        s_t <- sum(abs(x-mean(x)))/(2*sum(x))
	        S <- t(rmultinom(pvalsims, n, e))/n
	        d_c <- apply(S, 1, function(i) n*sum( ((i-e)^2)/e ))
	        d_p <- apply(S, 1, function(i) 1 - 1/max(e/i))
	        d_t <- apply(S, 1, function(i) sum(abs(i-mean(i))))/2        
	        p_c <- 1 - sum(d_c <= s_c)/pvalsims
	        p_p <- 1 - sum(d_p <= s_p)/pvalsims
	        p_t <- 1 - sum(d_t <= s_t)/pvalsims
	        return(c(s_c, p_c, s_p, p_p, s_t, p_t))
	    }    

	u_res <- univar.stats(data)
	u_sum <- sum(data)
	u_tab <- c(u_sum, u_res)
	names(u_tab) <- c('N', 'chi2', 'p(chi2)', 'pi*', 'p(pi*)', 'Delta', 'p(Delta)')
	u_tab[4] <- 1e2*u_tab[4]
	u_tab[6] <- 1e2*u_tab[6]
	u_tab <- u_tab[-c(5, 7)]



	#   Jackknife for pi* and Delta    

	#   A function for jackknife resamples
	jacksamp <-function(x){
	        af <- function(i){ x[i] <- x[i]-1 ; return(x) } 
	        l <- lapply(1:length(x), af)
	        return(l)
	    }

	#   Obtain the resamples of data_list
	jack_out <-  jacksamp(data)

	#   Simple functions for Delta and pi*
	gd <- function(i) sum(abs(i-mean(i)))/(2*sum(i))
	gp <- function(i) 1 - 1/max(mean(i)/i)
	jack.pistar <- function(x) { unlist(lapply(x, gp)) }
	jack.delta <- function(x) { unlist(lapply(x, gd)) }
	#   apply them
	est_pistar <- gp(data)
	est_delta <- gd(data)
	jack_pistar <- jack.pistar(jack_out)
	jack_delta <- jack.delta(jack_out)

	#   Pool the jackknife estimates
	pooler <-function(i, ld=data, le=est_delta, lj=jack_delta)
	    {
	        p <- pool.jack(data=ld, ct=T, estimate=le,
	                       jack_est=lj, lower=0, upper=1)
	        return(c(le, p$low, p$upp))
	    }


	pool_pistar <- t(vapply(1, FUN=pooler, le=est_pistar,
	                        lj=jack_pistar, FUN.VALUE=numeric(3)))
	pool_delta <- t(vapply(1, FUN=pooler, le=est_delta,
	                       lj=jack_delta, FUN.VALUE=numeric(3)))

	#   Prepare to export
	out <- c(u_tab[1], round(u_tab[4], 3), round(1e2*pool_pistar[2:3], 2),
	      round(u_tab[5], 3), round(1e2*pool_delta[2:3], 2))
	names(out) <- c('N', 'pi*', 'lb', 'ub', 'Delta', 'lb', 'ub')
	return(out)
}
