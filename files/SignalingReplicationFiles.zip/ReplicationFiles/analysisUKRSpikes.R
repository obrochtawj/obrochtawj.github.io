rm(list = ls())

library(spikes)

# We only use data for precincts where the analyzed party received 
# at least 10 votes

# Note this code takes a long time to run.

# Read Data
load(file = '~/Box/Signaling Electoral Reform/ReplicationFiles/ukr_data.RData')


set.seed(888)
# 2002: For United Ukraine
pr02 <- ukr_data[['pr02']]
pr02 <- pr02[pr02$for_united > 9, c('nvoters', 'turnout', 'for_united')]
names(pr02) <- c('N', 't', 'v')
pr02 <-spikes(pr02)

# 2006: Party of Regions
pr06 <- ukr_data[['pr06']]
pr06 <- pr06[pr06$pregions > 9, c('nvoters', 'turnout', 'pregions')]
names(pr06) <- c('N', 't', 'v')
pr06 <-spikes(pr06)

# 2007: Our Ukraine
pr07 <- ukr_data[['pr07']]
pr07 <- pr07[pr07$our_ukraine > 9, c('nvoters', 'turnout', 'our_ukraine')]
names(pr07) <- c('N', 't', 'v')
pr07 <-spikes(pr07)

# 2012: Party of Region
smdp12 <- ukr_data[['smdp12']]
pr12 <- ukr_data[['pr12']]
smdp12 <- na.omit(smdp12[smdp12$pregions > 9, c('nvoters', 'turnout', 'pregions')])
pr12 <- pr12[pr12$pregions > 9, c('nvoters', 'turnout', 'pregions')]
names(smdp12) <- c('N', 't', 'v')
rsmdp12 <-spikes(smdp12)
names(pr12) <- c('N', 't', 'v')
rpr12 <-spikes(pr12)


# 2014: Petro Poroshenko Bloc
smdp14 <- ukr_data[['smdp14']]
pr14 <- ukr_data[['pr14']]
smdp14 <- na.omit(smdp14[smdp14$petro > 9, c('nvoters', 'turnout', 'petro')])
pr14 <- pr14[pr14$petro > 9, c('nvoters', 'turnout', 'petro')]
names(smdp14) <- c('N', 't', 'v')
rsmdp14 <-spikes(smdp14)
names(pr14) <- c('N', 't', 'v')
rpr14 <-spikes(pr14)


# 2019
smdp19 <- ukr_data[['smdp19']]
pr19 <- ukr_data[['pr19']]
smdp19 <- smdp19[smdp19$servant > 9, c('nvoters', 'turnout', 'servant')]
pr19 <- pr19[pr19$servant > 9, c('nvoters', 'turnout', 'servant')]
names(smdp19) <- c('N', 't', 'v')
rsmdp19 <-spikes(smdp19)
names(pr19) <- c('N', 't', 'v')
rpr19 <-spikes(pr19)

# Save the results
spikesResults <- list(pr02,
	pr06,
	pr07,
	rsmdp12,
	rpr12,
	rsmdp14,
	rpr14,
	rsmdp19,
	rpr19)
save(spikesResults, file = '~/Box/Signaling Electoral Reform/ReplicationFiles/spikesResults.RData')

# Load results
load(file = '~/Box/Signaling Electoral Reform/ReplicationFiles/spikesResults.RData')

# Compute CI. This takes a long time to run. 
set.seed(888)
# 2002
ci02 <- confInt(spikesResults[[1]])
# 2006
ci06 <- confInt(spikesResults[[2]])
# 2007
ci07 <- confInt(spikesResults[[3]])
# 2012, SMD
ci12smd <- confInt(spikesResults[[4]])
# 2012, PR
ci12pr <- confInt(spikesResults[[5]])
# 2014, SMD
ci14smd <- confInt(spikesResults[[6]])
# 2014, PR
ci14pr <- confInt(spikesResults[[7]])
# 2019, SMD
ci19smd <- confInt(spikesResults[[8]])
# 2019, PR
ci19pr <- confInt(spikesResults[[9]])

spikesResultsCI <- list(ci02, ci06, ci07, ci12smd, ci12pr,
	ci14smd, ci14pr, ci19smd, ci19pr)
save(spikesResultsCI, file = '~/Box/Signaling Electoral Reform/ReplicationFiles/spikesResultsCI.RData')
# load results
load(file = '~/Box/Signaling Electoral Reform/ReplicationFiles/spikesResultsCI.RData')


# Get the estimates
summary(spikesResultsCI[[1]])
summary(spikesResultsCI[[2]])
summary(spikesResultsCI[[3]])
summary(spikesResultsCI[[4]])
summary(spikesResultsCI[[5]])
summary(spikesResultsCI[[6]])
summary(spikesResultsCI[[7]])
summary(spikesResultsCI[[8]])
summary(spikesResultsCI[[9]])

