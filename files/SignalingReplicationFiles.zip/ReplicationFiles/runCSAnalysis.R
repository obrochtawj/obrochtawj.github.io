rm(list = ls())

# Load Libraries
library(brms)
library(lfe)
library(stargazer)


# Load Data
load(file = '~/Box/Signaling Electoral Reform/ReplicationFiles/elecReform.RData')

# Run Main Model
m1 <- brm(nelda47 ~ reformTypeF
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct
	+ eu
	+ urban
	+ ef_index
	+ v2mecenefm # censorship
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, iter = 2000)

#------- Generate Table 1 (We report the median value of the distribution)
# Predicted Probablity
posterior <- data.frame(m1)
values <- Reduce('rbind', lapply(posterior[,1:13], quantile, probs = c(0.025, 0.5, 0.975)))
toTable <- matrix(NA, nrow = 13, ncol = 2)
toTable[,1] <- round(values[, 2], 3)
toTable[,2] <- sapply(1:13, function(i) paste0('[', round(values[i, 1], 3), '; ', round(values[i, 3], 3), ']'))
toTable <- rbind(toTable, c(NA, length(unique(model.frame(m1)$country_name))))
toTable <- rbind(toTable, c(NA, length(model.frame(m1)$country_name)))
rownames(toTable) <- c('Intercept'
		, 'More Proportional'
		, 'Less Proportional'
		, 'EMB - Autonomy'
		, 'EMB - Capacity'
		, 'Polity 2'
		, 'GDP per capita (log)'
		, 'Oil (% of GDP)'
		, 'EU'
		, 'Urbanization'
		, 'Ethnic Fractionalization'
		, 'Government Censorship Effort'
		, 'sigma'
		, 'countries'
		, 'N'
	)
stargazer(toTable)
values <- Reduce('rbind', lapply(posterior[,1:13], quantile, probs = c(0.025, 0.5, 0.975)))
rownames(values) <- colnames(posterior[,1:13])
round(values, 3)

#------- Generate Figure 1 -------#


# Generate XValues
xValuesNoR <- data.frame(Intercept = 1 
		, MoreProp = 0
		, LessProp = 0
		, v2elembaut = mean(model.frame(m1)$v2elembaut)
		, v2elembcap = mean(model.frame(m1)$v2elembcap)
		, e_polity2 = mean(model.frame(m1)$e_polity2)
		, e_migdppcln = mean(model.frame(m1)$e_migdppcln)
		, oil_gdp_pct = mean(model.frame(m1)$oil_gdp_pct)
		, eu = mean(model.frame(m1)$eu)		
		, urban = mean(model.frame(m1)$urban)
		, ef_index = mean(model.frame(m1)$ef_index)
		, v2mecenefm = mean(model.frame(m1)$v2mecenefm)
		)
xValuesMorePr <- data.frame(Intercept = 1 
		, MoreProp = 1
		, LessProp = 0
		, v2elembaut = mean(model.frame(m1)$v2elembaut)
		, v2elembcap = mean(model.frame(m1)$v2elembcap)
		, e_polity2 = mean(model.frame(m1)$e_polity2)
		, e_migdppcln = mean(model.frame(m1)$e_migdppcln)
		, oil_gdp_pct = mean(model.frame(m1)$oil_gdp_pct)
		, eu = mean(model.frame(m1)$eu)					
		, urban = mean(model.frame(m1)$urban)
		, ef_index = mean(model.frame(m1)$ef_index)
		, v2mecenefm = mean(model.frame(m1)$v2mecenefm)
		)	
xValuesLessPr <- data.frame(Intercept = 1 
		, MoreProp = 0
		, LessProp = 1
		, v2elembaut = mean(model.frame(m1)$v2elembaut)
		, v2elembcap = mean(model.frame(m1)$v2elembcap)
		, e_polity2 = mean(model.frame(m1)$e_polity2)
		, e_migdppcln = mean(model.frame(m1)$e_migdppcln)
		, oil_gdp_pct = mean(model.frame(m1)$oil_gdp_pct)
		, eu = mean(model.frame(m1)$eu)					
		, urban = mean(model.frame(m1)$urban)
		, ef_index = mean(model.frame(m1)$ef_index)
		, v2mecenefm = mean(model.frame(m1)$v2mecenefm)
		)		
coefMore <- names(posterior)[c(1:12)]
linearPred01 <- as.matrix(posterior[, coefMore]) %*% t(xValuesNoR)
linearPred02 <- as.matrix(posterior[, coefMore]) %*% t(xValuesMorePr)
linearPred03 <- as.matrix(posterior[, coefMore]) %*% t(xValuesLessPr)
probsim01 <- exp(linearPred01)/(1 + exp(linearPred01))
probsim02 <- exp(linearPred02)/(1 + exp(linearPred02))
probsim03 <- exp(linearPred03)/(1 + exp(linearPred03))

q1 <- quantile(probsim01, probs = c(0.025, 0.05, 0.5, 0.95, 0.975))
q2 <- quantile(probsim02, probs = c(0.025, 0.05, 0.5, 0.95, 0.975))
q3 <- quantile(probsim03, probs = c(0.025, 0.05, 0.5, 0.95, 0.975))
round(q1, 3)
round(q2, 3)
round(q3, 3)

par(mar = c(4, 5, 1, 1))
plot(y = c(q1[3], q2[3], q3[3]), x = c(1, 1.25, 1.5)
	, xlim = c(0.9, 1.60)
	, ylim = c(0, 1)
	, pch = 20
	, axes = FALSE
	, ylab = 'Probability of Reporting Vote Fraud'
	, xlab = ''
	, cex = 2
	, cex.lab = 1.25)
lines(x = c(1, 1), y = c(q1[1], q1[5]), lwd = 1.5)
lines(x = c(1, 1), y = c(q1[2], q1[4]), lwd = 4.5)
lines(x = c(1.25, 1.25), y = c(q2[1], q2[5]), lwd = 1.5)
lines(x = c(1.25, 1.25), y = c(q2[2], q2[4]), lwd = 4.5)
lines(x = c(1.5, 1.5), y = c(q3[1], q3[5]), lwd = 1.5)
lines(x = c(1.5, 1.5), y = c(q3[2], q3[4]), lwd = 4.5)
axis(1, at = c(1, 1.25, 1.5), labels = c('No Reform'
	, 'More Prop'
	, 'Less Prop'), tick = FALSE, cex.axis = 1.25)
axis(2, cex.axis = 1.25, las = 2)
legend('topleft', legend = c('90% CI', '95% CI')
	, lty = c(1, 1)
	, lwd = c(4.5, 1.5)
	, bty = 'n')
dev.off()

#------- Generate Figure C.1 -------#
q1 <- quantile(probsim02 - probsim01, probs = c(0.025, 0.05, 0.5, 0.95, 0.975))
q2 <- quantile(probsim03 - probsim01, probs = c(0.025, 0.05, 0.5, 0.95, 0.975))
q3 <- quantile(probsim03 - probsim02, probs = c(0.025, 0.05, 0.5, 0.95, 0.975))
par(mar = c(4, 12, 1, 1))
plot(y = c(q1[3], q2[3], q3[3]), x = c(1, 1.25, 1.5)
	, xlim = c(0.9, 1.60)
	, ylim = c(-0.8, 0.8)
	, las = 2
	, pch = 20
	, axes = FALSE
	, ylab = ''
	, xlab = ''
	, cex = 2
	, cex.lab = 1.25)

text(x = 0.72,
     y = 0,
     labels = "Change in the\nProbability\nof Reporting\nVote Fraud",
     xpd = NA,
     cex = 1.4)
lines(x = c(1, 1), y = c(q1[1], q1[5]), lwd = 1.5)
lines(x = c(1, 1), y = c(q1[2], q1[4]), lwd = 4.5)
lines(x = c(1.25, 1.25), y = c(q2[1], q2[5]), lwd = 1.5)
lines(x = c(1.25, 1.25), y = c(q2[2], q2[4]), lwd = 4.5)
lines(x = c(1.5, 1.5), y = c(q3[1], q3[5]), lwd = 1.5)
lines(x = c(1.5, 1.5), y = c(q3[2], q3[4]), lwd = 4.5)
axis(1, at = c(1, 1.25, 1.5), labels = c('More Proportional \n - No Reform'
	, 'Less Proportional \n- No Reform'
	, 'Less Proportional \n- More Proportional '), tick = FALSE, cex.axis = 1.25)
axis(2, at = c(-0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8), cex.axis = 1.25, las = 2)
abline(h = 0, lty = 2)
legend('topleft', legend = c('90% CI', '95% CI')
	, lty = c(1, 1)
	, lwd = c(4.5, 1.5)
	, bty = 'n')
dev.off()
#----------- Robustness Checks -------------#

# Pooled LPM
pooled <- felm(nelda47 ~ reformTypeF
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct	
	+ eu	
	+ urban
	+ ef_index
	+ v2mecenefm
	, data = elecReform)
summary(pooled)

# LPM with FE
fe <- felm(nelda47 ~  reformTypeF
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct	
	+ eu		
	+ urban
	+ ef_index
	+ v2mecenefm
	| country_name
	, data = elecReform)
summary(fe)

# Pooled Logit
pooledLogit <- glm(nelda47 ~ 
	 reformTypeF
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct	
	+ eu	
	+ urban
	+ ef_index
	+ v2mecenefm
	, family = 'binomial'	
	, data = elecReform)
summary(pooledLogit)



# Logit with FE
feLogit <- glm(nelda47 ~ reformTypeF
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct	
	+ eu	
	+ urban
	+ ef_index
	+ v2mecenefm
	+ as.factor(country_name)
	, family = 'binomial'	
	, data = elecReform)
summary(feLogit)

# LDV Logit
pooledLDV <- glm(nelda47 ~ 
	 reformTypeF
	+ nelda47Lag
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct	
	+ eu		
	+ urban
	+ ef_index
	+ v2mecenefm
	, family = 'binomial'	
	, data = elecReform)
summary(pooledLDV)

stargazer::stargazer(pooled, fe, pooledLogit, feLogit, pooledLDV
	, covariate.labels = c('More Proportional'
		, 'Less Proportional'
		, 'Lag DV'
		, 'EMB - Autonomy'
		, 'EMB - Capacity'
		, 'Polity 2'
		, 'GDP per capita (log)'
		, 'Oil (% of GDP)'		
		, 'EU'
		, 'Urbanization'
		, 'Ethnic Fractionalization'
		, 'Government Censorship Effort'
	)
	, omit = c('country')
	, column.labels = c('Pooled (LPM)', 'Country FE (LPM)', 'Pooled (Logit)', 'Country FE (Logit)', 'LDV (Logit)')
	, no.space = TRUE
	, omit.stat = c('ser', 'f')
	, star.cutoffs = c(0.1, 0.05, 0.01)
	, title = 'Association Between Electoral Reform and Fraud Detection'
	, label = 't:NELDARobs'
)

# Ran Model with post-treatment
m2 <- brm(nelda47 ~ reformTypeF
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln	
	+ oil_gdp_pct
	+ eu
	+ urban
	+ ef_index
	+ v2mecenefm # censorship
	+ nelda33
	+ nelda24
	+ v2elvotbuy # Election vote buying
	+ v2elirreg # Election other voting irregularities
	+ v2elintim # Election government intimidation
	+ v2elfrfair # Election fairness	
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, iter = 2000)
summary(m2)

#------- Generate Table 
# Predicted Probablity
posterior <- data.frame(m2)
values <- Reduce('rbind', lapply(posterior[,1:19], quantile, probs = c(0.025, 0.5, 0.975)))
toTable <- matrix(NA, nrow = 19, ncol = 2)
toTable[,1] <- round(values[, 2], 3)
toTable[,2] <- sapply(1:19, function(i) paste0('[', round(values[i, 1], 3), '; ', round(values[i, 3], 3), ']'))
toTable <- rbind(toTable, c(NA, length(unique(model.frame(m2)$country_name))))
toTable <- rbind(toTable, c(NA, length(model.frame(m2)$country_name)))
rownames(toTable) <- c('Intercept'
		, 'More Proportional'
		, 'Less Proportional'
		, 'EMB - Autonomy'
		, 'EMB - Capacity'
		, 'Polity 2'
		, 'GDP per capita (log)'
		, 'Oil (% of GDP)'	
		, 'EU'		
		, 'Urbanization'
		, 'Ethnic Fractionalization'
		, 'Government Censorship Effort'
		, 'Electoral Violence'
		, 'Incumbent Lost'
		, 'Vote Buying'
		, 'Other Voting Irregularities'
		, 'Government Intimidation'
		, 'Election Fairness'
		, 'sigma'
		, 'countries'
		, 'N'
	)
stargazer(toTable)

#----------- Additional Robustness Checks -------------#

# No Controls
m.noControls <- brm(nelda47 ~ reformTypeF
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, control = list(adapt_delta = 0.95)
	, iter = 2000)
posterior <- data.frame(m.noControls)
values <- Reduce('rbind', lapply(posterior[,1:4], quantile, probs = c(0.025, 0.5, 0.975)))
rownames(values) <- colnames(posterior[,1:4])
round(values, 3)
# 90% CI
values <- Reduce('rbind', lapply(posterior[,1:4], quantile, probs = c(0.05, 0.5, 0.95)))
rownames(values) <- colnames(posterior[,1:4])
round(values, 3)

# Socio-economic
m.SocioEco <- brm(nelda47 ~ reformTypeF
	+ e_migdppcln
	+ oil_gdp_pct
	+ urban
	+ ef_index
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, control = list(adapt_delta = 0.95)
	, iter = 2000)
posterior <- data.frame(m.SocioEco)
values <- Reduce('rbind', lapply(posterior[,1:8], quantile, probs = c(0.025, 0.5, 0.975)))
rownames(values) <- colnames(posterior[,1:8])
round(values, 3)
# 90% CI
values <- Reduce('rbind', lapply(posterior[,1:8], quantile, probs = c(0.05, 0.5, 0.95)))
rownames(values) <- colnames(posterior[,1:8])
round(values, 3)


# Regime 
m.Reg <- brm(nelda47 ~ reformTypeF
    + e_polity2	
    + v2mecenefm # censorship	
    + eu
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, control = list(adapt_delta = 0.95)
	, iter = 2000)
posterior <- data.frame(m.Reg)
values <- Reduce('rbind', lapply(posterior[,1:7], quantile, probs = c(0.025, 0.5, 0.975)))
rownames(values) <- colnames(posterior[,1:7])
round(values, 3)
# 90% CI
values <- Reduce('rbind', lapply(posterior[,1:7], quantile, probs = c(0.05, 0.5, 0.95)))
rownames(values) <- colnames(posterior[,1:7])
round(values, 3)

# EMB 
m.EMB <- brm(nelda47 ~ reformTypeF
    + v2elembaut	
    + v2elembcap 
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, control = list(adapt_delta = 0.95)
	, iter = 2000)
posterior <- data.frame(m.EMB)
values <- Reduce('rbind', lapply(posterior[,1:6], quantile, probs = c(0.025, 0.5, 0.975)))
rownames(values) <- colnames(posterior[,1:6])
round(values, 3)
values <- Reduce('rbind', lapply(posterior[,1:6], quantile, probs = c(0.05, 0.5, 0.95)))
rownames(values) <- colnames(posterior[,1:6])
round(values, 3)

#------ Alternative Coding Scheme
m3 <- brm(nelda47 ~ reformTypeComp
	+ v2elembaut
	+ v2elembcap
	+ e_polity2
	+ e_migdppcln
	+ oil_gdp_pct
	+ eu
	+ urban
	+ ef_index
	+ v2mecenefm # censorship
	+ (1| country_name)
	, thin = 1
	, data = elecReform
	, seed = 888
	, family = 'bernoulli'
	, chains = 4
	, cores = 4
	, iter = 2000)
posterior <- data.frame(m3)
values <- Reduce('rbind', lapply(posterior[,1:15], quantile, probs = c(0.025, 0.5, 0.975)))
rownames(values) <- colnames(posterior[,1:15])
round(values, 3)

#----------- Descriptive Stats -------------#
stargazer(na.omit(elecReform[, c('nelda47'
			, 'v2elembaut'
			, 'v2elembcap'
			, 'e_polity2'
			, 'e_migdppcln'
			, 'oil_gdp_pct'
			, 'eu'
			, 'urban'
			, 'ef_index'
			, 'v2mecenefm'
			)])
, covariate.labels = c('Vote Fraud Reported'
	, 'EMB Autonomy'
	, 'EMB Capacity'
	, 'Polity 2'
	, 'GDP per capita (log)'
	, 'Oil (% of GDP)'
	, 'European Union'
	, 'Urbanization'
	, 'Ethnic Fractionalization'
	, 'Government Censorship Effort'))


