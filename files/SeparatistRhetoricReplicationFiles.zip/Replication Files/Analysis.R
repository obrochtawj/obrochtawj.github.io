#################################################################################
### Public Discourse About Autonomous Regions and De Facto States             ###
### William O'Brochta                                                         ###
### Texas Lutheran University                                                 ###
#################################################################################

library(tm)
library(stringr)
library(plyr)
library(topicmodels)
library(ldatuning)
library(xtable)

#Function to count positive-negative words and return score
score.sentiment=function(sentences,pos.words,neg.words,.progress='none'){
  require(plyr)
  require(stringr)
  scores = laply(sentences, function(sentence,pos.words,neg.words){
    
    sentence = gsub('[[:punct:]]','',sentence)
    sentence = gsub('[[:cntrl:]]','',sentence)
    sentence = gsub('\\d+','',sentence)
    sentence = tolower(sentence)
    
    word.list = str_split(sentence, '\\s+')
    words = unlist(word.list)
    
    pos.matches = match(words, pos.words)
    neg.matches = match(words, neg.words)
    
    pos.matches = !is.na(pos.matches)
    neg.matches = !is.na(neg.matches)
    
    score = sum(pos.matches)-sum(neg.matches)
    
    return(score)
  }, pos.words,neg.words, .progress=.progress)
  
  scores.df = data.frame(scores=scores, text=sentences)
  return(scores.df)
}

nwords <- function(string, pseudo=F){
  ifelse( pseudo, 
          pattern <- "\\S+", 
          pattern <- "[[:alpha:]]+" 
  )
  str_count(string, pattern)
}

#Import positive and negative words from Hu and Liu.
pos.words <-scan('pos_words.txt',what='character',comment.char=';')
neg.words <-scan('neg_words.txt',what='character',comment.char=';')



#Adjara
adjara<- read.csv('data_adjara.csv', header=T, stringsAsFactors = F)
#Remove punctuation and characters and make lowercase for both text and title.
adjara[,5]<-laply(adjara[,5], function(sentence){
  sentence = gsub('[[:punct:]]','',sentence)
  sentence = gsub('[[:cntrl:]]','',sentence)
  sentence = gsub('\\d+','',sentence)
  sentence = tolower(sentence)
})
adjara[,4]<-laply(adjara[,4], function(sentence){
  sentence = gsub('[[:punct:]]','',sentence)
  sentence = gsub('[[:cntrl:]]','',sentence)
  sentence = gsub('\\d+','',sentence)
  sentence = tolower(sentence)
})
adjara$Date<-as.Date(adjara$Date,format="%d %b. '%y")
#Search for words mentioning autonomy.
adjara_autonomy<-adjara[grepl("autonomy",adjara[,5], ignore.case = T) | grepl("autonomy",adjara[,4], ignore.case = T) |
                        grepl("separatis",adjara[,5], ignore.case = T) | grepl("separatis",adjara[,4], ignore.case = T) |
                        grepl("breakaway",adjara[,5], ignore.case = T) | grepl("breakaway",adjara[,4], ignore.case = T) , ]
#Get articles not mentioning autonomy
adjara_not<-setdiff(adjara$Text,adjara_autonomy$Text)
adjara_not <- rbind(adjara, adjara_autonomy)
adjara_not <-adjara_not[! duplicated(adjara_not, fromLast=TRUE) & seq(nrow(adjara_not)) <= nrow(adjara), ]

#Score the two corpuses.
adjara_autonomy_score <- score.sentiment(adjara_autonomy[,5],pos.words,neg.words, .progress='text')
adjara_not_score <- score.sentiment(adjara_not[,5],pos.words,neg.words, .progress='text')

#Add the scores to the data frames
adjara_autonomy$score<-adjara_autonomy_score$scores
adjara_not$score<-adjara_not_score$scores

#Get overall difference in mean scores.
sum(adjara_autonomy_score$scores)/nrow(adjara_autonomy_score)
sum(adjara_not_score$scores)/nrow(adjara_not_score)

#Collapse to yearly score sums.
adjara_autonomy_year<-aggregate(score ~ format(Date,"%y"), sum, data = adjara_autonomy)
adjara_not_year<-aggregate(score ~ format(Date,"%y"), sum, data = adjara_not)

adjara_autonomy$year<-as.numeric(format(adjara_autonomy$Date,"%y"))
adjara_not$year<-as.numeric(format(adjara_not$Date,"%y"))

#Get word frequency to compare.
adjara_freq<-as.matrix(TermDocumentMatrix((Corpus(VectorSource(adjara_autonomy[,5])))) )
adjara_freqMat<-data.frame(ST=rownames(adjara_freq),Freq=rowSums(adjara_freq),row.names=NULL)
adjara_freqMat<-adjara_freqMat[order(-adjara_freqMat$Freq),]
adjara_freqMat$pct<-100*(adjara_freqMat$Freq/sum(adjara_freqMat$Freq))

adjara_not_freq<-as.matrix(TermDocumentMatrix((Corpus(VectorSource(adjara_not[,5])))) )
adjara_not_freqMat<-data.frame(ST=rownames(adjara_not_freq),Freq=rowSums(adjara_not_freq),row.names=NULL)
adjara_not_freqMat<-adjara_not_freqMat[order(-adjara_not_freqMat$Freq),]
adjara_not_freqMat$pct<-100*(adjara_not_freqMat$Freq/sum(adjara_not_freqMat$Freq))

#Count number of words
adjara_autonomy$word_count<-lapply(adjara_autonomy[,5],nwords)
adjara_autonomy$word_count<-as.numeric(adjara_autonomy$word_count)
adjara_autonomy_words_year<-aggregate(word_count ~ format(Date,"%y"), sum, data = adjara_autonomy)
adjara_autonomy_words_year<-rbind(adjara_autonomy_words_year, c(17,0))
adjara_not$word_count<-lapply(adjara_not[,5],nwords)
adjara_not$word_count<-as.numeric(adjara_not$word_count)
adjara_not_words_year<-aggregate(word_count ~ format(Date,"%y"), sum, data = adjara_not)




#Abkhazia
abkhazia<- read.csv('data_abkhazia.csv', header=T, stringsAsFactors = F)
abkhazia[,5]<-laply(abkhazia[,5], function(sentence){
  sentence = gsub('[[:punct:]]','',sentence)
  sentence = gsub('[[:cntrl:]]','',sentence)
  sentence = gsub('\\d+','',sentence)
  sentence = tolower(sentence)
})
abkhazia[,4]<-laply(abkhazia[,4], function(sentence){
  sentence = gsub('[[:punct:]]','',sentence)
  sentence = gsub('[[:cntrl:]]','',sentence)
  sentence = gsub('\\d+','',sentence)
  sentence = tolower(sentence)
})
abkhazia$Date<-as.Date(abkhazia$Date,format="%d %b. '%y")
abkhazia_autonomy<-abkhazia[grepl("autonomy",abkhazia[,5], ignore.case = T) | grepl("autonomy",abkhazia[,4], ignore.case = T) |
                            grepl("separatis",abkhazia[,5], ignore.case = T) | grepl("separatis",abkhazia[,4], ignore.case = T) |
                            grepl("breakaway",abkhazia[,5], ignore.case = T) | grepl("breakaway",abkhazia[,4], ignore.case = T),]

abkhazia_not<-setdiff(abkhazia$Text,abkhazia_autonomy$Text)
abkhazia_not <- rbind(abkhazia, abkhazia_autonomy)
abkhazia_not <-abkhazia_not[! duplicated(abkhazia_not, fromLast=TRUE) & seq(nrow(abkhazia_not)) <= nrow(abkhazia), ]

abkhazia_autonomy_score <- score.sentiment(abkhazia_autonomy[,5],pos.words,neg.words, .progress='text')
abkhazia_not_score <- score.sentiment(abkhazia_not[,5],pos.words,neg.words, .progress='text')

abkhazia_autonomy$score<-abkhazia_autonomy_score$scores
abkhazia_not$score<-abkhazia_not_score$scores


#Table 2
sum(abkhazia_autonomy_score$scores)/nrow(abkhazia_autonomy_score)
sum(abkhazia_not_score$scores)/nrow(abkhazia_not_score)
t.test(adjara_autonomy_score$scores, adjara_not_score$scores)
t.test(abkhazia_autonomy_score$scores, abkhazia_not_score$scores)
t.test(adjara_autonomy_score$scores, abkhazia_autonomy_score$scores)
t.test(adjara_not_score$scores, abkhazia_not_score$scores)

abkhazia_autonomy_year<-aggregate(score ~ format(Date,"%y"), sum, data = abkhazia_autonomy)
abkhazia_not_year<-aggregate(score ~ format(Date,"%y"), sum, data = abkhazia_not)

abkhazia_autonomy$year<-as.numeric(format(abkhazia_autonomy$Date,"%y"))
abkhazia_not$year<-as.numeric(format(abkhazia_not$Date,"%y"))


#Table 4
t.test(adjara_autonomy[adjara_autonomy$year==04,]$score, 
       adjara_not[adjara_not$year==04,]$score)
t.test(abkhazia_autonomy[abkhazia_autonomy$year==08,]$score, 
       abkhazia_not[abkhazia_not$year==08,]$score)
t.test(adjara_autonomy[adjara_autonomy$year==04,]$score,
       abkhazia_autonomy[abkhazia_autonomy$year==08,]$score)
t.test(adjara_not[adjara_not$year==04,]$score,
       abkhazia_not[abkhazia_not$year==08,]$score)

abkhazia_freq<-as.matrix(TermDocumentMatrix((Corpus(VectorSource(abkhazia_autonomy[,5])))) )
abkhazia_freqMat<-data.frame(ST=rownames(abkhazia_freq),Freq=rowSums(abkhazia_freq),row.names=NULL)
abkhazia_freqMat<-abkhazia_freqMat[order(-abkhazia_freqMat$Freq),]
abkhazia_freqMat$pct<-100*(abkhazia_freqMat$Freq/sum(abkhazia_freqMat$Freq))

abkhazia_not_freq<-as.matrix(TermDocumentMatrix((Corpus(VectorSource(abkhazia_not[,5])))) )
abkhazia_not_freqMat<-data.frame(ST=rownames(abkhazia_not_freq),Freq=rowSums(abkhazia_not_freq),row.names=NULL)
abkhazia_not_freqMat<-abkhazia_not_freqMat[order(-abkhazia_not_freqMat$Freq),]
abkhazia_not_freqMat$pct<-100*(abkhazia_not_freqMat$Freq/sum(abkhazia_not_freqMat$Freq))

abkhazia_autonomy$word_count<-lapply(abkhazia_autonomy[,5],nwords)
abkhazia_autonomy$word_count<-as.numeric(abkhazia_autonomy$word_count)
abkhazia_autonomy_words_year<-aggregate(word_count ~ format(Date,"%y"), sum, data = abkhazia_autonomy)
abkhazia_not$word_count<-lapply(abkhazia_not[,5],nwords)
abkhazia_not$word_count<-as.numeric(abkhazia_not$word_count)
abkhazia_not_words_year<-aggregate(word_count ~ format(Date,"%y"), sum, data = abkhazia_not)


#Table 1
t.test(adjara_autonomy_words_year$word_count, adjara_not_words_year$word_count)
t.test(abkhazia_autonomy_words_year$word_count, abkhazia_not_words_year$word_count)
t.test(adjara_autonomy_words_year$word_count, abkhazia_autonomy_words_year$word_count)
t.test(adjara_not_words_year$word_count, abkhazia_not_words_year$word_count)


#Keyword analysis
#Single word sentiment of autonomy articles
word_list<-c('military', 'conflict', 'security', 'president', 'russia', 
             'region', 'local', 'georgian', 'georgia', 'russian', 'foreign',
             'saakashvili', 'party', 'elections', 'abkhazia', 'adjarian', 'adjara', 'abkhaz')
single_word<-as.data.frame(matrix(nrow=18, ncol=12))

for(i in 1:length(word_list)){
abkhazia_autonomy_single<-abkhazia_autonomy[grepl(word_list[i],abkhazia_autonomy[,5], ignore.case = T) | grepl(word_list[i],abkhazia_autonomy[,4], ignore.case = T),]

abkhazia_not_single<-setdiff(abkhazia_autonomy$Text,abkhazia_autonomy_single$Text)
abkhazia_not_single <- rbind(abkhazia_autonomy, abkhazia_autonomy_single)
abkhazia_not_single <-abkhazia_not_single[! duplicated(abkhazia_not_single, fromLast=TRUE) & seq(nrow(abkhazia_not_single)) <= nrow(abkhazia_autonomy), ]

abkhazia_autonomy_score_single <- score.sentiment(abkhazia_autonomy_single[,5],pos.words,neg.words, .progress='text')
abkhazia_not_score_single <- score.sentiment(abkhazia_not_single[,5],pos.words,neg.words, .progress='text')

abkhazia_autonomy_single$score<-abkhazia_autonomy_score_single$scores
abkhazia_not_single$score<-abkhazia_not_score_single$scores

single_word[i,1]<-sum(abkhazia_autonomy_score_single$scores)/nrow(abkhazia_autonomy_score_single)
single_word[i,2]<-sum(abkhazia_not_score_single$scores)/nrow(abkhazia_not_score_single)

abkhazia_autonomy_year_2008<-abkhazia_autonomy_single[abkhazia_autonomy_single$Date<as.Date("2008-01-01"),]
abkhazia_autonomy_year_2008_2<-abkhazia_autonomy_single[abkhazia_autonomy_single$Date>as.Date("2008-01-01"),]

single_word[i,5]<-sum(abkhazia_autonomy_year_2008$score)/nrow(abkhazia_autonomy_year_2008)
single_word[i,6]<-sum(abkhazia_autonomy_year_2008_2$score)/nrow(abkhazia_autonomy_year_2008_2)

abkhazia_autonomy_year_2008_3<-abkhazia_not_single[abkhazia_not_single$Date<as.Date("2008-01-01"),]
abkhazia_autonomy_year_2008_4<-abkhazia_not_single[abkhazia_not_single$Date>as.Date("2008-01-01"),]

single_word[i,7]<-sum(abkhazia_autonomy_year_2008_3$score)/nrow(abkhazia_autonomy_year_2008_3)
single_word[i,8]<-sum(abkhazia_autonomy_year_2008_4$score)/nrow(abkhazia_autonomy_year_2008_4)

#Of non-autonomy articles
abkhazia_autonomy_single2<-abkhazia_not[grepl(word_list[i],abkhazia_not[,5], ignore.case = T) | grepl(word_list[i],abkhazia_not[,4], ignore.case = T),]

abkhazia_not_single2<-setdiff(abkhazia_not$Text,abkhazia_autonomy_single2$Text)
abkhazia_not_single2 <- rbind(abkhazia_not, abkhazia_autonomy_single2)
abkhazia_not_single2 <-abkhazia_not_single2[! duplicated(abkhazia_not_single2, fromLast=TRUE) & seq(nrow(abkhazia_not_single2)) <= nrow(abkhazia_not), ]

abkhazia_autonomy_score_single2 <- score.sentiment(abkhazia_autonomy_single2[,5],pos.words,neg.words, .progress='text')
abkhazia_not_score_single2 <- score.sentiment(abkhazia_not_single2[,5],pos.words,neg.words, .progress='text')

abkhazia_autonomy_single2$score<-abkhazia_autonomy_score_single2$scores
abkhazia_not_single2$score<-abkhazia_not_score_single2$scores

single_word[i,3]<-sum(abkhazia_autonomy_score_single2$scores)/nrow(abkhazia_autonomy_score_single2)
single_word[i,4]<-sum(abkhazia_not_score_single2$scores)/nrow(abkhazia_not_score_single2)

abkhazia_autonomy_year_2008_5<-abkhazia_autonomy_single2[abkhazia_autonomy_single2$Date<as.Date("2008-01-01"),]
abkhazia_autonomy_year_2008_6<-abkhazia_autonomy_single2[abkhazia_autonomy_single2$Date>as.Date("2008-01-01"),]

single_word[i,9]<-sum(abkhazia_autonomy_year_2008_5$score)/nrow(abkhazia_autonomy_year_2008_5)
single_word[i,10]<-sum(abkhazia_autonomy_year_2008_6$score)/nrow(abkhazia_autonomy_year_2008_6)

abkhazia_autonomy_year_2008_7<-abkhazia_not_single2[abkhazia_not_single2$Date<as.Date("2008-01-01"),]
abkhazia_autonomy_year_2008_8<-abkhazia_not_single2[abkhazia_not_single2$Date>as.Date("2008-01-01"),]

single_word[i,11]<-sum(abkhazia_autonomy_year_2008_7$score)/nrow(abkhazia_autonomy_year_2008_7)
single_word[i,12]<-sum(abkhazia_autonomy_year_2008_8$score)/nrow(abkhazia_autonomy_year_2008_8)
}

single_word2<-as.data.frame(cbind(word_list, single_word))

print(xtable(single_word2), include.rownames=F)
#write.csv(single_word2, 'abkhazia_single_words.csv', row.names=F)

#For Adjara
word_list<-c('military', 'conflict', 'security', 'president', 'russia', 
             'region', 'local', 'georgian', 'georgia', 'russian', 'foreign',
             'saakashvili', 'party', 'elections', 'abkhazia', 'adjarian', 'adjara', 'abkhaz')
single_word<-as.data.frame(matrix(nrow=18, ncol=12))

for(i in 1:length(word_list)){
adjara_autonomy_single<-adjara_autonomy[grepl(word_list[i],adjara_autonomy[,5], ignore.case = T) | grepl(word_list[i],adjara_autonomy[,4], ignore.case = T),]

adjara_not_single<-setdiff(adjara_autonomy$Text,adjara_autonomy_single$Text)
adjara_not_single <- rbind(adjara_autonomy, adjara_autonomy_single)
adjara_not_single <-adjara_not_single[! duplicated(adjara_not_single, fromLast=TRUE) & seq(nrow(adjara_not_single)) <= nrow(adjara_autonomy), ]

adjara_autonomy_score_single <- score.sentiment(adjara_autonomy_single[,5],pos.words,neg.words, .progress='text')
adjara_not_score_single <- score.sentiment(adjara_not_single[,5],pos.words,neg.words, .progress='text')

adjara_autonomy_single$score<-adjara_autonomy_score_single$scores
adjara_not_single$score<-adjara_not_score_single$scores

single_word[i,1]<-sum(adjara_autonomy_score_single$scores)/nrow(adjara_autonomy_score_single)
single_word[i,2]<-sum(adjara_not_score_single$scores)/nrow(adjara_not_score_single)

adjara_autonomy_year_2004<-adjara_autonomy_single[adjara_autonomy_single$Date<as.Date("2004-01-01"),]
adjara_autonomy_year_2004_2<-adjara_autonomy_single[adjara_autonomy_single$Date>as.Date("2004-01-01"),]

single_word[i,5]<-sum(adjara_autonomy_year_2004$score)/nrow(adjara_autonomy_year_2004)
single_word[i,6]<-sum(adjara_autonomy_year_2004_2$score)/nrow(adjara_autonomy_year_2004_2)

adjara_autonomy_year_2004_3<-adjara_not_single[adjara_not_single$Date<as.Date("2004-01-01"),]
adjara_autonomy_year_2004_4<-adjara_not_single[adjara_not_single$Date>as.Date("2004-01-01"),]

single_word[i,7]<-sum(adjara_autonomy_year_2004_3$score)/nrow(adjara_autonomy_year_2004_3)
single_word[i,8]<-sum(adjara_autonomy_year_2004_4$score)/nrow(adjara_autonomy_year_2004_4)

#Of non-autonomy articles
adjara_autonomy_single2<-adjara_not[grepl(word_list[i],adjara_not[,5], ignore.case = T) | grepl(word_list[i],adjara_not[,4], ignore.case = T),]

adjara_not_single2<-setdiff(adjara_not$Text,adjara_autonomy_single2$Text)
adjara_not_single2 <- rbind(adjara_not, adjara_autonomy_single2)
adjara_not_single2 <-adjara_not_single2[! duplicated(adjara_not_single2, fromLast=TRUE) & seq(nrow(adjara_not_single2)) <= nrow(adjara_not), ]

adjara_autonomy_score_single2 <- score.sentiment(adjara_autonomy_single2[,5],pos.words,neg.words, .progress='text')
adjara_not_score_single2 <- score.sentiment(adjara_not_single2[,5],pos.words,neg.words, .progress='text')

adjara_autonomy_single2$score<-adjara_autonomy_score_single2$scores
adjara_not_single2$score<-adjara_not_score_single2$scores

single_word[i,3]<-sum(adjara_autonomy_score_single2$scores)/nrow(adjara_autonomy_score_single2)
single_word[i,4]<-sum(adjara_not_score_single2$scores)/nrow(adjara_not_score_single2)

adjara_autonomy_year_2004_5<-adjara_autonomy_single2[adjara_autonomy_single2$Date<as.Date("2004-01-01"),]
adjara_autonomy_year_2004_6<-adjara_autonomy_single2[adjara_autonomy_single2$Date>as.Date("2004-01-01"),]

single_word[i,9]<-sum(adjara_autonomy_year_2004_5$score)/nrow(adjara_autonomy_year_2004_5)
single_word[i,10]<-sum(adjara_autonomy_year_2004_6$score)/nrow(adjara_autonomy_year_2004_6)

adjara_autonomy_year_2004_7<-adjara_not_single2[adjara_not_single2$Date<as.Date("2004-01-01"),]
adjara_autonomy_year_2004_8<-adjara_not_single2[adjara_not_single2$Date>as.Date("2004-01-01"),]

single_word[i,11]<-sum(adjara_autonomy_year_2004_7$score)/nrow(adjara_autonomy_year_2004_7)
single_word[i,12]<-sum(adjara_autonomy_year_2004_8$score)/nrow(adjara_autonomy_year_2004_8)
}

single_word3<-as.data.frame(cbind(word_list, single_word))

print(xtable(single_word3), include.rownames=F)
#write.csv(single_word3, 'adjara_single_words.csv', row.names=F)


### Topic Models
#Fixing NA rows
adjara_not[529,5]<-'Timeline'
adjara_not[465,5]<-'Timeline'
abkhazia_not[242,5]<-abkhazia_not[242,4]
abkhazia_not[243,5]<-abkhazia_not[243,4]
abkhazia_not[333,5]<-abkhazia_not[333,4]
abkhazia_not[1840,5]<-abkhazia_not[1840,4]
abkhazia_not[1845,5]<-abkhazia_not[1845,4]
abkhazia_not[1847,5]<-abkhazia_not[1847,4]

#Import corpus
docs<-adjara_autonomy[,5]
docs[docs==""] <- NA
which(is.na(docs))
docs<-docs[complete.cases(docs)]
docs<-Corpus(VectorSource(docs))

#Prepare corpus
#Make lowercase, remove punctuation, remove stopwords
docs<-tm_map(docs, content_transformer(tolower))
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, '', x))})
docs<-tm_map(docs, toSpace, '-')
docs<-tm_map(docs, toSpace, "'")
docs<-tm_map(docs, removePunctuation)
docs<-tm_map(docs, removeNumbers)
docs<-tm_map(docs, removeWords, stopwords('english'))
docs<-tm_map(docs, stripWhitespace)
docs<-tm_map(docs, stemDocument)
myStopwords<-c('httpwwwcivilgeengarticlephpid', 'Civil Georgia', 'CivilGe', 'reuters')
docs<-tm_map(docs, removeWords, myStopwords)
dtm<-DocumentTermMatrix(docs)
rownames(dtm)<-adjara_autonomy[,4]
freq<-colSums(as.matrix(dtm))
length(freq)
ord<-order(freq, decreasing=T)

#Set-up parameters for topic model
burnin<-4000
iter<-2000
thin<-500
seed<-list(2003,5,63,100001,765)
nstart<-5
best<-T
k<-7

ldaOut<-LDA(dtm, k, method='Gibbs', 
            control=list(nstart=nstart, seed=seed, 
                         best=best, burnin=burnin, 
                         iter=iter, thin=thin))

system.time(
ldaTopicsNumber<-FindTopicsNumber(dtm, topics=seq(2,10, by=1),  mc.cores= 4L,
                                  metrics = c( "CaoJuan2009", "Arun2010", "Deveaud2014"),
                                  control=list(nstart=nstart, seed=seed, 
                                               best=best, burnin=burnin, 
                                               iter=iter, thin=thin), verbose=T))


FindTopicsNumber_plot(ldaTopicsNumber)

ldaOut.topics<-as.matrix(topics(ldaOut))
#write.csv(ldaOut.topics,file=paste('LDAGibbs',k,'DocsToTopics.csv'))

ldaOut.terms<-as.matrix(terms(ldaOut,20))
#write.csv(ldaOut.terms,file=paste('LDAGibbs',k,'TopicsToTerms.csv'))

topicProbabilities<-as.data.frame(ldaOut@gamma)
#write.csv(topicProbabilities,file=paste('LDAGibbs',k,'TopicProbabilities.csv'))


###Selected 7 topics
adjara_topic<-read.csv('Adjara LDAGibbs 7 TopicProbabilities.csv', header=T, stringsAsFactors = F)
adjara_topic$Date<-adjara_autonomy$Date
adjara_topic<-adjara_topic[,2:ncol(adjara_topic)]
colSums(adjara_topic[,1:7])

adjara_not_topic<-read.csv('Adjara Not LDAGibbs 7 TopicProbabilities.csv', header=T, stringsAsFactors = F)
adjara_not_topic$Date<-adjara_not$Date
adjara_not_topic<-adjara_not_topic[,2:ncol(adjara_not_topic)]
colSums(adjara_not_topic[,1:7])

#Figure 1, Panel B
adjara_topic_Separatism<-aggregate(Separatism ~ format(Date,"%y"), mean, data = adjara_topic)
adjara_topic_Separatism<-rbind(adjara_topic_Separatism, c(17,0))
adjara_not_topic_Separatism<-aggregate(Separatism ~ format(Date,"%y"), mean, data = adjara_not_topic)

plot(adjara_topic_Separatism$Separatism~adjara_topic_Separatism$`format(Date, "%y")`, xaxt='n', yaxt='n', ylab='', type='o', col='red', ylim=c(0,.4), xlab='', 
     main='Public Discourse About Adjaran Separatism', lwd=2, cex.lab=1.3, cex=1.3, pch=18)
axis(1, at=seq(1,17, by=5), labels=c(2001, 2006, 2011, 2016), cex.axis=1.3)
mtext("Year", side=1, line=2.2, cex=1.3)
axis(2, cex.axis=1.3)
mtext("Proportion of Articles", side=2, line=2.2, cex=1.3)
legend(1, .45, c('Autonomy Mentioned', 'Autonomy Not Mentioned'), lwd=2, lty=c(1,2), pch=c(18,20), col=c('red', 'black'), bty='n', cex=1.3)
par(new=T)
plot(adjara_not_topic_Separatism$Separatism~adjara_not_topic_Separatism$`format(Date, "%y")`, 
     axes=F, xlab='', ylab='', pch=20, type='o', ylim=c(0,.4), lwd=2, lty=2)
cor(adjara_not_topic_Separatism$Separatism, adjara_topic_Separatism$Separatism)


###Abkhazia
abkhazia_topic<-read.csv('Abkhazia LDAGibbs 7 TopicProbabilities.csv', header=T, stringsAsFactors = F)
abkhazia_topic$Date<-abkhazia_autonomy$Date
abkhazia_topic<-abkhazia_topic[,2:ncol(abkhazia_topic)]
colSums(abkhazia_topic[,1:7])

abkhazia_not_topic<-read.csv('Abkhazia Not LDAGibbs 7 TopicProbabilities.csv', header=T, stringsAsFactors = F)
abkhazia_not_topic$Date<-abkhazia_not$Date
abkhazia_not_topic<-abkhazia_not_topic[,2:ncol(abkhazia_not_topic)]
colSums(abkhazia_not_topic[,1:7])



#Figure 1, Panel A
abkhazia_topic_Military<-aggregate(Military ~ format(Date,"%y"), mean, data = abkhazia_topic)
abkhazia_not_topic_Military<-aggregate(Military ~ format(Date,"%y"), mean, data = abkhazia_not_topic)
abkhazia_topic_Peace<-aggregate(Peace ~ format(Date,"%y"), mean, data = abkhazia_topic)
abkhazia_topic_Separatism<-aggregate(Separatism ~ format(Date,"%y"), mean, data = abkhazia_topic)


plot(abkhazia_topic_Peace$Peace~abkhazia_topic_Military$`format(Date, "%y")`, xaxt='n',yaxt='n', 
     type='o', col='red', ylim=c(0,.4), pch=18, axes=T, xlab="", ylab='', lwd=2, main='Public Discourse About Abkhazia Mentioning Autonomy', cex.lab=1.3, cex=1.3)
axis(1, at=seq(1,17, by=5), labels=c(2001, 2006, 2011, 2016), cex.axis=1.3)
mtext("Year", side=1, line=2.2, cex=1.3)
axis(2, cex.axis=1.3)
mtext("Proportion of Articles", side=2, line=2.2, cex=1.3)
legend(1, .45, c('Peace', 'Military'), lty=c(1,2), pch=c(18,20), col=c('red', 'black'), bty='n', lwd=2, cex=1.3)
par(new=T)
plot(abkhazia_topic_Military$Military~abkhazia_topic_Military$`format(Date, "%y")`, type='o', col='black', ylim=c(0,.4), pch=20, axes=F, xlab='', ylab='', lwd=2, lty=2, cex=1.3)
cor(abkhazia_topic_Peace$Peace, abkhazia_topic_Military$Military)

#Table 3
colSums(adjara_topic[,1:7])/nrow(adjara_topic)
colSums(adjara_not_topic[,1:7])/nrow(adjara_not_topic)
colSums(abkhazia_topic[,1:7])/nrow(abkhazia_topic)
colSums(abkhazia_not_topic[,1:7])/nrow(abkhazia_not_topic)




