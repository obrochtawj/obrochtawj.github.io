###################################################
### Citizen Responses to Ethnic Representation  ###
### William O'Brochta                           ###
### Washington University in St. Louis          ###
###################################################

library(haven)
library(cjoint)
library(MASS)
library(lmtest)
library(car)
library(psych)
library(stargazer)
library(margins)

survey<-read_sav("Washington_final_withQ29.sav")
profiles<-read.csv("Profiles.csv",header=T, stringsAsFactors = T)
survey2<-merge(survey, profiles, by="Profile", all.x=T)

#Prepare survey
survey2$female<-ifelse(survey2$dem1==2, 1, 0)
survey2$age<-survey2$dem2
survey2$dem3<-ifelse(survey2$dem3==99,NA,survey2$dem3)
survey2$married<-ifelse(survey2$dem3==1, 1, 0)
survey2$education<-survey2$dem4
survey2$albanian<-ifelse(survey2$dem5==1,1,0)
survey2$dem6<-ifelse(survey2$dem6==99,NA,survey2$dem6)
survey2$incomepersonal<-survey2$dem6
survey2$dem7<-ifelse(survey2$dem7==99,NA,survey2$dem7)
survey2$incomehousehold<-survey2$dem7
survey2$householdsize<-survey2$dem8
survey2$region<-as.factor(survey2$dem9)
survey2$Skopje<-ifelse(survey2$region==1, 1, 0)
survey2$region2<-ifelse(survey2$region==2, 1, 0)
survey2$region3<-ifelse(survey2$region==3, 1, 9)
survey2$urban<-ifelse(survey2$dem10==1,1,0)
survey2$municipality<-as.factor(survey2$dem10)
survey2$news<-survey2$Q2_1
survey2$equalopportunity<-survey2$Q2_2
survey2$authoritarian<-survey2$Q2_3
survey2$knowledge<-ifelse(survey2$Q5==3, 1, 0)

#Alternative Measures of Vignette Profiles
survey2$ProfileNumber_f<-as.factor(survey2$ProfileNumber)
survey2$ProfileOverZero<-ifelse(survey2$ProfileNumber>0,1,0)
survey2$ProfileOverOne<-ifelse(survey2$ProfileNumber>2,1,0)
survey2$ProfileSDSM<-ifelse(survey2$ProfileParty=="SDSM",1,0)

#Defining variables of interest
survey2$trust<-as.factor(survey2$Q6)
survey2$trust_n<-(survey2$Q6-1)/4
survey2$equality<-as.factor(survey2$Q7)
survey2$equality_n<-(survey2$Q7-1)/4
survey2$onegroup<-ifelse(survey2$Q8==1,1,0)
survey2$neighbor<-as.factor(survey2$Q9)
survey2$neighbor_n<-(survey2$Q9-1)/4
survey2$talkoutgroup<-as.factor(survey2$Q10)
survey2$talkoutgroup_n<-(survey2$Q10-1)/4
survey2$enthusiastic<-as.numeric(as.character(survey2$Q11))
survey2$angry<-as.numeric(as.character(survey2$Q12))
survey2$hopeful<-as.numeric(as.character(survey2$Q13))
survey2$resentful<-as.numeric(as.character(survey2$Q14))
survey2$cabinetrepresent<-as.factor(survey2$Q15)
survey2$cabinetrepresent_n<-(survey2$Q15-1)/4
survey2$cabinettrust<-as.factor(survey2$Q16)
survey2$cabinettrust_n<-(survey2$Q16-1)/4
survey2$cabinetmodel<-as.factor(survey2$Q17)
survey2$cabinetmodel_n<-(survey2$Q17-1)/4
survey2$ministerpersonal<-ifelse(survey2$Q18==1,1,0)
survey2$benefityou<-as.factor(survey2$Q19)
survey2$benefityou_n<-(survey2$Q19-1)/4
survey2$benefitfinancial<-as.factor(survey2$Q20)
survey2$benefitfinancial_n<-(survey2$Q20-1)/4
survey2$representsatisfied<-as.factor(survey2$Q21)
survey2$representsatisfied_n<-(survey2$Q21-1)/4
survey2$Q29<-ifelse(survey2$Q29==12| survey2$Q29==13| 
                      survey2$Q29==14| survey2$Q29==15, NA, survey2$Q29)
survey2$party_albanian<-ifelse(survey2$Q29==1| survey2$Q29==5| 
                                 survey2$Q29==7| survey2$Q29==8|
                                 survey2$Q29==10, 1, 0)
survey2$party_nationalist<-ifelse(survey2$Q29==4|
                                    survey2$Q29==9|
                                    survey2$Q29==11,1,0)
survey2$party<-as.factor(survey2$Q29)

#Correlation between DVs
#Vignette as prime
cor(survey2$Q6,survey2$Q7)
cor(survey2$Q9,survey2$Q10)

#Explicit reflection on cabinet profile
cor(survey2$Q15,survey2$Q16)
cor(survey2$Q15,survey2$Q17)
cor(survey2$Q16,survey2$Q17)

#Benefit from cabinet profile
cor(survey2$Q19, survey2$Q20)
cor(survey2$Q19, survey2$Q21)
cor(survey2$Q20, survey2$Q21)



###Test ProfileOverZero

#Trust
model1<-polr(trust~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==0,], Hess=TRUE)

model1.1<-polr(trust~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region2+region3+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==1,], Hess=TRUE)

#Equality
model1.2<-polr(equality~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==0,], Hess=TRUE)

model1.3<-polr(equality~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region2+region3+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==1,], Hess=TRUE)

#Neighbor
model1.4<-polr(neighbor~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==0,], Hess=TRUE)

model1.5<-polr(neighbor~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region2+region3+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==1,], Hess=TRUE)


#Talkoutgroup
model1.6<-polr(talkoutgroup~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==0,], Hess=TRUE)

model1.7<-polr(talkoutgroup~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
          +female+age+married+education+householdsize+region2+region3+urban
          +news+equalopportunity+authoritarian+knowledge, 
          survey2[survey2$albanian==1,], Hess=TRUE)

#Onegroup
model1.8<-glm(onegroup~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
       +female+age+married+education+householdsize+region+urban
       +news+equalopportunity+authoritarian+knowledge, 
       survey2[survey2$albanian==0,], family="binomial")
exp(coef(model1.8))

model1.9<-glm(onegroup~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region2+region3+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==1,], family="binomial")
exp(coef(model1.9))


#Table OA.6.2
stargazer(model1, model1.1, model1.2, model1.3, model1.4, model1.5, model1.6,
          model1.7, model1.8, model1.9)


#Cabinet Represent
model1.10<-polr(cabinetrepresent~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)

model1.11<-polr(cabinetrepresent~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)

#Cabinet Trust
model1.12<-polr(cabinettrust~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model1.13<-polr(cabinettrust~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)

#Cabinet Model
model1.14<-polr(cabinetmodel~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model1.15<-polr(cabinetmodel~ProfileOverZero+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)

#Table OA.6.1
stargazer(model1.10, model1.11, model1.12, model1.13, model1.14, model1.15)



###Main Analysis

#Trust
model3<-polr(trust~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3, "ProfileNumber_f6 = ProfileNumber_f10")


model3n<-lm(trust_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,])
(coef3n<-coeftest(model3n, vcov=vcovHC(model3n, type="HC0")))
marginal<-as.data.frame(summary(margins(model3n, 
                                 variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                             "ProfileCooperation", "ProfileSDSM"), 
                                 vcov = vcovHC(model3n, type="HC0"))))
marginal$dv<-"trust"
marginal$albanian<-0


model3.1<-polr(trust~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.1, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.1, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.1, "ProfileNumber_f6 = ProfileNumber_f10")


model3.1n<-lm(trust_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef3.1n<-coeftest(model3.1n, vcov=vcovHC(model3.1n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.1n, 
                                        variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                    "ProfileCooperation", "ProfileSDSM"), 
                                        vcov = vcovHC(model3.1n, type="HC0"))))
marginal_temp$dv<-"trust"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model3.trust<-polr(trust~ProfileNumber_f*albanian+ProfileSDSM*albanian+ProfileSubstantive*albanian
               +ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)


#Equality
model3.2<-polr(equality~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.2, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.2, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.2, "ProfileNumber_f6 = ProfileNumber_f10")

model3.2n<-lm(equality_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])
(coef3.2n<-coeftest(model3.2n, vcov=vcovHC(model3.2n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.2n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.2n, type="HC0"))))
marginal_temp$dv<-"equality"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model3.3<-polr(equality~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.3, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.3, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.3, "ProfileNumber_f6 = ProfileNumber_f10")

model3.3n<-lm(equality_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef3.3n<-coeftest(model3.3n, vcov=vcovHC(model3.3n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.3n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.3n, type="HC0"))))
marginal_temp$dv<-"equality"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model3.equality<-polr(equality~ProfileNumber_f*albanian+ProfileSDSM*albanian
                      +ProfileSubstantive*albanian+ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)


#Neighbor
model3.4<-polr(neighbor~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.4, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.4, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.4, "ProfileNumber_f6 = ProfileNumber_f10")

model3.4n<-lm(neighbor_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])
(coef3.4n<-coeftest(model3.4n, vcov=vcovHC(model3.4n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.4n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.4n, type="HC0"))))
marginal_temp$dv<-"neighbor"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model3.5<-polr(neighbor~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.5, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.5, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.5, "ProfileNumber_f6 = ProfileNumber_f10")

model3.5n<-lm(neighbor_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef3.5n<-coeftest(model3.5n, vcov=vcovHC(model3.5n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.5n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.5n, type="HC0"))))
marginal_temp$dv<-"neighbor"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model3.neighbor<-polr(neighbor~ProfileNumber_f*albanian+ProfileSDSM*albanian
                      +ProfileSubstantive*albanian+ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)



#Talkoutgroup
model3.6<-polr(talkoutgroup~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.6, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.6, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.6, "ProfileNumber_f6 = ProfileNumber_f10")


model3.6n<-lm(talkoutgroup_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])
(coef3.6n<-coeftest(model3.6n, vcov=vcovHC(model3.6n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.6n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.6n, type="HC0"))))
marginal_temp$dv<-"talkoutgroup"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model3.7<-polr(talkoutgroup~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.7, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.7, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.7, "ProfileNumber_f6 = ProfileNumber_f10")

model3.7n<-lm(talkoutgroup_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef3.7n<-coeftest(model3.7n, vcov=vcovHC(model3.7n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.7n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.7n, type="HC0"))))
marginal_temp$dv<-"talkoutgroup"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model3.talkoutgroup<-polr(talkoutgroup~ProfileNumber_f*albanian+ProfileSDSM*albanian
                          +ProfileSubstantive*albanian+ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)


#Onegroup
model3.8<-glm(onegroup~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==0,], family="binomial")
exp(coef(model3.8))

linearHypothesis(model3.8, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.8, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.8, "ProfileNumber_f6 = ProfileNumber_f10")


model3.8n<-lm(onegroup~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==0,])
(coef3.8n<-coeftest(model3.8n, vcov=vcovHC(model3.8n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.8n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.8n, type="HC0"))))
marginal_temp$dv<-"onegroup"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model3.9<-glm(onegroup~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region2+region3+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==1,], family="binomial")
exp(coef(model3.9))
linearHypothesis(model3.9, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.9, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.9, "ProfileNumber_f6 = ProfileNumber_f10")

model3.9n<-lm(onegroup~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region2+region3+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==1,])
(coef3.9n<-coeftest(model3.9n, vcov=vcovHC(model3.9n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.9n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.9n, type="HC0"))))
marginal_temp$dv<-"onegroup"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model3.onegroup<-glm(onegroup~ProfileNumber_f*albanian+ProfileSDSM*albanian
                     +ProfileSubstantive*albanian+ProfileCooperation*albanian
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2, family="binomial")

#Table OA.5.2
stargazer(model3, model3.1, model3.2, model3.3, model3.4, model3.5, model3.6,
          model3.7, model3.8, model3.9)

#Table OA.4.3
stargazer(model3n, model3.1n, model3.2n, model3.3n, model3.4n, model3.5n, model3.6n,
          model3.7n, model3.8n, model3.9n, se=list(coef3n[,2], coef3.1n[,2],
                                                coef3.2n[,2], coef3.3n[,2],
                                                coef3.4n[,2], coef3.5n[,2],
                                                coef3.6n[,2], coef3.7n[,2],
                                                coef3.8n[,2], coef3.9n[,2]))

#Table OA.6.4
stargazer(model3.trust, model3.equality, model3.neighbor, 
          model3.talkoutgroup, model3.onegroup)



#Cabinetrepresent
model3.10<-polr(cabinetrepresent~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.10, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.10, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.10, "ProfileNumber_f6 = ProfileNumber_f10")

model3.10n<-lm(cabinetrepresent_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,])
(coef3.10n<-coeftest(model3.10n, vcov=vcovHC(model3.10n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.10n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.10n, type="HC0"))))
marginal_temp$dv<-"cabinetrepresent"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model3.11<-polr(cabinetrepresent~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region2+region3+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.11, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.11, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.11, "ProfileNumber_f6 = ProfileNumber_f10")

model3.11n<-lm(cabinetrepresent_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region2+region3+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==1,])
(coef3.11n<-coeftest(model3.11n, vcov=vcovHC(model3.11n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.11n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.11n, type="HC0"))))
marginal_temp$dv<-"cabinetrepresent"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model3.cabinetrepresent<-polr(cabinetrepresent~ProfileNumber_f*albanian+ProfileSDSM*albanian
                              +ProfileSubstantive*albanian+ProfileCooperation*albanian
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2, Hess=TRUE)


#Cabinettrust
model3.12<-polr(cabinettrust~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.12, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.12, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.12, "ProfileNumber_f6 = ProfileNumber_f10")


model3.12n<-lm(cabinettrust_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,])
(coef3.12n<-coeftest(model3.12n, vcov=vcovHC(model3.12n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.12n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.12n, type="HC0"))))
marginal_temp$dv<-"cabinettrust"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model3.13<-polr(cabinettrust~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region2+region3+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.13, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.13, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.13, "ProfileNumber_f6 = ProfileNumber_f10")

model3.13n<-lm(cabinettrust_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region2+region3+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==1,])
(coef3.13n<-coeftest(model3.13n, vcov=vcovHC(model3.13n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.13n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.13n, type="HC0"))))
marginal_temp$dv<-"cabinettrust"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model3.cabinettrust<-polr(cabinettrust~ProfileNumber_f*albanian+ProfileSDSM*albanian
                          +ProfileSubstantive*albanian+ProfileCooperation*albanian
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2, Hess=TRUE)


#Cabinetmodel
model3.14<-polr(cabinetmodel~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model3.14, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.14, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.14, "ProfileNumber_f6 = ProfileNumber_f10")


model3.14n<-lm(cabinetmodel_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,])
(coef3.14n<-coeftest(model3.14n, vcov=vcovHC(model3.14n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.14n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.14n, type="HC0"))))
marginal_temp$dv<-"cabinetmodel"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model3.15<-polr(cabinetmodel~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region2+region3+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model3.15, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model3.15, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model3.15, "ProfileNumber_f6 = ProfileNumber_f10")

model3.15n<-lm(cabinetmodel_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                +female+age+married+education+householdsize+region2+region3+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==1,])
(coef3.15n<-coeftest(model3.15n, vcov=vcovHC(model3.15n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model3.15n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model3.15n, type="HC0"))))
marginal_temp$dv<-"cabinetmodel"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)



model3.cabinetmodel<-polr(cabinetmodel~ProfileNumber_f*albanian+ProfileSDSM*albanian
                          +ProfileSubstantive*albanian+ProfileCooperation*albanian
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2, Hess=TRUE)


#Table OA.5.1
stargazer(model3.10, model3.11, model3.12, model3.13, model3.14, model3.15)

#Table OA.4.2
stargazer(model3.10n, model3.11n, model3.12n, model3.13n, model3.14n, model3.15n,
          se=list(coef3.10n[,2], coef3.11n[,2],
                  coef3.12n[,2], coef3.13n[,2],
                  coef3.14n[,2], coef3.15n[,2]))

#Table OA.6.3
stargazer(model3.cabinetrepresent, model3.cabinettrust, model3.cabinetmodel)




###Mechanisms
#Estimate models on the post-treatment mechanism questions
#benefityou
model5<-polr(benefityou~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model5, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5, "ProfileNumber_f6 = ProfileNumber_f10")

model5n<-lm(benefityou_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,])
(coef5n<-coeftest(model5n, vcov=vcovHC(model5n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5n, type="HC0"))))
marginal_temp$dv<-"benefityou"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model5.1<-polr(benefityou~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model5.1, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.1, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.1, "ProfileNumber_f6 = ProfileNumber_f10")


model5.1n<-lm(benefityou_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef5.1n<-coeftest(model5.1n, vcov=vcovHC(model5.1n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.1n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.1n, type="HC0"))))
marginal_temp$dv<-"benefityou"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model5.benefityou<-polr(benefityou~ProfileNumber_f*albanian+ProfileSDSM*albanian
               +ProfileSubstantive*albanian+ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)

#benefitfinancial
model5.2<-polr(benefitfinancial~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model5.2, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.2, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.2, "ProfileNumber_f6 = ProfileNumber_f10")

model5.2n<-lm(benefitfinancial_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])
(coef5.2n<-coeftest(model5.2n, vcov=vcovHC(model5.2n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.2n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.2n, type="HC0"))))
marginal_temp$dv<-"benefitfinancial"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model5.3<-polr(benefitfinancial~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model5.3, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.3, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.3, "ProfileNumber_f6 = ProfileNumber_f10")

model5.3n<-lm(benefitfinancial_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef5.3n<-coeftest(model5.3n, vcov=vcovHC(model5.3n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.3n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.3n, type="HC0"))))
marginal_temp$dv<-"benefitfinancial"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model5.benefitfinancial<-polr(benefitfinancial~ProfileNumber_f*albanian+ProfileSDSM*albanian
               +ProfileSubstantive*albanian+ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)


#representsatisfied
model5.4<-polr(representsatisfied~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)
linearHypothesis(model5.4, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.4, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.4, "ProfileNumber_f6 = ProfileNumber_f10")

model5.4n<-lm(representsatisfied_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])
(coef5.4n<-coeftest(model5.4n, vcov=vcovHC(model5.4n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.4n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.4n, type="HC0"))))
marginal_temp$dv<-"representsatisfied"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model5.5<-polr(representsatisfied~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,], Hess=TRUE)
linearHypothesis(model5.5, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.5, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.5, "ProfileNumber_f6 = ProfileNumber_f10")

model5.5n<-lm(representsatisfied_n~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])
(coef5.5n<-coeftest(model5.5n, vcov=vcovHC(model5.5n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.5n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.5n, type="HC0"))))
marginal_temp$dv<-"representsatisfied"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model5.representsatisfied<-polr(representsatisfied~ProfileNumber_f*albanian+ProfileSDSM*albanian
               +ProfileSubstantive*albanian+ProfileCooperation*albanian
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2, Hess=TRUE)

#ministerpersonal
model5.6<-glm(ministerpersonal~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==0,], family="binomial")
exp(coef(model5.6))
linearHypothesis(model5.6, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.6, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.6, "ProfileNumber_f6 = ProfileNumber_f10")

model5.6n<-lm(ministerpersonal~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==0,])
(coef5.6n<-coeftest(model5.6n, vcov=vcovHC(model5.6n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.6n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.6n, type="HC0"))))
marginal_temp$dv<-"ministerpersonal"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model5.7<-glm(ministerpersonal~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region2+region3+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==1,], family="binomial")
exp(coef(model5.7))
linearHypothesis(model5.7, "ProfileNumber_f1 = ProfileNumber_f6")
linearHypothesis(model5.7, "ProfileNumber_f1 = ProfileNumber_f10")
linearHypothesis(model5.7, "ProfileNumber_f6 = ProfileNumber_f10")

model5.7n<-lm(ministerpersonal~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
              +female+age+married+education+householdsize+region2+region3+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==1,])
(coef5.7n<-coeftest(model5.7n, vcov=vcovHC(model5.7n, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model5.7n, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model5.7n, type="HC0"))))
marginal_temp$dv<-"ministerpersonal"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model5.ministerpersonal<-glm(ministerpersonal~ProfileNumber_f*albanian+ProfileSDSM*albanian
              +ProfileSubstantive*albanian+ProfileCooperation*albanian
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2, family="binomial")

#Table OA.5.3
stargazer(model5, model5.1, model5.2, model5.3, model5.4, 
          model5.5, model5.6, model5.7)

#Table OA.4.4
stargazer(model5n, model5.1n, model5.2n, model5.3n, model5.4n, 
          model5.5n, model5.6n, model5.7n, se=list(coef5n[,2], coef5.1n[,2],
        coef5.2n[,2], coef5.3n[,2], coef5.4n[,2], coef5.5n[,2], coef5.6n[,2], coef5.7n[,2]))


#Table OA.6.5
stargazer(model5.benefityou, model5.benefitfinancial, 
          model5.representsatisfied, model5.ministerpersonal)



#Affective status classification
###Affective Status
library(tidyLPA)
library(tidyverse)
library(psych)

#Compare to see which model is the best for different numbers of states
#Want drop in BIC with entropy remaining high
#survey2 %>%
#  select(enthusiastic, angry, hopeful, resentful) %>%
#  single_imputation() %>%
#  estimate_profiles(1:4, 
#                    variances = c("equal"),
#                    covariances = c("zero")) %>%
#  compare_solutions(statistics = c("Entropy", "BIC"))

#model1.5<-survey2%>%
#  select(enthusiastic, angry, hopeful, resentful)%>%
#  single_imputation()%>%
#  estimate_profiles(4)

#save(model1.5, file='model1.5.RData')

load('model1.5.RData')

#Probabilities for being in each category for each respondent
model1.5data<-as.data.frame(get_data(model1.5))
#Estimates of the mean parameter values for each profile;
#use to assess whether the four affective states result
model1.5estimates<-as.data.frame(get_estimates(model1.5))

#LPA Profiles Plot
model1.5%>%plot_profiles()

#Find largest probability; assign that to a state 
model1.5data$AffState<-colnames(model1.5data[,7:10])[apply(model1.5data[,7:10],1,which.max)]
model1.5data$AffState<-ifelse(model1.5data$AffState=='CPROB1', "Weak", model1.5data$AffState)
model1.5data$AffState<-ifelse(model1.5data$AffState=='CPROB3', "Mixed", model1.5data$AffState)
model1.5data$AffState<-ifelse(model1.5data$AffState=='CPROB2', "Unpleasant", model1.5data$AffState)
model1.5data$AffState<-ifelse(model1.5data$AffState=='CPROB4', "Pleasant", model1.5data$AffState)
model1.5data$Weak<-ifelse(model1.5data$AffState=="Weak",1,0)
model1.5data$Mixed<-ifelse(model1.5data$AffState=="Mixed",1,0)
model1.5data$Unpleasant<-ifelse(model1.5data$AffState=="Unpleasant",1,0)
model1.5data$Pleasant<-ifelse(model1.5data$AffState=="Pleasant",1,0)


#Table OA.3.1
#Mean value of hopeful is highest for pleasant
mean(model1.5data[model1.5data$Pleasant==1,]$hopeful)
mean(model1.5data[model1.5data$Unpleasant==1,]$hopeful)
mean(model1.5data[model1.5data$Weak==1,]$hopeful)
mean(model1.5data[model1.5data$Mixed==1,]$hopeful)

#Mean value for enthusiastic is highest for pleasant
mean(model1.5data[model1.5data$Pleasant==1,]$enthusiastic)
mean(model1.5data[model1.5data$Unpleasant==1,]$enthusiastic)
mean(model1.5data[model1.5data$Weak==1,]$enthusiastic)
mean(model1.5data[model1.5data$Mixed==1,]$enthusiastic)

#Mean value of angry is highest for angry
mean(model1.5data[model1.5data$Pleasant==1,]$angry)
mean(model1.5data[model1.5data$Unpleasant==1,]$angry)
mean(model1.5data[model1.5data$Weak==1,]$angry)
mean(model1.5data[model1.5data$Mixed==1,]$angry)

#Mean value for resentful is highest for unpleasant
mean(model1.5data[model1.5data$Pleasant==1,]$resentful)
mean(model1.5data[model1.5data$Unpleasant==1,]$resentful)
mean(model1.5data[model1.5data$Weak==1,]$resentful)
mean(model1.5data[model1.5data$Mixed==1,]$resentful)

#"Mean parameter estimates"
model1.5data$lpa_pleasant<-(model1.5data$hopeful+model1.5data$enthusiastic)/2
model1.5data$lpa_unpleasant<-(model1.5data$angry+model1.5data$resentful)/2

#Plot LPA_AffState
par(xpd = T, mar = par()$mar + c(0,0,0,7))
plot(jitter(lpa_pleasant)~jitter(lpa_unpleasant), model1.5data[model1.5data$Pleasant==1,], 
     xlim=c(1,5), ylim=c(1,5), xlab='Unpleasant', ylab="Pleasant", 
     main="LPA Pleasant and Unpleasant Affective States", 
     cex.axis=1.3, cex.lab=1.3, cex.main=1.3, lwd=2)
par(new=T)
plot(jitter(lpa_pleasant)~jitter(lpa_unpleasant), model1.5data[model1.5data$Unpleasant==1,],
     xlim=c(1,5), ylim=c(1,5), pch=18, 
     col='red', axes=F, xlab="", ylab="", main="", lwd=2)
par(new=T)
plot(jitter(lpa_pleasant)~jitter(lpa_unpleasant), model1.5data[model1.5data$Mixed==1,],
     xlim=c(1,5), ylim=c(1,5), pch=3, 
     col='darkgreen', axes=F, xlab="", ylab="", main="", lwd=2)
par(new=T)
plot(jitter(lpa_pleasant)~jitter(lpa_unpleasant), model1.5data[model1.5data$Weak==1,],
     xlim=c(1,5), ylim=c(1,5), pch=5, 
     col='purple', axes=F, xlab="", ylab="", main="", lwd=2)
legend(4.8, 4, c("Pleasant", "Unpleasant", "Mixed", "Weak"), pch=c(1, 18, 3, 5),
       col=c("black", "red", "darkgreen", "purple"), cex=1.2, bty='n')
dev.off()


#VSS and bi-plot
emotions<-as.matrix(cbind(survey2$enthusiastic,survey2$angry,survey2$hopeful,survey2$resentful))

#Shows that fit "peak" is at 2 factors
vss(emotions,fm="minres", rotate="oblimin")
#Should retain two factors (e.g., pleasant and unpleasant)
fa.parallel(emotions, fm="minres")

#Run the factor analysis in 7 different ways
factors.mr_r<-fa(emotions, 2, fm="minres", rotate ="oblimin", scores="regression")
factors.ml_r<-fa(emotions, 2, fm="ml", rotate ="oblimin", scores="regression")
factors.mr_b<-fa(emotions, 2, fm="minres", rotate ="oblimin", scores="Bartlett") ##This is our baseline
factors.ml_b<-fa(emotions, 2, fm="ml", rotate ="oblimin", scores="Bartlett")
factors.pa_r<-fa(emotions, 2, fm="pa", rotate ="oblimin", scores="regression")
factors.pa_b<-fa(emotions, 2, fm="pa", rotate ="oblimin", scores="Bartlett")
factors.pca<-principal(emotions, 2, rotate ="oblimin", scores=T)


#Figure OA.3.1
par(mfrow=c(2,4))
biplot(factors.mr_b, col=c("grey", "blue"),
       main="Minres Bartlett") #Main plot
biplot(factors.mr_r, col=c("grey", "blue"),
       main="Minres Regression")
biplot(factors.ml_r, col=c("grey", "blue"),
       main="Maxlik Regression")
biplot(factors.ml_b, col=c("grey", "blue"),
       main="Maxlik Bartlett")
biplot(factors.pa_r, col=c("grey", "blue"),
       main="Principal Axis Regression")
biplot(factors.pa_b, col=c("grey", "blue"),
       main="Principal Axis Bartlett")
biplot(factors.pca, col=c("grey", "blue"),
       main="PCA")
dev.off()

##Add factor scores
#Minres-regression
factors.mr_r.df <- as.data.frame(factors.mr_r$scores)
factors.mr_r.df$upfact <- as.numeric(factors.mr_r.df$MR1)
factors.mr_r.df$pfact <- as.numeric(factors.mr_r.df$MR2)
model1.5data$upfact_mr_r <- factors.mr_r.df$upfact
model1.5data$pfact_mr_r <- factors.mr_r.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_mr_r,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_mr_r,model1.5data$lpa_unpleasant, use="complete.obs")

#maxlik-regression
factors_ml_r.df <- as.data.frame(factors.ml_r$scores)
factors_ml_r.df$upfact <- as.numeric(factors_ml_r.df$ML1)
factors_ml_r.df$pfact <- as.numeric(factors_ml_r.df$ML2)
model1.5data$upfact_ml_r <- factors_ml_r.df$upfact
model1.5data$pfact_ml_r <- factors_ml_r.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_ml_r,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_ml_r,model1.5data$lpa_unpleasant, use="complete.obs")

#Minres-bartlett
factors_mr_b.df <- as.data.frame(factors.mr_b$scores)
factors_mr_b.df$upfact <- as.numeric(factors_mr_b.df$MR1)
factors_mr_b.df$pfact <- as.numeric(factors_mr_b.df$MR2)
model1.5data$upfact_mr_b <- factors_mr_b.df$upfact
model1.5data$pfact_mr_b <- factors_mr_b.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_mr_b,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_mr_b,model1.5data$lpa_unpleasant, use="complete.obs")

#maxlik-bartlett
factors_ml_b.df <- as.data.frame(factors.ml_b$scores)
factors_ml_b.df$upfact <- as.numeric(factors_ml_b.df$ML1)
factors_ml_b.df$pfact <- as.numeric(factors_ml_b.df$ML2)
model1.5data$upfact_ml_b <- factors_ml_b.df$upfact
model1.5data$pfact_ml_b <- factors_ml_b.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_ml_b,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_ml_b,model1.5data$lpa_unpleasant, use="complete.obs")

#princ access-regression
factors_pa_r.df <- as.data.frame(factors.pa_r$scores)
factors_pa_r.df$upfact <- as.numeric(factors_pa_r.df$PA1)
factors_pa_r.df$pfact <- as.numeric(factors_pa_r.df$PA2)
model1.5data$upfact_pa_r <- factors_pa_r.df$upfact
model1.5data$pfact_pa_r <- factors_pa_r.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_pa_r,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_pa_r,model1.5data$lpa_unpleasant, use="complete.obs")

#princ access-bartlett
factors_pa_b.df <- as.data.frame(factors.pa_b$scores)
factors_pa_b.df$upfact <- as.numeric(factors_pa_b.df$PA1)
factors_pa_b.df$pfact <- as.numeric(factors_pa_b.df$PA2)
model1.5data$upfact_pa_b <- factors_pa_b.df$upfact
model1.5data$pfact_pa_b <- factors_pa_b.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_pa_b,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_pa_b,model1.5data$lpa_unpleasant, use="complete.obs")

#pca
factors_pca.df <- as.data.frame(factors.pca$scores)
factors_pca.df$upfact <- as.numeric(factors_pca.df$TC1)
factors_pca.df$pfact <- as.numeric(factors_pca.df$TC2)
model1.5data$upfact_pca <- factors_pca.df$upfact
model1.5data$pfact_pca <- factors_pca.df$pfact
##To check if we assinged the correct factors:
cor(model1.5data$pfact_pca,model1.5data$lpa_pleasant, use="complete.obs")
cor(model1.5data$upfact_pca,model1.5data$lpa_unpleasant, use="complete.obs")

#Correlation between all the factors
library(xtable)
factors_all <- model1.5data %>%
  select(pfact_mr_r,pfact_mr_b,pfact_ml_r,pfact_ml_b,pfact_pa_r,
         pfact_pa_b,pfact_pca,lpa_pleasant,upfact_mr_r,upfact_mr_b,
         upfact_ml_r,upfact_ml_b,upfact_pa_r,upfact_pa_b,
         upfact_pca,lpa_unpleasant)
factors_corr <- cor(factors_all, use="complete.obs")
factors_corr

#Table OA.3.2
xtable(factors_corr[,1:8], type="latex")

#Table OA.3.3
xtable(factors_corr[,9:16], type="latex")

##To generate the affect variable for each method:
#Table OA.3.4
#Minres-regression
model1.5data$affect_mr_r <- NA
model1.5data$affect_mr_r <- ifelse((model1.5data$pfact_mr_r>0 & model1.5data$upfact_mr_r<0),
                                   "Pleasant",ifelse((model1.5data$pfact_mr_r<0 & 
                                                        model1.5data$upfact_mr_r<0),
                                                     "Weak",ifelse((model1.5data$pfact_mr_r>0 
                                                                    & model1.5data$upfact_mr_r>0),
                                                                   "Mixed","Unpleasant")))
model1.5data$affect_mr_r<- factor(model1.5data$affect_mr_r , ordered = FALSE )
model1.5data$affect_mr_r <- relevel(model1.5data$affect_mr_r, ref="Weak")
table(model1.5data$affect_mr_r)

#maxlik-regression
model1.5data$affect_ml_r <- NA
model1.5data$affect_ml_r <- ifelse((model1.5data$pfact_ml_r>0 & 
                                      model1.5data$upfact_ml_r<0),
                                   "Pleasant",ifelse((model1.5data$pfact_ml_r<0 & 
                                                        model1.5data$upfact_ml_r<0),
                                                     "Weak",ifelse((model1.5data$pfact_ml_r>0 & 
                                                                      model1.5data$upfact_ml_r>0),
                                                                   "Mixed","Unpleasant")))
model1.5data$affect_ml_r<- factor(model1.5data$affect_ml_r , ordered = FALSE )
model1.5data$affect_ml_r <- relevel(model1.5data$affect_ml_r, ref="Weak")
table(model1.5data$affect_ml_r)

#Minres-bartlett
model1.5data$affect_mr_b <- NA
model1.5data$affect_mr_b <- ifelse((model1.5data$pfact_mr_b>0 & 
                                      model1.5data$upfact_mr_b<0),
                                   "Pleasant",ifelse((model1.5data$pfact_mr_b<0 &
                                                        model1.5data$upfact_mr_b<0),
                                                     "Weak",ifelse((model1.5data$pfact_mr_b>0 & 
                                                                      model1.5data$upfact_mr_b>0),
                                                                   "Mixed","Unpleasant")))
model1.5data$affect_mr_b<- factor(model1.5data$affect_mr_b , ordered = FALSE )
model1.5data$affect_mr_b <- relevel(model1.5data$affect_mr_b, ref="Weak")
table(model1.5data$affect_mr_b)

#maxlik-bartlett
model1.5data$affect_ml_b <- NA
model1.5data$affect_ml_b <- ifelse((model1.5data$pfact_ml_b>0 & 
                                      model1.5data$upfact_ml_b<0),
                                   "Pleasant",ifelse((model1.5data$pfact_ml_b<0 &
                                                        model1.5data$upfact_ml_b<0),
                                                     "Weak",ifelse((model1.5data$pfact_ml_b>0 & 
                                                                      model1.5data$upfact_ml_b>0),
                                                                   "Mixed","Unpleasant")))
model1.5data$affect_ml_b<- factor(model1.5data$affect_ml_b , ordered = FALSE )
model1.5data$affect_ml_b <- relevel(model1.5data$affect_ml_b, ref="Weak")
table(model1.5data$affect_ml_b)

#princ access-regression
model1.5data$affect_pa_r <- NA
model1.5data$affect_pa_r <- ifelse((model1.5data$pfact_pa_r>0 & 
                                      model1.5data$upfact_pa_r<0),
                                   "Pleasant",ifelse((model1.5data$pfact_pa_r<0 &
                                                        model1.5data$upfact_pa_r<0),
                                                     "Weak",ifelse((model1.5data$pfact_pa_r>0 &
                                                                      model1.5data$upfact_pa_r>0),
                                                                   "Mixed","Unpleasant")))
model1.5data$affect_pa_r<- factor(model1.5data$affect_pa_r , ordered = FALSE )
model1.5data$affect_pa_r <- relevel(model1.5data$affect_pa_r, ref="Weak")
table(model1.5data$affect_pa_r)

#princ access-bartlett
model1.5data$affect_pa_b <- NA
model1.5data$affect_pa_b <- ifelse((model1.5data$pfact_pa_b>0 & 
                                      model1.5data$upfact_pa_b<0),
                                   "Pleasant",ifelse((model1.5data$pfact_pa_b<0 &
                                                        model1.5data$upfact_pa_b<0),
                                                     "Weak",ifelse((model1.5data$pfact_pa_b>0 &
                                                                      model1.5data$upfact_pa_b>0),
                                                                   "Mixed","Unpleasant")))
model1.5data$affect_pa_b<- factor(model1.5data$affect_pa_b , ordered = FALSE )
model1.5data$affect_pa_b <- relevel(model1.5data$affect_pa_b, ref="Weak")
table(model1.5data$affect_pa_b)

#pca
model1.5data$affect_pca <- NA
model1.5data$affect_pca <- ifelse((model1.5data$pfact_pca>0 &
                                     model1.5data$upfact_pca<0),
                                  "Pleasant",ifelse((model1.5data$pfact_pca<0 &
                                                       model1.5data$upfact_pca<0),
                                                    "Weak",ifelse((model1.5data$pfact_pca>0 &
                                                                     model1.5data$upfact_pca>0),
                                                                  "Mixed","Unpleasant")))
model1.5data$affect_pca<- factor(model1.5data$affect_pca , ordered = FALSE )
model1.5data$affect_pca <- relevel(model1.5data$affect_pca, ref="Weak")
table(model1.5data$affect_pca)

#LPA Results
table(model1.5data$AffState)


##To calculate Cramer's V for the "correlation" between these different cateogorical variables
library(vcd)
catcorrm <- function(vars, dat) sapply(vars, function(y) sapply(vars, function(x) assocstats(table(dat[,x], dat[,y]))$cramer))

factors_affcor <- catcorrm(c("affect_mr_r","affect_mr_b","affect_ml_r","affect_ml_b",
                        "affect_pa_r","affect_pa_b","affect_pca", "AffState"), model1.5data)
factors_affcor

#Table OA.3.5
xtable(factors_affcor, type='latex')


##The Quadraplex Assignment plot:
#Figure OA.3.2
factors_affectplot <- model1.5data %>%
  as_tibble() %>%
  mutate(cluster = affect_mr_b) %>%
  ggplot(aes(upfact_mr_b, pfact_mr_b, color = affect_mr_b)) + geom_jitter() + theme_bw() + 
  guides(color=guide_legend(title="")) + ggtitle("Minres Bartlett Affective States")+
  theme(plot.title = element_text(hjust = 0.5))+
  xlab("Unpleasant Valence") + ylab("Pleasant Valence") + theme(axis.title=element_text(size=12)) + 
  theme(axis.text=element_text(size=12)) + theme(legend.text=element_text(size=12)) + 
  theme(legend.title=element_text(size=12)) + geom_hline(yintercept = 0, lty=4) + 
  geom_vline(xintercept = 0, lty=2) + scale_color_manual(values=c("#4daf4a", "#984ea3", "#377eb8", "#e41a1c"), 
                                                         labels = c("Weak","Mixed","Pleasant","Unpleasant"))
factors_affectplot

##Sensitivity Plot:
#Figure OA.3.3
library(tidyverse)
factors_affect.df <- model1.5data %>%
  select(affect_mr_r,affect_mr_b,affect_ml_r,affect_ml_b,affect_pa_r,affect_pa_b,affect_pca)
rownames_to_column(factors_affect.df, var="rownames")
factors_affect.df$affectsum <- NA
factors_affect.df

affect.f <- function(i, col) {
  if (factors_affect.df[i, "affect_mr_b"] == factors_affect.df[i, col]) {
    return(1)
  } else {
    return(0)
  }
}

affect.sum <- function(i) {
  return (affect.f(i,"affect_mr_b") 
          + affect.f(i,"affect_mr_r")
          + affect.f(i,"affect_ml_b")
          + affect.f(i,"affect_ml_r")
          + affect.f(i,"affect_pa_r")
          + affect.f(i,"affect_pa_b")
          + affect.f(i,"affect_pca"))
}

for(i in 1:nrow(factors_affect.df)) {
  factors_affect.df[i,]$affectsum = affect.sum(i)
}
factors_affect.df

model1.5data$affectsum <- factors_affect.df$affectsum
table(model1.5data$affectsum)

model1.5data$affectperc <- model1.5data$affectsum/7

factors_faplot <- model1.5data %>%
  as_tibble() %>%
  mutate(cluster = affect_mr_b) %>%
  ggplot(aes(upfact_mr_b, pfact_mr_b, color = factor(affectsum))) + 
  geom_jitter() + theme_bw() +  ggtitle("Number of FA Methods with Same Affective State Classification")+
  theme(plot.title = element_text(hjust = 0.5))+
  guides(color=guide_legend(title="")) + 
  xlab("Unpleasant Valence") + ylab("Pleasant Valence") + 
  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=12)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) + geom_vline(xintercept = 0, lty=2) 
#+ scale_color_manual(values=c("#FFFF33", "#FFFF33", "#FFFF00", "#FFCC33", "#FFCC00", "#66CC00"))
factors_faplot

#data4<-as.data.frame(c(survey2, model1.5data[,12:41]))
#save(data4, file='data4.RData')


#Figure out who is in which state

load("data4.RData")

data4$affect_mr_b2_p<-ifelse(data4$affect_mr_b=="Pleasant",1,0)
data4$affect_mr_b2_u<-ifelse(data4$affect_mr_b=="Unpleasant",1,0)
data4$affect_mr_b2_m<-ifelse(data4$affect_mr_b=="Mixed",1,0)
data4$affect_mr_b2_w<-ifelse(data4$affect_mr_b=="Weak",1,0)

data4$affect_mr_r2_p<-ifelse(data4$affect_mr_r=="Pleasant",1,NA)
data4$affect_mr_r2_u<-ifelse(data4$affect_mr_r=="Unpleasant",1,0)
data4$affect_mr_r2_m<-ifelse(data4$affect_mr_r=="Mixed",1,0)
data4$affect_mr_r2_w<-ifelse(data4$affect_mr_r=="Weak",1,0)

data4$affect_ml_b2_p<-ifelse(data4$affect_ml_b=="Pleasant",1,0)
data4$affect_ml_b2_u<-ifelse(data4$affect_ml_b=="Unpleasant",1,0)
data4$affect_ml_b2_m<-ifelse(data4$affect_ml_b=="Mixed",1,0)
data4$affect_ml_b2_w<-ifelse(data4$affect_ml_b=="Weak",1,0)

data4$affect_ml_r2_p<-ifelse(data4$affect_ml_r=="Pleasant",1,0)
data4$affect_ml_r2_u<-ifelse(data4$affect_ml_r=="Unpleasant",1,0)
data4$affect_ml_r2_m<-ifelse(data4$affect_ml_r=="Mixed",1,0)
data4$affect_ml_r2_w<-ifelse(data4$affect_ml_r=="Weak",1,0)

data4$affect_pa_r2_p<-ifelse(data4$affect_pa_r=="Pleasant",1,0)
data4$affect_pa_r2_u<-ifelse(data4$affect_pa_r=="Unpleasant",1,0)
data4$affect_pa_r2_m<-ifelse(data4$affect_pa_r=="Mixed",1,0)
data4$affect_pa_r2_w<-ifelse(data4$affect_pa_r=="Weak",1,0)

data4$affect_pa_b2_p<-ifelse(data4$affect_pa_b=="Pleasant",1,0)
data4$affect_pa_b2_u<-ifelse(data4$affect_pa_b=="Unpleasant",1,0)
data4$affect_pa_b2_m<-ifelse(data4$affect_pa_b=="Mixed",1,0)
data4$affect_pa_b2_w<-ifelse(data4$affect_pa_b=="Weak",1,0)

data4$affect_pca2_p<-ifelse(data4$affect_pca=="Pleasant",1,0)
data4$affect_pca2_u<-ifelse(data4$affect_pca=="Unpleasant",1,0)
data4$affect_pca2_m<-ifelse(data4$affect_pca=="Mixed",1,0)
data4$affect_pca2_w<-ifelse(data4$affect_pca=="Weak",1,0)

data4$AffState2_p<-ifelse(data4$AffState=="Pleasant",1,0)
data4$AffState2_u<-ifelse(data4$AffState=="Unpleasant",1,0)
data4$AffState2_m<-ifelse(data4$AffState=="Mixed",1,0)
data4$AffState2_w<-ifelse(data4$AffState=="Weak",1,0)


model1.10p<-lm(affect_mr_b2_p~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10p<-coeftest(model1.10p, vcov=vcovHC(model1.10p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10p, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)



model1.10u<-lm(affect_mr_b2_u~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10u<-coeftest(model1.10u, vcov=vcovHC(model1.10u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10u, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)




model1.10m<-lm(affect_mr_b2_m~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10m<-coeftest(model1.10m, vcov=vcovHC(model1.10m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10m, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)



model1.10w<-lm(affect_mr_b2_w~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10w<-coeftest(model1.10w, vcov=vcovHC(model1.10w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10w, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model1.10.1p<-lm(affect_mr_r2_p~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10.1p<-coeftest(model1.10.1p, vcov=vcovHC(model1.10.1p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.1p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.1p, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model1.10.1u<-lm(affect_mr_r2_u~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10.1u<-coeftest(model1.10.1u, vcov=vcovHC(model1.10.1u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.1u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.1u, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model1.10.1m<-lm(affect_mr_r2_m~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10.1m<-coeftest(model1.10.1m, vcov=vcovHC(model1.10.1m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.1m, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model1.10.1w<-lm(affect_mr_r2_w~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==0,])
(coef1.10.1w<-coeftest(model1.10.1w, vcov=vcovHC(model1.10.1w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.1w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.1w, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model1.10.2p<-lm(affect_ml_b2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.2p<-coeftest(model1.10.2p, vcov=vcovHC(model1.10.2p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.2p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.2p, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.2u<-lm(affect_ml_b2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.2u<-coeftest(model1.10.2u, vcov=vcovHC(model1.10.2u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.2u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.2u, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.2m<-lm(affect_ml_b2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.2m<-coeftest(model1.10.2m, vcov=vcovHC(model1.10.2m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.2m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.2m, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.2w<-lm(affect_ml_b2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.2w<-coeftest(model1.10.2w, vcov=vcovHC(model1.10.2w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.2w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.2w, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


model1.10.3p<-lm(affect_ml_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.3p<-coeftest(model1.10.3p, vcov=vcovHC(model1.10.3p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.3p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.3p, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.3u<-lm(affect_ml_r2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.3u<-coeftest(model1.10.3u, vcov=vcovHC(model1.10.3u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.3u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.3u, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.3m<-lm(affect_ml_r2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.3m<-coeftest(model1.10.3m, vcov=vcovHC(model1.10.3m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.3m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.3m, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.3w<-lm(affect_ml_r2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.3w<-coeftest(model1.10.3w, vcov=vcovHC(model1.10.3w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.3w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.3w, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.4p<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.4p<-coeftest(model1.10.4p, vcov=vcovHC(model1.10.4p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.4p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.4p, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.4u<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.4u<-coeftest(model1.10.4u, vcov=vcovHC(model1.10.4u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.4u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.4u, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.4m<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.4m<-coeftest(model1.10.4m, vcov=vcovHC(model1.10.4m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.4m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.4m, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.4w<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.4w<-coeftest(model1.10.4w, vcov=vcovHC(model1.10.4w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.4w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.4w, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.5p<-lm(affect_pa_b2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.5p<-coeftest(model1.10.5p, vcov=vcovHC(model1.10.5p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.5p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.5p, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.5u<-lm(affect_pa_b2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.5u<-coeftest(model1.10.5u, vcov=vcovHC(model1.10.5u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.5u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.5u, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.5m<-lm(affect_pa_b2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.5m<-coeftest(model1.10.5m, vcov=vcovHC(model1.10.5m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.5m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.5m, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.5w<-lm(affect_pa_b2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.5w<-coeftest(model1.10.5w, vcov=vcovHC(model1.10.5w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.5w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.5w, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.6p<-lm(affect_pca2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.6p<-coeftest(model1.10.6p, vcov=vcovHC(model1.10.6p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.6p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.6p, type="HC0"))))
marginal_temp$dv<-"affect_pca2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.6u<-lm(affect_pca2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.6u<-coeftest(model1.10.6u, vcov=vcovHC(model1.10.6u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.6u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.6u, type="HC0"))))
marginal_temp$dv<-"affect_pca2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.6m<-lm(affect_pca2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.6m<-coeftest(model1.10.6m, vcov=vcovHC(model1.10.6m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.6m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.6m, type="HC0"))))
marginal_temp$dv<-"affect_pca2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.6w<-lm(affect_pca2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.6w<-coeftest(model1.10.6w, vcov=vcovHC(model1.10.6w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.6w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.6w, type="HC0"))))
marginal_temp$dv<-"affect_pca2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.7p<-lm(AffState2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.7p<-coeftest(model1.10.7p, vcov=vcovHC(model1.10.7p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.7p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.7p, type="HC0"))))
marginal_temp$dv<-"AffState2_p"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.7u<-lm(AffState2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.7u<-coeftest(model1.10.7u, vcov=vcovHC(model1.10.7u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.7u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.7u, type="HC0"))))
marginal_temp$dv<-"AffState2_u"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.7m<-lm(AffState2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.7m<-coeftest(model1.10.7m, vcov=vcovHC(model1.10.7m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.7m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.7m, type="HC0"))))
marginal_temp$dv<-"AffState2_m"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)

model1.10.7w<-lm(AffState2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==0,])
(coef1.10.7w<-coeftest(model1.10.7w, vcov=vcovHC(model1.10.7w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.10.7w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.10.7w, type="HC0"))))
marginal_temp$dv<-"AffState2_w"
marginal_temp$albanian<-0
marginal<-rbind(marginal, marginal_temp)


###Repeat for Albanians
model1.11p<-lm(affect_mr_b2_p~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==1,])
(coef1.11p<-coeftest(model1.11p, vcov=vcovHC(model1.11p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11p, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)



model1.11u<-lm(affect_mr_b2_u~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==1,])
(coef1.11u<-coeftest(model1.11u, vcov=vcovHC(model1.11u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11u, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)




model1.11m<-lm(affect_mr_b2_m~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==1,])
(coef1.11m<-coeftest(model1.11m, vcov=vcovHC(model1.11m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11m, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)



model1.11w<-lm(affect_mr_b2_w~ProfileNumber_f+ProfileSDSM
               +ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge,
               data=data4[data4$albanian==1,])
(coef1.11w<-coeftest(model1.11w, vcov=vcovHC(model1.11w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11w, type="HC0"))))
marginal_temp$dv<-"affect_mr_b2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model1.11.1p<-lm(affect_mr_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.1p<-coeftest(model1.11.1p, vcov=vcovHC(model1.11.1p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.1p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.1p, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model1.11.1u<-lm(affect_mr_r2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.1u<-coeftest(model1.11.1u, vcov=vcovHC(model1.11.1u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.1u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.1u, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model1.11.1m<-lm(affect_mr_r2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.1m<-coeftest(model1.11.1m, vcov=vcovHC(model1.11.1m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.1m, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model1.11.1w<-lm(affect_mr_r2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.1w<-coeftest(model1.11.1w, vcov=vcovHC(model1.11.1w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.1w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.1w, type="HC0"))))
marginal_temp$dv<-"affect_mr_r2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model1.11.2p<-lm(affect_ml_b2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.2p<-coeftest(model1.11.2p, vcov=vcovHC(model1.11.2p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.2p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.2p, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.2u<-lm(affect_ml_b2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.2u<-coeftest(model1.11.2u, vcov=vcovHC(model1.11.2u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.2u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.2u, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.2m<-lm(affect_ml_b2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.2m<-coeftest(model1.11.2m, vcov=vcovHC(model1.11.2m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.2m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.2m, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.2w<-lm(affect_ml_b2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.2w<-coeftest(model1.11.2w, vcov=vcovHC(model1.11.2w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.2w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.2w, type="HC0"))))
marginal_temp$dv<-"affect_ml_b2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)


model1.11.3p<-lm(affect_ml_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.3p<-coeftest(model1.11.3p, vcov=vcovHC(model1.11.3p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.3p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.3p, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.3u<-lm(affect_ml_r2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.3u<-coeftest(model1.11.3u, vcov=vcovHC(model1.11.3u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.3u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.3u, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.3m<-lm(affect_ml_r2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.3m<-coeftest(model1.11.3m, vcov=vcovHC(model1.11.3m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.3m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.3m, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.3w<-lm(affect_ml_r2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.3w<-coeftest(model1.11.3w, vcov=vcovHC(model1.11.3w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.3w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.3w, type="HC0"))))
marginal_temp$dv<-"affect_ml_r2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.4p<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.4p<-coeftest(model1.11.4p, vcov=vcovHC(model1.11.4p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.4p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.4p, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.4u<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.4u<-coeftest(model1.11.4u, vcov=vcovHC(model1.11.4u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.4u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.4u, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.4m<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.4m<-coeftest(model1.11.4m, vcov=vcovHC(model1.11.4m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.4m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.4m, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.4w<-lm(affect_pa_r2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.4w<-coeftest(model1.11.4w, vcov=vcovHC(model1.11.4w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.4w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.4w, type="HC0"))))
marginal_temp$dv<-"affect_pa_r2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.5p<-lm(affect_pa_b2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.5p<-coeftest(model1.11.5p, vcov=vcovHC(model1.11.5p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.5p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.5p, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.5u<-lm(affect_pa_b2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.5u<-coeftest(model1.11.5u, vcov=vcovHC(model1.11.5u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.5u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.5u, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.5m<-lm(affect_pa_b2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.5m<-coeftest(model1.11.5m, vcov=vcovHC(model1.11.5m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.5m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.5m, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.5w<-lm(affect_pa_b2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.5w<-coeftest(model1.11.5w, vcov=vcovHC(model1.11.5w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.5w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.5w, type="HC0"))))
marginal_temp$dv<-"affect_pa_b2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.6p<-lm(affect_pca2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.6p<-coeftest(model1.11.6p, vcov=vcovHC(model1.11.6p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.6p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.6p, type="HC0"))))
marginal_temp$dv<-"affect_pca2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.6u<-lm(affect_pca2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.6u<-coeftest(model1.11.6u, vcov=vcovHC(model1.11.6u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.6u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.6u, type="HC0"))))
marginal_temp$dv<-"affect_pca2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.6m<-lm(affect_pca2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.6m<-coeftest(model1.11.6m, vcov=vcovHC(model1.11.6m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.6m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.6m, type="HC0"))))
marginal_temp$dv<-"affect_pca2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.6w<-lm(affect_pca2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.6w<-coeftest(model1.11.6w, vcov=vcovHC(model1.11.6w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.6w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.6w, type="HC0"))))
marginal_temp$dv<-"affect_pca2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.7p<-lm(AffState2_p~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.7p<-coeftest(model1.11.7p, vcov=vcovHC(model1.11.7p, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.7p, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.7p, type="HC0"))))
marginal_temp$dv<-"AffState2_p"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.7u<-lm(AffState2_u~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.7u<-coeftest(model1.11.7u, vcov=vcovHC(model1.11.7u, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.7u, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.7u, type="HC0"))))
marginal_temp$dv<-"AffState2_u"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.7m<-lm(AffState2_m~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.7m<-coeftest(model1.11.7m, vcov=vcovHC(model1.11.7m, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.7m, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.7m, type="HC0"))))
marginal_temp$dv<-"AffState2_m"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

model1.11.7w<-lm(AffState2_w~ProfileNumber_f+ProfileSDSM
                 +ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge,
                 data=data4[data4$albanian==1,])
(coef1.11.7w<-coeftest(model1.11.7w, vcov=vcovHC(model1.11.7w, type="HC0")))
marginal_temp<-as.data.frame(summary(margins(model1.11.7w, 
                                             variables=c("ProfileNumber_f", "ProfileSubstantive", 
                                                         "ProfileCooperation", "ProfileSDSM"), 
                                             vcov = vcovHC(model1.11.7w, type="HC0"))))
marginal_temp$dv<-"AffState2_w"
marginal_temp$albanian<-1
marginal<-rbind(marginal, marginal_temp)

#save(marginal, file="marginal.RData")

#Table OA.4.1
#Just minres Barlett models
stargazer(model1.10p, model1.11p, model1.10u, model1.11u, model1.10m, model1.11m,
          model1.10w, model1.11w, se=list(coef1.10p[,2], coef1.11p[,2], coef1.10u[,2],
          coef1.11u[,2], coef1.10m[,2], coef1.11m[,2], coef1.10w[,2], coef1.11w[,2]))

#Macedonian models
stargazer(model1.10p, model1.10.1p, model1.10.2p, model1.10.3p, model1.10.4p,
          model1.10.5p, model1.10.6p, model1.10.7p, se=list(coef1.10p[,2],
          coef1.10.1p[,2], coef1.10.2p[,2], coef1.10.3p[,2], coef1.10.4p[,2],
          coef1.10.5p[,2], coef1.10.6p[,2], coef1.10.7p[,2]))

stargazer(model1.10u, model1.10.1u, model1.10.2u, model1.10.3u, model1.10.4u,
          model1.10.5u, model1.10.6u, model1.10.7u, se=list(coef1.10u[,2],
          coef1.10.1u[,2], coef1.10.2u[,2], coef1.10.3u[,2], coef1.10.4u[,2],
          coef1.10.5u[,2], coef1.10.6u[,2], coef1.10.7u[,2]))

stargazer(model1.10m, model1.10.1m, model1.10.2m, model1.10.3m, model1.10.4m,
          model1.10.5m, model1.10.6m, model1.10.7m, se=list(coef1.10m[,2],
          coef1.10.1m[,2], coef1.10.2m[,2], coef1.10.3m[,2], coef1.10.4m[,2],
          coef1.10.5m[,2], coef1.10.6m[,2], coef1.10.7m[,2]))

stargazer(model1.10w, model1.10.1w, model1.10.2w, model1.10.3w, model1.10.4w,
          model1.10.5w, model1.10.6w, model1.10.7w, se=list(coef1.10w[,2],
          coef1.10.1w[,2], coef1.10.2w[,2], coef1.10.3w[,2], coef1.10.4w[,2],
          coef1.10.5w[,2], coef1.10.6w[,2], coef1.10.7w[,2]))

#Albanian models
stargazer(model1.11p, model1.11.1p, model1.11.2p, model1.11.3p, model1.11.4p,
          model1.11.5p, model1.11.6p, model1.11.7p, se=list(coef1.11p[,2],
          coef1.11.1p[,2], coef1.11.2p[,2], coef1.11.3p[,2], coef1.11.4p[,2],
          coef1.11.5p[,2], coef1.11.6p[,2], coef1.11.7p[,2]))

stargazer(model1.11u, model1.11.1u, model1.11.2u, model1.11.3u, model1.11.4u,
          model1.11.5u, model1.11.6u, model1.11.7u, se=list(coef1.11u[,2],
          coef1.11.1u[,2], coef1.11.2u[,2], coef1.11.3u[,2], coef1.11.4u[,2],
          coef1.11.5u[,2], coef1.11.6u[,2], coef1.11.7u[,2]))

stargazer(model1.11m, model1.11.1m, model1.11.2m, model1.11.3m, model1.11.4m,
          model1.11.5m, model1.11.6m, model1.11.7m, se=list(coef1.11m[,2],
          coef1.11.1m[,2], coef1.11.2m[,2], coef1.11.3m[,2], coef1.11.4m[,2],
          coef1.11.5m[,2], coef1.11.6m[,2], coef1.11.7m[,2]))

stargazer(model1.11w, model1.11.1w, model1.11.2w, model1.11.3w, model1.11.4w,
          model1.11.5w, model1.11.6w, model1.11.7w, se=list(coef1.11w[,2],
          coef1.11.1w[,2], coef1.11.2w[,2], coef1.11.3w[,2], coef1.11.4w[,2],
          coef1.11.5w[,2], coef1.11.6w[,2], coef1.11.7w[,2]))


###Plots for main text

load("marginal.RData")

#Subset out all but the minres Bartlett for the main text



###Descriptive Plots
#Figure 1
descriptive_all<-marginal[marginal$factor=="ProfileNumber_f1" |
                            marginal$factor=="ProfileNumber_f10",]
rownames(descriptive_all)<-NULL
descriptive_all<-descriptive_all[c(1:56, 113:120),]
rownames(descriptive_all)<-NULL
descriptive_all$factor <- factor(descriptive_all$factor, levels = c("ProfileNumber_f10", "ProfileNumber_f1"),
                                 labels = c("10", "1"))
descriptive_all$dv<-factor(descriptive_all$dv,levels = c("ministerpersonal", "representsatisfied","benefitfinancial",
                                                         "benefityou","onegroup", "talkoutgroup", "neighbor", "equality", "trust",
                                                         "cabinetmodel", "cabinettrust", "cabinetrepresent", "affect_mr_b2_w",
                                                         "affect_mr_b2_m", "affect_mr_b2_u", "affect_mr_b2_p"),
                           labels=c("Min. Personal", "Rep. Satisfied",
                                    "Benefit Financial", "Benefit You", "One Group",
                                    "Talk Outgroup", "Neighbor", "Equality", "Trust",
                                    "Model", "Trust", "Represent",
                                    "Weak", "Mixed", "Unpleaseant", "Pleasant"))
descriptive_all$type<-c(rep("Outgroup Attitudes", 20), rep("Cabinet Perceptions", 12), rep("Mechanisms", 16), rep("Cabinet Affect", 16))
descriptive_all$type<-factor(descriptive_all$type, levels=c("Cabinet Affect", "Cabinet Perceptions", "Outgroup Attitudes", "Mechanisms"))
descriptive_all$factoralbanian<-as.factor(paste0(descriptive_all$factor,descriptive_all$albanian))
descriptive_all$factoralbanian <- factor(descriptive_all$factoralbanian, levels = c("10", "100", "11", "101"), 
                                         labels = c("MAC, 1", "MAC, 10", "ALB, 1", "ALB, 10"))

descriptive_all1 <- ggplot(data=descriptive_all, aes(dv, AME, color = factoralbanian, linetype=factoralbanian,
                                                     group = factoralbanian, shape = factoralbanian)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()+
  facet_wrap(~type, strip.position = "top", scales = "free_y")

descriptive_all2 <- descriptive_all1 + geom_linerange(data=descriptive_all, 
                                                      aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="Marginal Effect") + 
  coord_flip(ylim = c(-0.32, 0.32)) +  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=12)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 12))+
  labs(color  = "Group, Ministers", linetype = "Group, Ministers", shape = "Group, Ministers")+
  scale_linetype_manual( values= c("solid", "solid", "solid", "solid"))+
  scale_colour_manual(values = c("black", "gray45","orange3", "orange"))+
  scale_shape_manual( values = c(17,16,17,16))
descriptive_all2




###Substantive Plots
#Figure 2
substantive_all<-marginal[marginal$factor=="ProfileSubstantive",]
rownames(substantive_all)<-NULL
substantive_all<-substantive_all[c(1:28, 57:60),]
rownames(substantive_all)<-NULL
substantive_all$dv<-factor(substantive_all$dv,levels = c("ministerpersonal", "representsatisfied","benefitfinancial",
                                                         "benefityou","onegroup", "talkoutgroup", "neighbor", "equality", "trust",
                                                         "cabinetmodel", "cabinettrust", "cabinetrepresent", "affect_mr_b2_w",
                                                         "affect_mr_b2_m", "affect_mr_b2_u", "affect_mr_b2_p"),
                           labels=c("Min. Personal", "Rep. Satisfied",
                                    "Benefit Financial", "Benefit You", "One Group",
                                    "Talk Outgroup", "Neighbor", "Equality", "Trust",
                                    "Model", "Trust", "Represent",
                                    "Weak", "Mixed", "Unpleaseant", "Pleasant"))
substantive_all$type<-c(rep("Outgroup Attitudes", 10), rep("Cabinet Perceptions", 6), rep("Mechanisms", 8), rep("Cabinet Affect", 8))
substantive_all$type<-factor(substantive_all$type, levels=c("Cabinet Affect", "Cabinet Perceptions", "Outgroup Attitudes", "Mechanisms"))
substantive_all$albanian <- factor(1-substantive_all$albanian, levels = c("1", "0"), 
                                         labels = c("MAC", "ALB"))

substantive_all1 <- ggplot(data=substantive_all, aes(dv, AME, color = albanian, linetype=albanian,
                                                     group = albanian, shape = albanian)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()+
  facet_wrap(~type, strip.position = "top", scales = "free_y")

substantive_all2 <- substantive_all1 + geom_linerange(data=substantive_all, 
                                                      aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="Marginal Effect") + 
  coord_flip(ylim = c(-0.32, 0.32)) +  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=12)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 12))+
  labs(color  = "Group", linetype = "Group", shape = "Group")+
  scale_linetype_manual( values= c("solid", "solid"))+
  scale_colour_manual(values = c("black","orange3"))+
  scale_shape_manual( values = c(17,17))
substantive_all2









###Cooperation Plots
#Figure 3
cooperation_all<-marginal[marginal$factor=="ProfileCooperation" | marginal$factor=="ProfileSDSM",]
rownames(cooperation_all)<-NULL
cooperation_all<-cooperation_all[c(1:56, 113:120),]
rownames(cooperation_all)<-NULL
cooperation_all$factor <- factor(cooperation_all$factor, levels = c("ProfileSDSM", "ProfileCooperation"),
                                 labels = c("SDSM", "Cooperation"))
cooperation_all$dv<-factor(cooperation_all$dv,levels = c("ministerpersonal", "representsatisfied","benefitfinancial",
                                                         "benefityou","onegroup", "talkoutgroup", "neighbor", "equality", "trust",
                                                         "cabinetmodel", "cabinettrust", "cabinetrepresent", "affect_mr_b2_w",
                                                         "affect_mr_b2_m", "affect_mr_b2_u", "affect_mr_b2_p"),
                           labels=c("Min. Personal", "Rep. Satisfied",
                                    "Benefit Financial", "Benefit You", "One Group",
                                    "Talk Outgroup", "Neighbor", "Equality", "Trust",
                                    "Model", "Trust", "Represent",
                                    "Weak", "Mixed", "Unpleaseant", "Pleasant"))
cooperation_all$type<-c(rep("Outgroup Attitudes", 20), rep("Cabinet Perceptions", 12), rep("Mechanisms", 16), rep("Cabinet Affect", 16))
cooperation_all$type<-factor(cooperation_all$type, levels=c("Cabinet Affect", "Cabinet Perceptions", "Outgroup Attitudes", "Mechanisms"))
cooperation_all$factoralbanian<-as.factor(paste0(cooperation_all$factor,cooperation_all$albanian))
cooperation_all$factoralbanian <- factor(cooperation_all$factoralbanian, levels = c("Cooperation0", "SDSM0", "Cooperation1", "SDSM1"), 
                                         labels = c("MAC, Coop.", "MAC, SDSM", "ALB, Coop.", "ALB, SDSM"))


cooperation_all1 <- ggplot(data=cooperation_all, aes(dv, AME, color = factoralbanian, linetype=factoralbanian,
                                                     group = factoralbanian, shape = factoralbanian)) + 
  geom_point(stat="identity", position = position_dodge(width = .7, 
                                                        preserve = "total"), size=3) + theme_bw()+
  facet_wrap(~type, strip.position = "top", scales = "free_y")

cooperation_all2 <- cooperation_all1 + geom_linerange(data=cooperation_all, 
                                                      aes(ymin=lower,ymax=upper), position = position_dodge(width = .7, preserve = "total"), size=1.3) + 
  labs(x="",y="Marginal Effect") + 
  coord_flip(ylim = c(-0.32, 0.32)) +  theme(axis.title=element_text(size=12)) + theme(axis.text=element_text(size=12)) + 
  theme(legend.text=element_text(size=12)) + theme(legend.title=element_text(size=12)) + 
  geom_hline(yintercept = 0, lty=2) +  
  theme(legend.position = "right") +theme(strip.text.x = element_text(size = 12))+
  labs(color  = "Group, Type", linetype = "Group, Type", shape = "Group, Type")+
  scale_linetype_manual( values= c("solid", "solid", "solid", "solid"))+
  scale_colour_manual(values = c("black", "gray45","orange3", "orange"))+
  scale_shape_manual( values = c(17,16,17,16))
cooperation_all2


#P-value correction
descriptive_all.1<-descriptive_all[descriptive_all$factor=="1",]
descriptive_all.1a<-descriptive_all.1[descriptive_all.1$albanian==1,]
descriptive_all.1a$p

#Adjust for each theoretically distinct group of tests:
#outgroup attitudes, perceptions, mechanisms, and affect
c(p.adjust(descriptive_all.1a$p[1:5], "holm"),
  p.adjust(descriptive_all.1a$p[6:8], "holm"),
  p.adjust(descriptive_all.1a$p[9:12], "holm"),
  p.adjust(descriptive_all.1a$p[13:16], "holm"))


descriptive_all.1m<-descriptive_all.1[descriptive_all.1$albanian==0,]
descriptive_all.1m$p

c(p.adjust(descriptive_all.1m$p[1:5], "holm"),
  p.adjust(descriptive_all.1m$p[6:8], "holm"),
  p.adjust(descriptive_all.1m$p[9:12], "holm"),
  p.adjust(descriptive_all.1m$p[13:16], "holm"))


descriptive_all.10<-descriptive_all[descriptive_all$factor=="10",]
descriptive_all.10a<-descriptive_all.10[descriptive_all.10$albanian==1,]
descriptive_all.10a$p

c(p.adjust(descriptive_all.10a$p[1:5], "holm"),
  p.adjust(descriptive_all.10a$p[6:8], "holm"),
  p.adjust(descriptive_all.10a$p[9:12], "holm"),
  p.adjust(descriptive_all.10a$p[13:16], "holm"))



descriptive_all.10m<-descriptive_all.10[descriptive_all.10$albanian==0,]
descriptive_all.10m$p

c(p.adjust(descriptive_all.10m$p[1:5], "holm"),
  p.adjust(descriptive_all.10m$p[6:8], "holm"),
  p.adjust(descriptive_all.10m$p[9:12], "holm"),
  p.adjust(descriptive_all.10m$p[13:16], "holm"))


substantive_all.a<-substantive_all[substantive_all$albanian=="ALB",]
substantive_all.a$p

c(p.adjust(substantive_all.a$p[1:5], "holm"),
  p.adjust(substantive_all.a$p[6:8], "holm"),
  p.adjust(substantive_all.a$p[9:12], "holm"),
  p.adjust(substantive_all.a$p[13:16], "holm"))



substantive_all.m<-substantive_all[substantive_all$albanian=="MAC",]
substantive_all.m$p

c(p.adjust(substantive_all.m$p[1:5], "holm"),
  p.adjust(substantive_all.m$p[6:8], "holm"),
  p.adjust(substantive_all.m$p[9:12], "holm"),
  p.adjust(substantive_all.m$p[13:16], "holm"))


cooperation_all.1<-cooperation_all[cooperation_all$factor=="SDSM",]
cooperation_all.1a<-cooperation_all.1[cooperation_all.1$albanian==1,]
cooperation_all.1a$p

c(p.adjust(cooperation_all.1a$p[1:5], "holm"),
  p.adjust(cooperation_all.1a$p[6:8], "holm"),
  p.adjust(cooperation_all.1a$p[9:12], "holm"),
  p.adjust(cooperation_all.1a$p[13:16], "holm"))



cooperation_all.1m<-cooperation_all.1[cooperation_all.1$albanian==0,]
cooperation_all.1m$p

c(p.adjust(cooperation_all.1m$p[1:5], "holm"),
  p.adjust(cooperation_all.1m$p[6:8], "holm"),
  p.adjust(cooperation_all.1m$p[9:12], "holm"),
  p.adjust(cooperation_all.1m$p[13:16], "holm"))


cooperation_all.10<-cooperation_all[cooperation_all$factor=="Cooperation",]
cooperation_all.10a<-cooperation_all.10[cooperation_all.10$albanian==1,]
cooperation_all.10a$p

c(p.adjust(cooperation_all.10a$p[1:5], "holm"),
  p.adjust(cooperation_all.10a$p[6:8], "holm"),
  p.adjust(cooperation_all.10a$p[9:12], "holm"),
  p.adjust(cooperation_all.10a$p[13:16], "holm"))


cooperation_all.10m<-cooperation_all.10[cooperation_all.10$albanian==0,]
cooperation_all.10m$p

c(p.adjust(cooperation_all.10m$p[1:5], "holm"),
  p.adjust(cooperation_all.10m$p[6:8], "holm"),
  p.adjust(cooperation_all.10m$p[9:12], "holm"),
  p.adjust(cooperation_all.10m$p[13:16], "holm"))



###Mediation analysis
library(mediation)

extract_mediation_summary <- function (x) { 
  
  clp <- 100 * x$conf.level
  isLinear.y <- ((class(x$model.y)[1] %in% c("lm", "rq")) || 
                   (inherits(x$model.y, "glm") && x$model.y$family$family == 
                      "gaussian" && x$model.y$family$link == "identity") || 
                   (inherits(x$model.y, "survreg") && x$model.y$dist == 
                      "gaussian"))
  
  printone <- !x$INT && isLinear.y
  
  if (printone) {
    
    smat <- c(x$d1, x$d1.ci, x$d1.p)
    smat <- rbind(smat, c(x$z0, x$z0.ci, x$z0.p))
    smat <- rbind(smat, c(x$tau.coef, x$tau.ci, x$tau.p))
    smat <- rbind(smat, c(x$n0, x$n0.ci, x$n0.p))
    
    rownames(smat) <- c("ACME", "ADE", "Total Effect", "Prop. Mediated")
    
  } else {
    smat <- c(x$d0, x$d0.ci, x$d0.p)
    smat <- rbind(smat, c(x$d1, x$d1.ci, x$d1.p))
    smat <- rbind(smat, c(x$z0, x$z0.ci, x$z0.p))
    smat <- rbind(smat, c(x$z1, x$z1.ci, x$z1.p))
    smat <- rbind(smat, c(x$tau.coef, x$tau.ci, x$tau.p))
    smat <- rbind(smat, c(x$n0, x$n0.ci, x$n0.p))
    smat <- rbind(smat, c(x$n1, x$n1.ci, x$n1.p))
    smat <- rbind(smat, c(x$d.avg, x$d.avg.ci, x$d.avg.p))
    smat <- rbind(smat, c(x$z.avg, x$z.avg.ci, x$z.avg.p))
    smat <- rbind(smat, c(x$n.avg, x$n.avg.ci, x$n.avg.p))
    
    rownames(smat) <- c("ACME (control)", "ACME (treated)", 
                        "ADE (control)", "ADE (treated)", "Total Effect", 
                        "Prop. Mediated (control)", "Prop. Mediated (treated)", 
                        "ACME (average)", "ADE (average)", "Prop. Mediated (average)")
    
  }
  
  colnames(smat) <- c("Estimate", paste(clp, "% CI Lower", sep = ""), 
                      paste(clp, "% CI Upper", sep = ""), "p-value")
  smat
  
}

#No mediation effects

#Trust and Cabinet Trust
model6.med<-lm(Q16~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,])


model6.out<-lm(Q6~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q16*ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,])

med6.out<-mediate(model6.med, model6.out, treat="ProfileCooperation", 
                  mediator="Q16", sims=1000, robustSE=TRUE)

summary(med6.out)

model6.1.med<-lm(Q16~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])


model6.1.out<-lm(Q6~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q16*ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,])

med6.1.out<-mediate(model6.1.med, model6.1.out, treat="ProfileCooperation", 
                  mediator="Q16", sims=1000, robustSE=TRUE)

summary(med6.1.out)


#Equality and Cabinet Representation
model6.2.med<-lm(Q15~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])

model6.2.out<-lm(Q7~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q15*ProfileCooperation
               +female+age+married+education+householdsize+region2+region3+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==1,])

med6.2.out<-mediate(model6.2.med, model6.2.out, treat="ProfileCooperation", 
                  mediator="Q15", sims=1000, robustSE=TRUE)

summary(med6.2.out)


model6.3.med<-lm(Q15~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,])


model6.3.out<-lm(Q7~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q15*ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,])

med6.3.out<-mediate(model6.3.med, model6.3.out, treat="ProfileCooperation", 
                    mediator="Q15", sims=1000, robustSE=TRUE)

summary(med6.3.out)

#One group and model
model6.4.med<-lm(Q17~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,])

model6.4.out<-glm(ministerpersonal~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q17*ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], family="binomial")

med6.4.out<-mediate(model6.4.med, model6.4.out, treat="ProfileCooperation", 
                    mediator="Q17", sims=1000, robustSE=TRUE)

summary(med6.4.out)


model6.5.med<-lm(Q17~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,])

model6.5.out<-glm(ministerpersonal~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q17*ProfileCooperation
                  +female+age+married+education+householdsize+region+urban
                  +news+equalopportunity+authoritarian+knowledge, 
                  survey2[survey2$albanian==0,], family="binomial")

med6.5.out<-mediate(model6.5.med, model6.5.out, treat="ProfileCooperation", 
                    mediator="Q17", sims=1000, robustSE=TRUE)

summary(med6.5.out)


#Represent Satisfied and Cabinet Represent
model6.6.med<-lm(Q21~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,])

model6.6.out<-lm(Q15~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q21*ProfileCooperation
                  +female+age+married+education+householdsize+region2+region3+urban
                  +news+equalopportunity+authoritarian+knowledge, 
                  survey2[survey2$albanian==1,])

med6.6.out<-mediate(model6.6.med, model6.6.out, treat="ProfileCooperation", 
                    mediator="Q21", sims=1000, robustSE=TRUE)

summary(med6.6.out)


model6.7.med<-lm(Q21~ProfileNumber_f+ProfileSDSM+ProfileSubstantive+ProfileCooperation
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,])

model6.7.out<-lm(Q15~ProfileSubstantive+ProfileNumber_f+ProfileSDSM+Q21*ProfileCooperation
                  +female+age+married+education+householdsize+region+urban
                  +news+equalopportunity+authoritarian+knowledge, 
                  survey2[survey2$albanian==0,])

med6.7.out<-mediate(model6.7.med, model6.7.out, treat="ProfileCooperation", 
                    mediator="Q21", sims=1000, robustSE=TRUE)

summary(med6.7.out)


xtable(rbind(extract_mediation_summary(med6.out), 
             extract_mediation_summary(med6.1.out)))
xtable(rbind(extract_mediation_summary(med6.2.out), 
             extract_mediation_summary(med6.3.out)))
xtable(rbind(extract_mediation_summary(med6.4.out), 
             extract_mediation_summary(med6.5.out)))
xtable(rbind(extract_mediation_summary(med6.6.out), 
             extract_mediation_summary(med6.7.out)))




#Model Based Exploratory Analysis
library(factorEx)
target_dist_marginal <- OnoBurden$target_dist_marginal

survey4<-survey2[,c("Q16", "ProfileSubstantive", 
                    "ProfileCooperation", "ProfileNumber", "ProfileSDSM","albanian")]
survey4$ProfileSubstantive<-ifelse(survey4$ProfileSubstantive==1,"Yes1", "No1")
survey4$ProfileSubstantive<-as.factor(survey4$ProfileSubstantive)
survey4$ProfileCooperation<-ifelse(survey4$ProfileCooperation==1,"Yes2", "No2")
survey4$ProfileCooperation<-as.factor(survey4$ProfileCooperation)
survey4$ProfileSDSM<-ifelse(survey4$ProfileSDSM==1,"Yes3", "No3")
survey4$ProfileSDSM<-as.factor(survey4$ProfileSDSM)
survey4$ProfileNumber<-ifelse(survey4$ProfileNumber==0,"Zero", survey4$ProfileNumber)
survey4$ProfileNumber<-ifelse(survey4$ProfileNumber==1,"One", survey4$ProfileNumber)
survey4$ProfileNumber<-ifelse(survey4$ProfileNumber==6,"Six", survey4$ProfileNumber)
survey4$ProfileNumber<-ifelse(survey4$ProfileNumber==10,"Ten", survey4$ProfileNumber)
survey4$ProfileNumber<-as.factor(survey4$ProfileNumber)
survey4$ProfileNumber_f<-as.factor(survey4$ProfileNumber)

target_dist_marginal_small <- target_dist_marginal[c("gender", "party", "experience", "pos_security")]
names(target_dist_marginal_small)<-c("ProfileSubstantive","ProfileCooperation", "ProfileNumber_f", "ProfileSDSM")
names(target_dist_marginal_small$ProfileSubstantive)<-c("Yes1","No1")
names(target_dist_marginal_small$ProfileCooperation)<-c("Yes2","No2")
names(target_dist_marginal_small$ProfileSDSM)<-c("Yes3","No3")
names(target_dist_marginal_small$ProfileNumber_f)<-c("Zero","One", "Six", "Ten")

#Have to run with one as default number of ministers

q16_data<-as.data.frame(matrix(nrow=1000, ncol=25))
colnames(q16_data)<-c('Substantive', 'Cooperation', 'SDSM', 'ProfileNumber0',
                      'ProfileNumber1', 'ProfileNumber6', 'ProfileNumber10',
                      'ProfileSubstantive_e', 'ProfileSubstantive_sd', 'ProfileSubstantive_p',
                      'ProfileCooperation_e', 'ProfileCooperation_sd', 'ProfileCooperation_p',
                      'ProfileSDSM_e', 'ProfileSDSM_sd', 'ProfileSDSM_p',
                      'ProfileNumber6_e', 'ProfileNumber6_sd', 'ProfileNumber6_p',
                      'ProfileNumber10_e', 'ProfileNumber10_sd', 'ProfileNumber10_p',
                      'ProfileNumber0_e', 'ProfileNumber0_sd', 'ProfileNumber0_p')

# for(i in 1:1000){
# q16_data[i,1]<-Substantive<-runif(1)
# q16_data[i,2]<-Cooperation<-runif(1)
# q16_data[i,3]<-SDSM<-runif(1)
# ProfileNumber<-runif(4,0,1)
# ProfileNumber_s<-ProfileNumber/sum(ProfileNumber)
# q16_data[i,4]<-ProfileNumber0<-ProfileNumber[1]
# q16_data[i,5]<-ProfileNumber1<-ProfileNumber[2]
# q16_data[i,6]<-ProfileNumber6<-ProfileNumber[3]
# q16_data[i,7]<-ProfileNumber10<-ProfileNumber[4]
# 
# target_dist_marginal_small$ProfileSubstantive[1:2]<-c(Substantive, (1-Substantive))
# target_dist_marginal_small$ProfileCooperation[1:2]<-c(Cooperation, (1-Cooperation))
# target_dist_marginal_small$ProfileSDSM[1:2]<-c(SDSM, (1-SDSM))
# target_dist_marginal_small$ProfileNumber_f[1:4]<-c(ProfileNumber0, ProfileNumber1,
#                                                    ProfileNumber6, ProfileNumber10)
# 
# model7<-model_pAMCE(formula=Q16~ProfileSubstantive+ProfileCooperation+
#                       ProfileSDSM+ProfileNumber_f,
#                     data=survey4[survey4$albanian==1,],
#                     reg=FALSE,
#                     target_dist=target_dist_marginal_small,
#                     target_type="marginal", boot=500)
# a<-summary(model7)
# estimate<-a$Estimate
# stderror<-a$`Std. Error`
# pvalue<-a$`p value`
# q16_data[i,8]<-estimate[1]
# q16_data[i,9]<-stderror[1]
# q16_data[i,10]<-pvalue[1]
# q16_data[i,11]<-estimate[2]
# q16_data[i,12]<-stderror[2]
# q16_data[i,13]<-pvalue[2]
# q16_data[i,14]<-estimate[3]
# q16_data[i,15]<-stderror[3]
# q16_data[i,16]<-pvalue[3]
# q16_data[i,17]<-estimate[4]
# q16_data[i,18]<-stderror[4]
# q16_data[i,19]<-pvalue[4]
# q16_data[i,20]<-estimate[5]
# q16_data[i,21]<-stderror[5]
# q16_data[i,22]<-pvalue[5]
# q16_data[i,23]<-estimate[6]
# q16_data[i,24]<-stderror[6]
# q16_data[i,25]<-pvalue[6]
# }

#Albanian=1
#save(q16_data,file='q16_data.Rdata')


#Change to Albanian=0
# for(i in 1:1000){
#   q16_data[i,1]<-Substantive<-runif(1)
#   q16_data[i,2]<-Cooperation<-runif(1)
#   q16_data[i,3]<-SDSM<-runif(1)
#   ProfileNumber<-runif(4,0,1)
#   ProfileNumber_s<-ProfileNumber/sum(ProfileNumber)
#   q16_data[i,4]<-ProfileNumber0<-ProfileNumber[1]
#   q16_data[i,5]<-ProfileNumber1<-ProfileNumber[2]
#   q16_data[i,6]<-ProfileNumber6<-ProfileNumber[3]
#   q16_data[i,7]<-ProfileNumber10<-ProfileNumber[4]
#   
#   target_dist_marginal_small$ProfileSubstantive[1:2]<-c(Substantive, (1-Substantive))
#   target_dist_marginal_small$ProfileCooperation[1:2]<-c(Cooperation, (1-Cooperation))
#   target_dist_marginal_small$ProfileSDSM[1:2]<-c(SDSM, (1-SDSM))
#   target_dist_marginal_small$ProfileNumber_f[1:4]<-c(ProfileNumber0, ProfileNumber1,
#                                                      ProfileNumber6, ProfileNumber10)
#   
#   model7<-model_pAMCE(formula=Q16~ProfileSubstantive+ProfileCooperation+
#                         ProfileSDSM+ProfileNumber_f,
#                       data=survey4[survey4$albanian==0,],
#                       reg=FALSE,
#                       target_dist=target_dist_marginal_small,
#                       target_type="marginal", boot=500)
#   a<-summary(model7)
#   estimate<-a$Estimate
#   stderror<-a$`Std. Error`
#   pvalue<-a$`p value`
#   q16_data[i,8]<-estimate[1]
#   q16_data[i,9]<-stderror[1]
#   q16_data[i,10]<-pvalue[1]
#   q16_data[i,11]<-estimate[2]
#   q16_data[i,12]<-stderror[2]
#   q16_data[i,13]<-pvalue[2]
#   q16_data[i,14]<-estimate[3]
#   q16_data[i,15]<-stderror[3]
#   q16_data[i,16]<-pvalue[3]
#   q16_data[i,17]<-estimate[4]
#   q16_data[i,18]<-stderror[4]
#   q16_data[i,19]<-pvalue[4]
#   q16_data[i,20]<-estimate[5]
#   q16_data[i,21]<-stderror[5]
#   q16_data[i,22]<-pvalue[5]
#   q16_data[i,23]<-estimate[6]
#   q16_data[i,24]<-stderror[6]
#   q16_data[i,25]<-pvalue[6]
# }
#save(q16_data,file='q16_data_macedonian.Rdata')


#Albanian=0
load("q16_data_macedonian.Rdata")
q16_data_macedonian<-q16_data

predictSDSM2<-lm(ProfileSDSM_p~Cooperation+Substantive+
                   SDSM+ProfileNumber0+ProfileNumber6+ProfileNumber10, q16_data_macedonian)

q16_data2_m<-q16_data_macedonian[q16_data_macedonian$ProfileSDSM_p<0.1,]
mean(q16_data2_m$Cooperation)
mean(q16_data2_m$Substantive)
mean(q16_data2_m$SDSM)
mean(q16_data2_m$ProfileNumber0)
mean(q16_data2_m$ProfileNumber1)
mean(q16_data2_m$ProfileNumber6)
mean(q16_data2_m$ProfileNumber10)



#Albanian=1
load("q16_data.Rdata")

predictSDSM<-lm(ProfileSDSM_p~Cooperation+Substantive+
        SDSM+ProfileNumber0+ProfileNumber6+ProfileNumber10, q16_data)

q16_data2<-q16_data[q16_data$ProfileSDSM_p<0.1,]
mean(q16_data2$Cooperation)
mean(q16_data$Substantive)
mean(q16_data2$SDSM)
mean(q16_data2$ProfileNumber0)
mean(q16_data2$ProfileNumber1)
mean(q16_data2$ProfileNumber6)
mean(q16_data2$ProfileNumber10)

par(lwd=2, mfrow=c(1,2))
hist(q16_data$ProfileSDSM_p, main="Albanian ProfileSDSM P-Values",
     ylim=c(0,245), xlab="ProfileSDSM P-Value", 
     cex.main=1.2, cex.axis=1.2, cex.lab=1.2, lwd=2)

hist(q16_data_macedonian$ProfileSDSM_p, main="Macedonian ProfileSDSM P-Values",
     ylim=c(0,245), xlab="ProfileSDSM P-Value", 
     cex.main=1.2, cex.axis=1.2, cex.lab=1.2, lwd=2)
dev.off()

par(mfrow=c(1,2))
plot(Substantive~ProfileSDSM_p, q16_data, main='Albanian Substantive Pct.',
     xlab="ProfileSDSM P-Value", ylab="Substantive Pct.",
     cex.main=1.2, cex.axis=1.2, cex.lab=1.2, lwd=2)
abline(v=0.1, lwd=6, col='red')
plot(Substantive~ProfileSDSM_p, q16_data_macedonian, main="Macedoniann Substantive Pct.",
     xlab="ProfileSDSM P-Value", ylab="Substantive Pct.",
     cex.main=1.2, cex.axis=1.2, cex.lab=1.2, lwd=2)
abline(v=0.1, lwd=6, col='red')

dev.off()




###Randomization checks
library(nnet)
model0<-multinom(ProfileNumber_f~female+age+married+education+householdsize+
                   region+urban
                 , data=survey2)
z <- summary(model0)$coefficients/summary(model0)$standard.errors
(p <- (1 - pnorm(abs(z), 0, 1)) * 2)

model0.1<-multinom(ProfileCooperation~female+age+married+education+householdsize+
                     region+urban
                 , data=survey2)
z.1 <- summary(model0.1)$coefficients/summary(model0.1)$standard.errors
(p.1 <- (1 - pnorm(abs(z.1), 0, 1)) * 2)


model0.2<-multinom(ProfileSDSM~female+age+married+education+householdsize+
                     region+urban
                   , data=survey2)
z.2 <- summary(model0.2)$coefficients/summary(model0.2)$standard.errors
(p.2 <- (1 - pnorm(abs(z.2), 0, 1)) * 2)


model0.3<-multinom(ProfileSubstantive~female+age+married+education+householdsize+
                     region+urban
                   , data=survey2)
z.3 <- summary(model0.3)$coefficients/summary(model0.3)$standard.errors
(p.3 <- (1 - pnorm(abs(z.3), 0, 1)) * 2)


model0.4<-multinom(Profile~female+age+married+education+householdsize+
                     region+urban
                   , data=survey2)
#z.4 <- summary(model0.4)$coefficients/summary(model0.4)$standard.errors
#(p.4 <- (1 - pnorm(abs(z.4), 0, 1)) * 2)


#Table OA.2.1
stargazer(model0, model0.1, model0.2, model0.3)

#Table OA.2.2
stargazer(model0.4)


#Balance Checks
#Table OA.2.3

#Cooperation
(model0.5<-lm(ProfileCooperation~female, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$female)
mean(survey2[survey2$ProfileCooperation==0,]$female)
(model0.6<-lm(ProfileCooperation~age, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$age)
mean(survey2[survey2$ProfileCooperation==0,]$age)
(model0.7<-lm(ProfileCooperation~married, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileCooperation==0,]$married, na.rm=T)
(model0.8<-lm(ProfileCooperation~education, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$education)
mean(survey2[survey2$ProfileCooperation==0,]$education)
(model0.9<-lm(ProfileCooperation~householdsize, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$householdsize)
mean(survey2[survey2$ProfileCooperation==0,]$householdsize)
(model0.10<-lm(ProfileCooperation~Skopje, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$Skopje)
mean(survey2[survey2$ProfileCooperation==0,]$Skopje)
(model0.11<-lm(ProfileCooperation~urban, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$urban)
mean(survey2[survey2$ProfileCooperation==0,]$urban)
(model0.12<-lm(ProfileCooperation~albanian, data=survey2))
mean(survey2[survey2$ProfileCooperation==1,]$albanian)
mean(survey2[survey2$ProfileCooperation==0,]$albanian)

#Substantive
(model0.13<-lm(ProfileSubstantive~female, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$female)
mean(survey2[survey2$ProfileSubstantive==0,]$female)
(model0.14<-lm(ProfileSubstantive~age, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$age)
mean(survey2[survey2$ProfileSubstantive==0,]$age)
(model0.15<-lm(ProfileSubstantive~married, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileSubstantive==0,]$married, na.rm=T)
(model0.16<-lm(ProfileSubstantive~education, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$education)
mean(survey2[survey2$ProfileSubstantive==0,]$education)
(model0.17<-lm(ProfileSubstantive~householdsize, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$householdsize)
mean(survey2[survey2$ProfileSubstantive==0,]$householdsize)
(model0.18<-lm(ProfileSubstantive~Skopje, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$Skopje)
mean(survey2[survey2$ProfileSubstantive==0,]$Skopje)
(model0.19<-lm(ProfileSubstantive~urban, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$urban)
mean(survey2[survey2$ProfileSubstantive==0,]$urban)
(model0.20<-lm(ProfileSubstantive~albanian, data=survey2))
mean(survey2[survey2$ProfileSubstantive==1,]$albanian)
mean(survey2[survey2$ProfileSubstantive==0,]$albanian)

#SDSM
(model0.21<-lm(ProfileSDSM~female, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$female)
mean(survey2[survey2$ProfileSDSM==0,]$female)
(model0.22<-lm(ProfileSDSM~age, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$age)
mean(survey2[survey2$ProfileSDSM==0,]$age)
(model0.23<-lm(ProfileSDSM~married, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileSDSM==0,]$married, na.rm=T)
(model0.24<-lm(ProfileSDSM~education, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$education)
mean(survey2[survey2$ProfileSDSM==0,]$education)
(model0.25<-lm(ProfileSDSM~householdsize, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$householdsize)
mean(survey2[survey2$ProfileSDSM==0,]$householdsize)
(model0.26<-lm(ProfileSDSM~Skopje, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$Skopje)
mean(survey2[survey2$ProfileSDSM==0,]$Skopje)
(model0.27<-lm(ProfileSDSM~urban, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$urban)
mean(survey2[survey2$ProfileSDSM==0,]$urban)
(model0.28<-lm(ProfileSDSM~albanian, data=survey2))
mean(survey2[survey2$ProfileSDSM==1,]$albanian)
mean(survey2[survey2$ProfileSDSM==0,]$albanian)

#ProfileNumber_f
survey2$ProfileNumber0<-ifelse(survey2$ProfileNumber==0,1,0)

(model0.29<-lm(ProfileNumber0~female, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$female)
mean(survey2[survey2$ProfileNumber0==0,]$female)
(model0.30<-lm(ProfileNumber0~age, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$age)
mean(survey2[survey2$ProfileNumber0==0,]$age)
(model0.31<-lm(ProfileNumber0~married, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileNumber0==0,]$married, na.rm=T)
(model0.32<-lm(ProfileNumber0~education, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$education)
mean(survey2[survey2$ProfileNumber0==0,]$education)
(model0.33<-lm(ProfileNumber0~householdsize, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$householdsize)
mean(survey2[survey2$ProfileNumber0==0,]$householdsize)
(model0.34<-lm(ProfileNumber0~Skopje, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$Skopje)
mean(survey2[survey2$ProfileNumber0==0,]$Skopje)
(model0.35<-lm(ProfileNumber0~urban, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$urban)
mean(survey2[survey2$ProfileNumber0==0,]$urban)
(model0.36<-lm(ProfileNumber0~albanian, data=survey2))
mean(survey2[survey2$ProfileNumber0==1,]$albanian)
mean(survey2[survey2$ProfileNumber0==0,]$albanian)

survey2$ProfileNumber1<-ifelse(survey2$ProfileNumber==1,1,0)

(model0.37<-lm(ProfileNumber1~female, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$female)
mean(survey2[survey2$ProfileNumber1==0,]$female)
(model0.38<-lm(ProfileNumber1~age, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$age)
mean(survey2[survey2$ProfileNumber1==0,]$age)
(model0.39<-lm(ProfileNumber1~married, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileNumber1==0,]$married, na.rm=T)
(model0.40<-lm(ProfileNumber1~education, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$education)
mean(survey2[survey2$ProfileNumber1==0,]$education)
(model0.41<-lm(ProfileNumber1~householdsize, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$householdsize)
mean(survey2[survey2$ProfileNumber1==0,]$householdsize)
(model0.42<-lm(ProfileNumber1~Skopje, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$Skopje)
mean(survey2[survey2$ProfileNumber1==0,]$Skopje)
(model0.43<-lm(ProfileNumber1~urban, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$urban)
mean(survey2[survey2$ProfileNumber1==0,]$urban)
(model0.44<-lm(ProfileNumber1~albanian, data=survey2))
mean(survey2[survey2$ProfileNumber1==1,]$albanian)
mean(survey2[survey2$ProfileNumber1==0,]$albanian)

survey2$ProfileNumber6<-ifelse(survey2$ProfileNumber==6,1,0)

(model0.45<-lm(ProfileNumber6~female, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$female)
mean(survey2[survey2$ProfileNumber6==0,]$female)
(model0.46<-lm(ProfileNumber6~age, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$age)
mean(survey2[survey2$ProfileNumber6==0,]$age)
(model0.47<-lm(ProfileNumber6~married, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileNumber6==0,]$married, na.rm=T)
(model0.48<-lm(ProfileNumber6~education, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$education)
mean(survey2[survey2$ProfileNumber6==0,]$education)
(model0.49<-lm(ProfileNumber6~householdsize, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$householdsize)
mean(survey2[survey2$ProfileNumber6==0,]$householdsize)
(model0.50<-lm(ProfileNumber6~Skopje, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$Skopje)
mean(survey2[survey2$ProfileNumber6==0,]$Skopje)
(model0.51<-lm(ProfileNumber6~urban, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$urban)
mean(survey2[survey2$ProfileNumber6==0,]$urban)
(model0.52<-lm(ProfileNumber6~albanian, data=survey2))
mean(survey2[survey2$ProfileNumber6==1,]$albanian)
mean(survey2[survey2$ProfileNumber6==0,]$albanian)

survey2$ProfileNumber10<-ifelse(survey2$ProfileNumber==10,1,0)

(model0.53<-lm(ProfileNumber10~female, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$female)
mean(survey2[survey2$ProfileNumber10==0,]$female)
(model0.54<-lm(ProfileNumber10~age, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$age)
mean(survey2[survey2$ProfileNumber10==0,]$age)
(model0.55<-lm(ProfileNumber10~married, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$married, na.rm=T)
mean(survey2[survey2$ProfileNumber10==0,]$married, na.rm=T)
(model0.56<-lm(ProfileNumber10~education, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$education)
mean(survey2[survey2$ProfileNumber10==0,]$education)
(model0.57<-lm(ProfileNumber10~householdsize, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$householdsize)
mean(survey2[survey2$ProfileNumber10==0,]$householdsize)
(model0.58<-lm(ProfileNumber10~Skopje, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$Skopje)
mean(survey2[survey2$ProfileNumber10==0,]$Skopje)
(model0.59<-lm(ProfileNumber10~urban, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$urban)
mean(survey2[survey2$ProfileNumber10==0,]$urban)
(model0.60<-lm(ProfileNumber10~albanian, data=survey2))
mean(survey2[survey2$ProfileNumber10==1,]$albanian)
mean(survey2[survey2$ProfileNumber10==0,]$albanian)


#Wald Test
model0.61<-lm(ProfileCooperation~female+age+married+education+householdsize+
                region+urban
                   , data=survey2)
waldtest(model0.61)

model0.62<-lm(ProfileSubstantive~female+age+married+education+householdsize+
                region+urban
             , data=survey2)
waldtest(model0.62)

model0.63<-lm(ProfileSDSM~female+age+married+education+householdsize+
                region+urban
             , data=survey2)
waldtest(model0.63)

model0.64<-lm(ProfileNumber~female+age+married+education+householdsize+
                region+urban
             , data=survey2)
waldtest(model0.64)

model0.65<-lm(ProfileNumber0~female+age+married+education+householdsize+
                region+urban
              , data=survey2)
waldtest(model0.65)

model0.66<-lm(ProfileNumber1~female+age+married+education+householdsize+
                region+urban
              , data=survey2)
waldtest(model0.66)

model0.67<-lm(ProfileNumber6~female+age+married+education+householdsize+
                region+urban
              , data=survey2)
waldtest(model0.67)

model0.68<-lm(ProfileNumber10~female+age+married+education+householdsize+
                region+urban
              , data=survey2)
waldtest(model0.68)







###Heterogeneous effects by Macedonian nationalist party
#Trust
model7<-polr(trust~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
             +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)

#Equality
model7.1<-polr(equality~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
               +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

#Neighbor
model7.2<-polr(neighbor~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
               +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)


#Talkoutgroup
model7.3<-polr(talkoutgroup~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
               +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)


#Onegroup
model7.4<-glm(onegroup~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
              +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
              +female+age+married+education+householdsize+region+urban
              +news+equalopportunity+authoritarian+knowledge, 
              survey2[survey2$albanian==0,], family="binomial")
exp(coef(model7.4))


#Cabinetrepresent
model7.5<-polr(cabinetrepresent~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
                +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,], Hess=TRUE)

#Cabinettrust
model7.6<-polr(cabinettrust~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
                +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,], Hess=TRUE)


#Cabinetmodel
model7.7<-polr(cabinetmodel~ProfileNumber_f*party_nationalist+ProfileSDSM*party_nationalist
                +ProfileSubstantive*party_nationalist+ProfileCooperation*party_nationalist
                +female+age+married+education+householdsize+region+urban
                +news+equalopportunity+authoritarian+knowledge, 
                survey2[survey2$albanian==0,], Hess=TRUE)


#Table OA.6.6
stargazer(model7, model7.1, model7.2, model7.3, model7.4, model7.5, model7.6, model7.7)





###Interactions between IVs
#Trust
model8<-polr(trust~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
             +ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)

model8.0.1<-polr(trust~ProfileNumber_f*ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)

model8.0.2<-polr(trust~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.0.3<-polr(trust~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
             +ProfileCooperation
             +female+age+married+education+householdsize+region2+region3+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==1,], Hess=TRUE)

model8.0.4<-polr(trust~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.0.5<-polr(trust~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)





#Equality
model8.1<-polr(equality~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
             +ProfileCooperation
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,], Hess=TRUE)

model8.1.1<-polr(equality~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.1.2<-polr(equality~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.1.3<-polr(equality~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.1.4<-polr(equality~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.1.5<-polr(equality~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)






#Neighbor
model8.2<-polr(neighbor~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
               +ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.2.1<-polr(neighbor~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.2.2<-polr(neighbor~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.2.3<-polr(neighbor~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.2.4<-polr(neighbor~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.2.5<-polr(neighbor~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)



#Talkoutgroup
model8.3<-polr(talkoutgroup~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
               +ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.3.1<-polr(talkoutgroup~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.3.2<-polr(talkoutgroup~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.3.3<-polr(talkoutgroup~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.3.4<-polr(talkoutgroup~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.3.5<-polr(talkoutgroup~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

#Onegroup
model8.4<-glm(onegroup~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
               +ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], family="binomial")

model8.4.1<-glm(onegroup~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], family="binomial")

model8.4.2<-glm(onegroup~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], family="binomial")

model8.4.3<-glm(onegroup~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], family="binomial")

model8.4.4<-glm(onegroup~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], family="binomial")

model8.4.5<-glm(onegroup~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], family="binomial")




#Cabinetrepresent
model8.5<-polr(cabinetrepresent~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
               +ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.5.1<-polr(cabinetrepresent~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.5.2<-polr(cabinetrepresent~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.5.3<-polr(cabinetrepresent~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.5.4<-polr(cabinetrepresent~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.5.5<-polr(cabinetrepresent~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)


#Cabinettrust
model8.6<-polr(cabinettrust~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
               +ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.6.1<-polr(cabinettrust~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.6.2<-polr(cabinettrust~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.6.3<-polr(cabinettrust~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.6.4<-polr(cabinettrust~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.6.5<-polr(cabinettrust~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)



#Cabinetmodel
model8.7<-polr(cabinetmodel~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
               +ProfileCooperation
               +female+age+married+education+householdsize+region+urban
               +news+equalopportunity+authoritarian+knowledge, 
               survey2[survey2$albanian==0,], Hess=TRUE)

model8.7.1<-polr(cabinetmodel~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.7.2<-polr(cabinetmodel~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==0,], Hess=TRUE)

model8.7.3<-polr(cabinetmodel~ProfileNumber_f*ProfileSubstantive+ProfileSDSM
                 +ProfileCooperation
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.7.4<-polr(cabinetmodel~ProfileNumber_f*ProfileCooperation+ProfileSDSM
                 +ProfileSubstantive
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)

model8.7.5<-polr(cabinetmodel~ProfileNumber_f+ProfileCooperation*ProfileSubstantive+ProfileSDSM
                 +female+age+married+education+householdsize+region2+region3+urban
                 +news+equalopportunity+authoritarian+knowledge, 
                 survey2[survey2$albanian==1,], Hess=TRUE)


#Table OA.7.1
stargazer(model8, model8.0.1, model8.0.2, model8.0.3, model8.0.4, model8.0.5)

#Table OA.7.2
stargazer(model8.1, model8.1.1, model8.1.2, model8.1.3, model8.1.4, model8.1.5)

#Table OA.7.3
stargazer(model8.2, model8.2.1, model8.2.2, model8.2.3, model8.2.4, model8.2.5)

#Table OA.7.4
stargazer(model8.3, model8.3.1, model8.3.2, model8.3.3, model8.3.4, model8.3.5)

#Table OA.7.5
stargazer(model8.4, model8.4.1, model8.4.2, model8.4.3, model8.4.4, model8.4.5)

#Table OA.7.6
stargazer(model8.5, model8.5.1, model8.5.2, model8.5.3, model8.5.4, model8.5.5)

#Table OA.7.7
stargazer(model8.6, model8.6.1, model8.6.2, model8.6.3, model8.6.4, model8.6.5)

#Table OA.7.8
stargazer(model8.7, model8.7.1, model8.7.2, model8.7.3, model8.7.4, model8.7.5)










###Cabinet Preferences
survey2$cabinetchoice<-as.factor(survey2$Q22)

#Table OA.1.1
xtable(table(survey2$cabinetchoice, survey2$albanian)/
         colSums(table(survey2$cabinetchoice, survey2$albanian)), type="latex")

#1=culture, 2=welfare, 3=international, 4=economy
survey2$cabinetcoded<-ifelse(survey2$cabinetchoice==9|
                               survey2$cabinetchoice==10|
                               survey2$cabinetchoice==16|
                               survey2$cabinetchoice==17|
                               survey2$cabinetchoice==23,1,NA)
survey2$cabinetcoded<-ifelse(survey2$cabinetchoice==2|
                               survey2$cabinetchoice==3|
                               survey2$cabinetchoice==8|
                               survey2$cabinetchoice==11,2,survey2$cabinetcoded)
survey2$cabinetcoded<-ifelse(survey2$cabinetchoice==1|
                               survey2$cabinetchoice==13|
                               survey2$cabinetchoice==19|
                               survey2$cabinetchoice==22,3,survey2$cabinetcoded)
survey2$cabinetcoded<-ifelse(is.na(survey2$cabinetcoded),4,survey2$cabinetcoded)
survey2$cabinetcoded<-as.factor(survey2$cabinetcoded)

#Table OA.1.2
xtable(table(survey2$cabinetcoded, survey2$albanian)/
         colSums(table(survey2$cabinetcoded, survey2$albanian)), type="latex")




###Manipulation Check
survey2$hiring_ethnicity<-survey2$Q23
survey2$employee_ethnicity<-survey2$Q24
survey2$ministerfinancial<-survey2$Q25
survey2$ministerconcerns<-survey2$Q26


model9<-lm(hiring_ethnicity~ProfileNumber_f+ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,])
(coef9<-coeftest(model9, vcov=vcovHC(model9, type="HC0")))


model9.1<-lm(hiring_ethnicity~ProfileNumber_f+ProfileCooperation+ProfileSDSM
           +ProfileSubstantive
           +female+age+married+education+householdsize+region2+region3+urban
           +news+equalopportunity+authoritarian+knowledge, 
           survey2[survey2$albanian==1,])
(coef9.1<-coeftest(model9.1, vcov=vcovHC(model9.1, type="HC0")))


model9.2<-lm(employee_ethnicity~ProfileNumber_f+ProfileCooperation+ProfileSDSM
           +ProfileSubstantive
           +female+age+married+education+householdsize+region+urban
           +news+equalopportunity+authoritarian+knowledge, 
           survey2[survey2$albanian==0,])
(coef9.2<-coeftest(model9.2, vcov=vcovHC(model9.2, type="HC0")))


model9.3<-lm(employee_ethnicity~ProfileNumber_f+ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region2+region3+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==1,])
(coef9.3<-coeftest(model9.3, vcov=vcovHC(model9.3, type="HC0")))



model9.4<-lm(ministerfinancial~ProfileNumber_f+ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,])
(coef9.4<-coeftest(model9.4, vcov=vcovHC(model9.4, type="HC0")))


model9.5<-lm(ministerfinancial~ProfileNumber_f+ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region2+region3+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==1,])
(coef9.5<-coeftest(model9.5, vcov=vcovHC(model9.5, type="HC0")))


model9.6<-lm(ministerconcerns~ProfileNumber_f+ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==0,])
(coef9.6<-coeftest(model9.6, vcov=vcovHC(model9.6, type="HC0")))


model9.7<-lm(ministerconcerns~ProfileNumber_f+ProfileCooperation+ProfileSDSM
             +ProfileSubstantive
             +female+age+married+education+householdsize+region2+region3+urban
             +news+equalopportunity+authoritarian+knowledge, 
             survey2[survey2$albanian==1,])
(coef9.7<-coeftest(model9.7, vcov=vcovHC(model9.7, type="HC0")))


#Table OA.6.7
stargazer(model9, model9.1, model9.2, model9.3, model9.4,
          model9.5, model9.6, model9.7, se=list(coef9[,2],
          coef9.1[,2], coef9.2[,2], coef9.3[,2], coef9.4[,2],
          coef9.5[,2], coef9.6[,2], coef9.7[,2]))

