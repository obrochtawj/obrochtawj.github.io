##########################################################
### Do Peers Respond? Attendance and Critical Events   ###
### William O'Brochta                                  ###
### Washington University in St. Louis                 ###
### Published in British Politics                      ###
##########################################################



library(foreign)
library(dplyr)
library(tidyverse)
library(stargazer)
library(xtable)
library(lubridate)
library(interplot)
library(sandwich)
library(lmtest)
library(robustbase)
library(scales)
library(hansard)
library(DataCombine)



#Import Lords attendance from the Hansard API (import done 10/1/17)
#attendance<-lords_attendance()
#attendance2 <- data.frame(do.call('rbind', strsplit(as.character(attendance$about),split='/', fixed=T)))
#attendance$about<-attendance2$X5
#write.csv(attendance, file='attendance_dates.csv')


d<-read.csv('attendance_dates.csv')

#Pull year from date
d$year <- lubridate::year(d$date_value)

#Count number of peers in HOL by year
#Number of members comes from Russell's database
total_members<-c(809,822,792,781,760,787,753,706,732,738,736,717,691,664,679,700,688,662,669)
elected<-total_members-26-92
rev((hist(d$year))$counts)
#Create elected year variable counting number of elected members per year
elected_year<-c(rep(691,15),rep(704,152), rep(674,138), rep(663,146), rep(642,149), rep(669, 154),
                rep(635,157), rep(588, 142), rep(614, 141), rep(620, 149), rep(618, 150), rep(599, 148),
                rep(573, 131), rep(546, 163), rep(561, 174), rep(582,160), rep(570,141), rep(544,173), rep(551,18))

d$elected_year<-elected_year

## Share of Hereditary Lords present in each sesssion 
d <- mutate(d, sh_h_present=Hereditary/92, 
            sh_s_present = Spiritual/26,
            sh_l_present = Elected/elected_year)

# Sittings per year
d_year <- group_by(d, year)
d_year_sum <- summarise(d_year, no_sittng=n(), 
                        share_h=mean(sh_h_present),
                        share_s=mean(sh_s_present),
                        share_l=mean(sh_l_present),
                        sd_h = sd(sh_h_present), 
                        sd_s = sd(sh_s_present), 
                        sd_l = sd(sh_l_present))


#Get Lords and Commons Divisions (don't run)
#commons_divisions<-commons_divisions()
#commons_divisions_date<-table(commons_divisions$date_value)
#commons_divisions_date<-as.data.frame(commons_divisions_date)
#colnames(commons_divisions_date)<-c('date_value', 'commons_divisions')
#commons_divisions_date$date_value<-as.Date(commons_divisions_date$date_value)
#commons_divisions_date$commons_divisions<-ifelse(is.na(commons_divisions_date$commons_divisions), 0, commons_divisions_date$commons_divisions)

#lords_divisions<-lords_divisions()
#lords_divisions_date<-table(lords_divisions$date_value)
#lords_divisions_date<-as.data.frame(lords_divisions_date)
#colnames(lords_divisions_date)<-c('date_value', 'lords_divisions')
#lords_divisions_date$date_value<-as.Date(lords_divisions_date$date_value)
#lords_divisions_date$lords_divisions<-ifelse(is.na(lords_divisions_date$lords_divisions), 0, lords_divisions_date$lords_divisions)

#Commons data starts 2001-06-27
#save(lords_divisions_date, file='lords_divisions_date.RData')
#save(commons_divisions_date, file='commons_divisions_date.RData')


#Import Lords and Commons divisions
load('lords_divisions_date.RData')
load('commons_divisions_date.RData')
divisions<-merge(commons_divisions_date, lords_divisions_date, by='date_value', all.x=T, all.y=T)

d_year$date_value<-as.Date(d_year$date_value)
#Pull attendance by date and merge with divisions data
d_year2<-merge(d_year, lords_divisions_date, by='date_value', all.x=T)
d_year2$lords_divisions<-ifelse(is.na(d_year2$lords_divisions), 0, d_year2$lords_divisions)
#Calculate share of all Lords present including Spiritual and Hereditary
d_year2$sh_all_present<-d_year2$totals/(d_year2$elected_year+26+92)
d_year2$date_value<-as.Date(d_year2$date_value)

#Import revised Commons divisions
#Add NA for missing data and 0 for days with no divisions
divisions2<-read.csv('divisions2.csv', header=T, stringsAsFactors = F)
colnames(divisions2)<-c('date_value', 'commons_divisions')
divisions2$date_value<-as.Date(divisions2$date_value, format='%m/%d/%y')

d_year4<-merge(d_year2, divisions2, by='date_value', all.x=T)
d_year4$date_value<-as.Date(d_year4$date_value)

#Import daily weather from Crawley Down
crawley<-read.csv('crawley_down.csv', header=T, stringsAsFactors = F)
crawley$date_value<-as.Date(crawley$date_value)

d_year5<-merge(d_year4, crawley, by='date_value', all.x=T)
d_year5$mean<-as.numeric(d_year5$mean)
d_year5$high<-as.numeric(d_year5$high)
d_year5$low<-as.numeric(d_year5$low)
d_year5$heat<-as.numeric(d_year5$heat)
d_year5$cool<-as.numeric(d_year5$cool)
d_year5$rain<-as.numeric(d_year5$rain)
d_year5$avg_wind<-as.numeric(d_year5$avg_wind)
d_year5$high_wind<-as.numeric(d_year5$high_wind)

#Is day of HOL/Commons reform debate influential?
debate<-read.csv('reform_debate.csv', header=T, stringsAsFactors = F)
debate$date_value<-as.Date(debate$date_value, format='%m/%d/%y')

d_year5$date_value<-as.Date(d_year5$date_value)
d_year6<-merge(d_year5, debate, by='date_value', all.x=T)
d_year6$debate_commons<-ifelse(is.na(d_year6$debate_commons), 0, d_year6$debate_commons)
d_year6$debate_lords<-ifelse(is.na(d_year6$debate_lords), 0, d_year6$debate_lords)


#GTD data
gtd<-read.csv('gtdUK_date.csv', header=T, stringsAsFactors = F)
gtd$close_date<-as.Date(gtd$close_date, origin = "1899-12-30")

gtd$nattack_days<-gtd$nattack/gtd$days_after
d_year9<-merge(d_year6, gtd, by.x='date_value', by.y='close_date', all.x=T)
d_year9$nkill<-ifelse(is.na(d_year9$nkill), 0, d_year9$nkill)
d_year9$nwound<-ifelse(is.na(d_year9$nwound), 0, d_year9$nwound)
d_year9$nattack_days<-ifelse(is.na(d_year9$nattack_days), 0, d_year9$nattack_days)
d_year9$nattack01<-ifelse(d_year9$nattack!=0,1,0)
d_year9$nattack01<-ifelse(is.na(d_year9$nattack01),0,d_year9$nattack01)
#save(d_year9, file='d_year9.RData')


load('d_year9.RData')
d_year9$violentattack<-ifelse(d_year9$nkill!=0 | d_year9$nwound!=0, 1, 0)
d_year9$nattack01<-ifelse(d_year9$date_value>'2015-01-01',NA,d_year9$nattack01)
d_year9$nattack_days2<-ifelse(d_year9$nattack01==1 & d_year9$days_after<11, 1, 0)
d_year9$nattack_days2<-ifelse(is.na(d_year9$nattack_days2), 0, d_year9$nattack_days2)
d_year9$nattack_days2<-ifelse(d_year9$date_value>'2015-01-01',NA,d_year9$nattack_days2)
d_year11<-d_year9

d_year11<- slide(d_year11, Var = "nattack01", NewVar="nattack01_l", slideBy = -1)
t.test(d_year11[d_year11$nattack01==1,]$sh_all_present,
       d_year11[d_year11$nattack01_l==1,]$sh_all_present)

d_year11<- slide(d_year11, Var = "violentattack", NewVar="violentattack_l", slideBy = -1)
t.test(d_year11[d_year11$violentattack==1,]$sh_all_present,
       d_year11[d_year11$violentattack_l==1,]$sh_all_present)

d_year11<- slide(d_year11, Var = "nattack_days2", NewVar="nattack_days2_l", slideBy = -1)
t.test(d_year11[d_year11$nattack_days2==1,]$sh_all_present,
       d_year11[d_year11$nattack_days2_l==1,]$sh_all_present)


#Complaints (only since 2009)
hol_complaints<-read.csv('HOL Complaints_sittings.csv', header=T, stringsAsFactors = F)
hol_complaints$close_date<-as.Date(with(hol_complaints, paste(year, month, day,sep="-")), "%Y-%m-%d")
hol_complaints$complaint<-1
d_year12<-merge(d_year11, hol_complaints, by.x='date_value', by.y='close_date', all.x=T)

#Disasters from EM-Dat
disasters<-read.csv("UK Disasters_sittings.csv", header=T, stringsAsFactors = F)
disasters$close_date<-as.Date(with(disasters, paste(year, month, day,sep="-")), "%Y-%m-%d")
disasters$disaster<-1

d_year13<-merge(d_year12, disasters, by.x='date_value', by.y='close_date', all.x=T)
d_year13$disaster<-ifelse(is.na(d_year13$disaster),0,d_year13$disaster)
d_year13$affected<-ifelse(is.na(d_year13$Total.affected),0,1)

d_year13<- slide(d_year13, Var = "disaster", NewVar="disaster_l", slideBy = -1)
t.test(d_year13[d_year13$disaster==1,]$sh_all_present,
       d_year13[d_year13$disaster_l==1,]$sh_all_present)

d_year13<- slide(d_year13, Var = "affected", NewVar="affected_l", slideBy = -1)
t.test(d_year13[d_year13$affected==1,]$sh_all_present,
       d_year13[d_year13$affected_l==1,]$sh_all_present)

d_year13$lords_divisions01<-ifelse(d_year13$lords_divisions>0,1,0)
d_year13$commons_divisions01<-ifelse(d_year13$commons_divisions>0,1,0)
d_year13$rain01<-ifelse(d_year13$rain>0,1,0)

##Run Full Model
model1<-lm(sh_all_present~nattack01+disaster+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_all_present)
           +as.factor(year.x), data=d_year13)
(coef1<-coeftest(model1, vcov = vcovHC(model1, 'HC0')))

model1.1<-lm(sh_all_present~nattack01+affected+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_all_present)
           +as.factor(year.x), data=d_year13)
(coef1.1<-coeftest(model1.1, vcov = vcovHC(model1.1, 'HC0')))


model1.2<-lm(sh_all_present~violentattack+disaster+debate_lords+debate_commons+
               lords_divisions01+commons_divisions01+high+rain01+
               as.factor(month.x)+lag(sh_all_present)
             +as.factor(year.x), data=d_year13[d_year13$year.x<2015,])
(coef1.2<-coeftest(model1.2, vcov = vcovHC(model1.2, 'HC0')))

model1.3<-lm(sh_all_present~nattack_days2+disaster+debate_lords+debate_commons+
               lords_divisions01+commons_divisions01+high+rain01+
               as.factor(month.x)+lag(sh_all_present)
             +as.factor(year.x), data=d_year13)
(coef1.3<-coeftest(model1.3, vcov = vcovHC(model1.3, 'HC0')))


model2<-lm(sh_h_present~nattack01+disaster+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_h_present)
           +as.factor(year.x), data=d_year13)
(coef2<-coeftest(model2, vcov = vcovHC(model2, 'HC0')))

model3<-lm(sh_l_present~nattack01+disaster+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_l_present)
           +as.factor(year.x), data=d_year13)
(coef3<-coeftest(model3, vcov = vcovHC(model3, 'HC0')))

model4<-lm(sh_s_present~nattack01+disaster+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_s_present)
           +as.factor(year.x), data=d_year13)
(coef4<-coeftest(model4, vcov = vcovHC(model4, 'HC0')))



#Just look at complaints
d_year14<-d_year13[d_year13$year.x>2008,]
d_year14$complaint<-ifelse(is.na(d_year14$complaint),0,d_year14$complaint)
d_year14$Adverse.Finding<-ifelse(is.na(d_year14$Adverse.Finding),0,d_year14$Adverse.Finding)

d_year14<- slide(d_year14, Var = "complaint", NewVar="complaint_l", slideBy = -1)
t.test(d_year14[d_year14$complaint==1,]$sh_all_present,
       d_year14[d_year14$complaint_l==1,]$sh_all_present)

d_year14<- slide(d_year14, Var = "Adverse.Finding", NewVar="Adverse.Finding_l", slideBy = -1)
t.test(d_year14[d_year14$Adverse.Finding==1,]$sh_all_present,
       d_year14[d_year14$Adverse.Finding_l==1,]$sh_all_present)



model5<-lm(sh_all_present~nattack01+disaster+complaint+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_all_present)
           +as.factor(year.x), data=d_year14)
(coef5<-coeftest(model5, vcov = vcovHC(model5, 'HC0')))

model5.1<-lm(sh_all_present~nattack01+disaster+Adverse.Finding+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_all_present)
           +as.factor(year.x), data=d_year14)
(coef5.1<-coeftest(model5.1, vcov = vcovHC(model5.1, 'HC0')))

model5.2<-lm(sh_all_present~nattack01+affected+complaint+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_all_present)
           +as.factor(year.x), data=d_year14)
(coef5.2<-coeftest(model5.2, vcov = vcovHC(model5.2, 'HC0')))

model5.3<-lm(sh_all_present~nattack01+affected+Adverse.Finding+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_all_present)
           +as.factor(year.x), data=d_year14)
(coef5.3<-coeftest(model5.3, vcov = vcovHC(model5.3, 'HC0')))



model6.1<-lm(sh_all_present~violentattack+disaster+complaint+debate_lords+debate_commons+
               lords_divisions01+commons_divisions01+high+rain01+
               as.factor(month.x)+lag(sh_all_present)
             +as.factor(year.x), data=d_year14[d_year14$year.x<2015,])
(coef6.1<-coeftest(model6.1, vcov = vcovHC(model6.1, 'HC0')))

model6.2<-lm(sh_all_present~nattack_days2+disaster+complaint+debate_lords+debate_commons+
               lords_divisions01+commons_divisions01+high+rain01+
               as.factor(month.x)+lag(sh_all_present)
             +as.factor(year.x), data=d_year14)
(coef6.2<-coeftest(model6.2, vcov = vcovHC(model6.2, 'HC0')))


model7<-lm(sh_h_present~nattack01+disaster+complaint+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_h_present)
           +as.factor(year.x), data=d_year14)
(coef7<-coeftest(model7, vcov = vcovHC(model7, 'HC0')))

model8<-lm(sh_l_present~nattack01+disaster+complaint+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_l_present)
           +as.factor(year.x), data=d_year14)
(coef8<-coeftest(model8, vcov = vcovHC(model8, 'HC0')))

model9<-lm(sh_s_present~nattack01+disaster+complaint+debate_lords+debate_commons+
             lords_divisions01+commons_divisions01+high+rain01+
             as.factor(month.x)+lag(sh_s_present)
           +as.factor(year.x), data=d_year14)
(coef9<-coeftest(model9, vcov = vcovHC(model9, 'HC0')))


table(d_year13$debate_lords,d_year13$debate_commons)
table(d_year13$debate_commons,d_year13$year.x)
table(d_year13$debate_commons, d_year13$month.x)

#Main results table
stargazer(model1, model5, se=list(coef1[,2], coef5[,2]), 
          type='html', out="mainresults.doc", no.space=T, omit.stat=c("f", "ser"), digits=2)

#Robustness checks
stargazer(model1.1, model1.2, model1.3, model5.2, model5.1, model5.3, model6.1, model6.2,
          se=list(coef1.1[,2], coef1.2[,2], coef1.3[,2], coef5.2[,2], coef5.1[,2], coef5.3[,2],
                  coef6.1[,2], coef6.2[,2]), 
          type='html', out='robustness.doc', no.space=T, omit.stat=c("f", "ser"), digits=2)





### Summary plots
### Lords and Commons Attendance
load('d_year9.RData')
mean(d_year9$sh_all_present)
mean(d_year9$sh_h_present)
mean(d_year9$sh_l_present)
mean(d_year9$sh_s_present)

mean(d_year9[d_year9$year.x==2000,]$sh_l_present)
mean(d_year9[d_year9$year.x==2015,]$sh_l_present)

#Summarize attendance by year
d_year9$nattack<-ifelse(d_year9$date_value>'2015-01-01',NA,d_year9$nattack)
d_year12<-as.data.frame(cbind(d_year9$date_value,d_year9$sh_all_present, 
                              d_year9$sh_h_present, d_year9$sh_l_present,
                              d_year9$sh_s_present, d_year9$nattack,
                              d_year9$debate_commons, d_year9$debate_lords, d_year9$year.x))
d_year12$V2<-as.numeric(as.character(d_year12$V2))
d_year12$V3<-as.numeric(as.character(d_year12$V3))
d_year12$V4<-as.numeric(as.character(d_year12$V4))
d_year12$V5<-as.numeric(as.character(d_year12$V5))
d_year12$V6<-as.numeric(as.character(d_year12$V6))
d_year12$V7<-as.numeric(as.character(d_year12$V7))
d_year12$V8<-as.numeric(as.character(d_year12$V8))
d_year12$V9<-as.numeric(as.character(d_year12$V9))
d_year12$V1<-as.yearmon(d_year12$V1, '%b-%Y')

### Yearly Frequency Plots
#Legislator-Level
attendance_time2<-d_year12%>%
  group_by(V9)%>%
  summarise(debate_commons=sum(V7),
            debate_lords=sum(V8))

attendance_time3<-as.matrix(cbind(attendance_time2$debate_commons, 
                                  attendance_time2$debate_lords))
rownames(attendance_time3)<-attendance_time2$V9
attendance_time3<-attendance_time3[-c(1,17,18,19),]

#Complaints
complaints_2<-c(NA,NA,NA,NA,NA,NA,NA,NA,NA, 7, 3, 3, 7, 8, 2)

#Constituency-Level
disasters_2<-c(4, 3, 6, 0, 3, 4, 0, 5, 3, 4, 2, 0, 5, 4, 1)
nattack_2<-c(10, 14, 3, 0, 1, 9, 3, 8, 9, 2, 2, 2, 4, 19, 23)
mean(nattack_2, na.rm=T)

par(mfrow=c(1,2))
plot(2000:2014, disasters_2, main="Constituency-Level",
     xlab="Year", ylab="Frequency", ylim=c(0,25), cex.main=1.5, cex.lab=1.3, cex.axis=1.3,
     cex=1.5, pch=16, type='o', col="gray50", xaxt='n', lwd=2, frame.plot=F)
points(y=nattack_2, x=2000:2014, pch=17, cex=1.8, type="o", lwd=2)
axis(1,at=c(2000,2004,2008, 2012), labels=c("2000", "2004", "2008", "2012"), cex.axis=1.3)
legend('topleft', c('Disaster', 'Attack'), col=c("gray50", "black"), pch=c(16,17), bty='n',
       inset=c(-0.1,-0.05), cex=1.2)

barplot1<-barplot(t(attendance_time3), names=rownames(attendance_time3),
                  col=c('gray50', 'gray100'), xlab='Year', ylab='Frequency', ylim=c(0,26), main='Legislator-Level',
                  cex.main=1.5, cex.lab=1.3, cex.axis=1.3, cex.names=1.5, xaxt="n")
points(y=complaints_2, x=barplot1, pch=18, cex=1.8, type='o', lwd=2)
axis(1,at=c(0.7,5.5,10.3, 15.1), labels=c("2000", "2004", "2008", "2012"), cex.axis=1.3)
legend('topleft', c('Commons Debate', 'Lords Debate', 'Scandal'), pt.bg=c('gray50', 'gray100', NA), pch=c(22, 22, 18), bty='n', cex=1.2,
       inset=c(-0.1, -0.05))

